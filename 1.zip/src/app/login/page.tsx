import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/seed";
import { LoginForm } from "@/components/login-form";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  await ensureSeeded();
  const user = await getCurrentUser();
  if (user) redirect("/dashboard");

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-950 px-4 py-10">
      <div className="pointer-events-none absolute -left-40 -top-40 h-96 w-96 rounded-full bg-blue-600/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -right-32 h-96 w-96 rounded-full bg-cyan-500/20 blur-3xl" />

      <div className="relative z-10 grid w-full max-w-4xl overflow-hidden rounded-3xl shadow-2xl md:grid-cols-2">
        <div className="hidden flex-col justify-between bg-gradient-to-br from-blue-700 via-blue-600 to-cyan-600 p-10 text-white md:flex">
          <div>
            <div className="flex items-center gap-2 text-xl font-bold tracking-tight">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/15 text-lg">🩺</span>
              MEDORA
            </div>
            <p className="mt-1 text-sm text-blue-100">Health Care Ecosystem</p>
          </div>
          <div>
            <h2 className="text-2xl font-semibold leading-snug">
              One workspace for your entire care team.
            </h2>
            <p className="mt-3 text-sm text-blue-100">
              Patients, appointments, records, pharmacy and billing — unified, secure, and always in sync.
            </p>
            <ul className="mt-6 space-y-2 text-sm text-blue-50">
              <li className="flex items-center gap-2">✅ Role-based access for your whole team</li>
              <li className="flex items-center gap-2">✅ Live inventory & prescription tracking</li>
              <li className="flex items-center gap-2">✅ Billing and insurance-ready invoices</li>
            </ul>
          </div>
          <p className="text-xs text-blue-100/80">© {new Date().getFullYear()} MEDORA Health Systems</p>
        </div>

        <div className="bg-white p-8 sm:p-10">
          <div className="mb-6 flex items-center gap-2 text-lg font-bold text-slate-900 md:hidden">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-blue-600 text-base text-white">🩺</span>
            MEDORA
          </div>
          <h1 className="text-2xl font-semibold text-slate-900">Welcome back</h1>
          <p className="mt-1 text-sm text-slate-500">Sign in to access your care team dashboard.</p>

          <LoginForm />
        </div>
      </div>
    </div>
  );
}
