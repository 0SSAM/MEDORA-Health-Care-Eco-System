import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { invoices, patients } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const invoiceSchema = z.object({
  patientId: z.string().uuid(),
  appointmentId: z.string().uuid().optional().nullable(),
  description: z.string().min(1),
  amount: z.coerce.number().min(0),
  status: z.enum(["paid", "pending", "overdue", "cancelled"]).default("pending"),
  issuedDate: z.string().optional(),
  dueDate: z.string().optional().nullable(),
});

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const rows = await db
    .select({
      id: invoices.id,
      invoiceNumber: invoices.invoiceNumber,
      patientId: invoices.patientId,
      appointmentId: invoices.appointmentId,
      description: invoices.description,
      amount: invoices.amount,
      status: invoices.status,
      issuedDate: invoices.issuedDate,
      dueDate: invoices.dueDate,
      paid: invoices.paid,
      createdAt: invoices.createdAt,
      firstName: patients.firstName,
      lastName: patients.lastName,
      mrn: patients.mrn,
    })
    .from(invoices)
    .leftJoin(patients, eq(invoices.patientId, patients.id))
    .orderBy(desc(invoices.createdAt));

  const result = rows.map((r) => ({
    ...r,
    patientName: r.firstName ? `${r.firstName} ${r.lastName}` : "Unknown patient",
  }));

  return NextResponse.json({ invoices: result });
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const body = await request.json().catch(() => null);
  const parsed = invoiceSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid invoice data.", issues: parsed.error.issues }, { status: 400 });
  }

  const invoiceNumber = `INV-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;

  const [created] = await db
    .insert(invoices)
    .values({
      ...parsed.data,
      invoiceNumber,
      amount: String(parsed.data.amount),
      paid: parsed.data.status === "paid",
    })
    .returning();

  return NextResponse.json({ invoice: created }, { status: 201 });
}
