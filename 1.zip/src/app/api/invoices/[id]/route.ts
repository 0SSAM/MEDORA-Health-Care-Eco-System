import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { invoices } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const invoiceUpdateSchema = z.object({
  patientId: z.string().uuid().optional(),
  appointmentId: z.string().uuid().optional().nullable(),
  description: z.string().min(1).optional(),
  amount: z.coerce.number().min(0).optional(),
  status: z.enum(["paid", "pending", "overdue", "cancelled"]).optional(),
  issuedDate: z.string().optional(),
  dueDate: z.string().optional().nullable(),
});

type RouteParams = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const body = await request.json().catch(() => null);
  const parsed = invoiceUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid invoice data.", issues: parsed.error.issues }, { status: 400 });
  }

  const { amount, status, ...rest } = parsed.data;

  const [updated] = await db
    .update(invoices)
    .set({
      ...rest,
      ...(amount !== undefined ? { amount: String(amount) } : {}),
      ...(status ? { status, paid: status === "paid" } : {}),
    })
    .where(eq(invoices.id, id))
    .returning();

  if (!updated) {
    return NextResponse.json({ message: "Invoice not found." }, { status: 404 });
  }

  return NextResponse.json({ invoice: updated });
}

export async function DELETE(_request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const [deleted] = await db.delete(invoices).where(eq(invoices.id, id)).returning();

  if (!deleted) {
    return NextResponse.json({ message: "Invoice not found." }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
