import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { prescriptions } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const prescriptionUpdateSchema = z.object({
  patientId: z.string().uuid().optional(),
  doctorId: z.string().uuid().optional().nullable(),
  medicationId: z.string().uuid().optional().nullable(),
  medicationName: z.string().min(1).optional(),
  dosage: z.string().min(1).optional(),
  frequency: z.string().min(1).optional(),
  durationDays: z.coerce.number().int().min(1).optional(),
  status: z.enum(["active", "completed", "cancelled"]).optional(),
  notes: z.string().optional().nullable(),
});

type RouteParams = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const body = await request.json().catch(() => null);
  const parsed = prescriptionUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid prescription data.", issues: parsed.error.issues }, { status: 400 });
  }

  const [updated] = await db
    .update(prescriptions)
    .set(parsed.data)
    .where(eq(prescriptions.id, id))
    .returning();

  if (!updated) {
    return NextResponse.json({ message: "Prescription not found." }, { status: 404 });
  }

  return NextResponse.json({ prescription: updated });
}

export async function DELETE(_request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const [deleted] = await db.delete(prescriptions).where(eq(prescriptions.id, id)).returning();

  if (!deleted) {
    return NextResponse.json({ message: "Prescription not found." }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
