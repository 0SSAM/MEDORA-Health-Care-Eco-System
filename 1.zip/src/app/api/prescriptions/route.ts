import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { medications, patients, prescriptions, users } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const prescriptionSchema = z.object({
  patientId: z.string().uuid(),
  doctorId: z.string().uuid().optional().nullable(),
  medicationId: z.string().uuid().optional().nullable(),
  medicationName: z.string().min(1),
  dosage: z.string().min(1),
  frequency: z.string().min(1),
  durationDays: z.coerce.number().int().min(1).default(7),
  status: z.enum(["active", "completed", "cancelled"]).default("active"),
  notes: z.string().optional().nullable(),
});

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const rows = await db
    .select({
      id: prescriptions.id,
      patientId: prescriptions.patientId,
      doctorId: prescriptions.doctorId,
      doctorName: users.name,
      medicationId: prescriptions.medicationId,
      medicationName: prescriptions.medicationName,
      dosage: prescriptions.dosage,
      frequency: prescriptions.frequency,
      durationDays: prescriptions.durationDays,
      status: prescriptions.status,
      notes: prescriptions.notes,
      createdAt: prescriptions.createdAt,
      firstName: patients.firstName,
      lastName: patients.lastName,
      mrn: patients.mrn,
    })
    .from(prescriptions)
    .leftJoin(users, eq(prescriptions.doctorId, users.id))
    .leftJoin(patients, eq(prescriptions.patientId, patients.id))
    .orderBy(desc(prescriptions.createdAt));

  const result = rows.map((r) => ({
    ...r,
    patientName: r.firstName ? `${r.firstName} ${r.lastName}` : "Unknown patient",
  }));

  return NextResponse.json({ prescriptions: result });
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const body = await request.json().catch(() => null);
  const parsed = prescriptionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid prescription data.", issues: parsed.error.issues }, { status: 400 });
  }

  const [created] = await db.insert(prescriptions).values(parsed.data).returning();

  if (parsed.data.medicationId && parsed.data.status === "active") {
    const [med] = await db
      .select({ stockQuantity: medications.stockQuantity })
      .from(medications)
      .where(eq(medications.id, parsed.data.medicationId));
    if (med && med.stockQuantity > 0) {
      await db
        .update(medications)
        .set({ stockQuantity: med.stockQuantity - 1 })
        .where(eq(medications.id, parsed.data.medicationId));
    }
  }

  return NextResponse.json({ prescription: created }, { status: 201 });
}
