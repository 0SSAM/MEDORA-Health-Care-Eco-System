import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { requireRole, requireUser } from "@/lib/api-auth";
import { hashPassword } from "@/lib/auth";

const staffUpdateSchema = z.object({
  name: z.string().min(1).optional(),
  email: z.string().email().optional(),
  password: z.string().min(6).optional().or(z.literal("")),
  role: z.enum(["admin", "doctor", "nurse", "receptionist", "pharmacist"]).optional(),
  specialty: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  status: z.enum(["active", "inactive"]).optional(),
});

type RouteParams = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const forbidden = requireRole(auth.user, ["admin"]);
  if (forbidden) return forbidden;

  const { id } = await params;
  const body = await request.json().catch(() => null);
  const parsed = staffUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid staff data.", issues: parsed.error.issues }, { status: 400 });
  }

  const { password, email, ...rest } = parsed.data;
  const updateValues: Record<string, unknown> = { ...rest };
  if (email) updateValues.email = email.toLowerCase().trim();
  if (password) updateValues.passwordHash = await hashPassword(password);

  const [updated] = await db
    .update(users)
    .set(updateValues)
    .where(eq(users.id, id))
    .returning({
      id: users.id,
      name: users.name,
      email: users.email,
      role: users.role,
      specialty: users.specialty,
      phone: users.phone,
      avatarColor: users.avatarColor,
      status: users.status,
      createdAt: users.createdAt,
    });

  if (!updated) {
    return NextResponse.json({ message: "Team member not found." }, { status: 404 });
  }

  return NextResponse.json({ staff: updated });
}

export async function DELETE(_request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const forbidden = requireRole(auth.user, ["admin"]);
  if (forbidden) return forbidden;

  const { id } = await params;

  if (id === auth.user.id) {
    return NextResponse.json({ message: "You cannot remove your own account." }, { status: 400 });
  }

  const [deleted] = await db.delete(users).where(eq(users.id, id)).returning();

  if (!deleted) {
    return NextResponse.json({ message: "Team member not found." }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
