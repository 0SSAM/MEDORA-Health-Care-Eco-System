import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { requireRole, requireUser } from "@/lib/api-auth";
import { hashPassword } from "@/lib/auth";

const staffSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(["admin", "doctor", "nurse", "receptionist", "pharmacist"]),
  specialty: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  status: z.enum(["active", "inactive"]).default("active"),
});

const palette = ["#2563eb", "#7c3aed", "#0891b2", "#059669", "#d97706", "#ea580c", "#db2777", "#4f46e5"];

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const rows = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      role: users.role,
      specialty: users.specialty,
      phone: users.phone,
      avatarColor: users.avatarColor,
      status: users.status,
      createdAt: users.createdAt,
    })
    .from(users)
    .orderBy(desc(users.createdAt));

  return NextResponse.json({ staff: rows });
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const forbidden = requireRole(auth.user, ["admin"]);
  if (forbidden) return forbidden;

  const body = await request.json().catch(() => null);
  const parsed = staffSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid staff data.", issues: parsed.error.issues }, { status: 400 });
  }

  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.email, parsed.data.email.toLowerCase().trim()))
    .limit(1);

  if (existing.length > 0) {
    return NextResponse.json({ message: "A team member with this email already exists." }, { status: 409 });
  }

  const passwordHash = await hashPassword(parsed.data.password);
  const avatarColor = palette[Math.floor(Math.random() * palette.length)];

  const [created] = await db
    .insert(users)
    .values({
      name: parsed.data.name,
      email: parsed.data.email.toLowerCase().trim(),
      passwordHash,
      role: parsed.data.role,
      specialty: parsed.data.specialty,
      phone: parsed.data.phone,
      status: parsed.data.status,
      avatarColor,
    })
    .returning({
      id: users.id,
      name: users.name,
      email: users.email,
      role: users.role,
      specialty: users.specialty,
      phone: users.phone,
      avatarColor: users.avatarColor,
      status: users.status,
      createdAt: users.createdAt,
    });

  return NextResponse.json({ staff: created }, { status: 201 });
}
