import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { medicalRecords, patients, users } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const recordSchema = z.object({
  patientId: z.string().uuid(),
  doctorId: z.string().uuid().optional().nullable(),
  visitDate: z.string().optional(),
  diagnosis: z.string().min(1),
  treatment: z.string().optional().nullable(),
  bloodPressure: z.string().optional().nullable(),
  heartRate: z.coerce.number().int().optional().nullable(),
  temperature: z.coerce.number().optional().nullable(),
  weightKg: z.coerce.number().optional().nullable(),
  notes: z.string().optional().nullable(),
});

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const rows = await db
    .select({
      id: medicalRecords.id,
      patientId: medicalRecords.patientId,
      doctorId: medicalRecords.doctorId,
      doctorName: users.name,
      visitDate: medicalRecords.visitDate,
      diagnosis: medicalRecords.diagnosis,
      treatment: medicalRecords.treatment,
      bloodPressure: medicalRecords.bloodPressure,
      heartRate: medicalRecords.heartRate,
      temperature: medicalRecords.temperature,
      weightKg: medicalRecords.weightKg,
      notes: medicalRecords.notes,
      createdAt: medicalRecords.createdAt,
      firstName: patients.firstName,
      lastName: patients.lastName,
      mrn: patients.mrn,
    })
    .from(medicalRecords)
    .leftJoin(users, eq(medicalRecords.doctorId, users.id))
    .leftJoin(patients, eq(medicalRecords.patientId, patients.id))
    .orderBy(desc(medicalRecords.visitDate));

  const result = rows.map((r) => ({
    ...r,
    patientName: r.firstName ? `${r.firstName} ${r.lastName}` : "Unknown patient",
  }));

  return NextResponse.json({ records: result });
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const body = await request.json().catch(() => null);
  const parsed = recordSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid record data.", issues: parsed.error.issues }, { status: 400 });
  }

  const { visitDate, temperature, weightKg, ...rest } = parsed.data;

  const [created] = await db
    .insert(medicalRecords)
    .values({
      ...rest,
      visitDate: visitDate ? new Date(visitDate) : new Date(),
      temperature: temperature != null ? String(temperature) : null,
      weightKg: weightKg != null ? String(weightKg) : null,
    })
    .returning();

  return NextResponse.json({ record: created }, { status: 201 });
}
