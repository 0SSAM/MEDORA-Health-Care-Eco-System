import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { medicalRecords } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const recordUpdateSchema = z.object({
  patientId: z.string().uuid().optional(),
  doctorId: z.string().uuid().optional().nullable(),
  visitDate: z.string().optional(),
  diagnosis: z.string().min(1).optional(),
  treatment: z.string().optional().nullable(),
  bloodPressure: z.string().optional().nullable(),
  heartRate: z.coerce.number().int().optional().nullable(),
  temperature: z.coerce.number().optional().nullable(),
  weightKg: z.coerce.number().optional().nullable(),
  notes: z.string().optional().nullable(),
});

type RouteParams = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const body = await request.json().catch(() => null);
  const parsed = recordUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid record data.", issues: parsed.error.issues }, { status: 400 });
  }

  const { visitDate, temperature, weightKg, ...rest } = parsed.data;

  const [updated] = await db
    .update(medicalRecords)
    .set({
      ...rest,
      ...(visitDate ? { visitDate: new Date(visitDate) } : {}),
      ...(temperature !== undefined ? { temperature: temperature != null ? String(temperature) : null } : {}),
      ...(weightKg !== undefined ? { weightKg: weightKg != null ? String(weightKg) : null } : {}),
    })
    .where(eq(medicalRecords.id, id))
    .returning();

  if (!updated) {
    return NextResponse.json({ message: "Record not found." }, { status: 404 });
  }

  return NextResponse.json({ record: updated });
}

export async function DELETE(_request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const [deleted] = await db.delete(medicalRecords).where(eq(medicalRecords.id, id)).returning();

  if (!deleted) {
    return NextResponse.json({ message: "Record not found." }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
