import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { patients } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const patientUpdateSchema = z.object({
  firstName: z.string().min(1).optional(),
  lastName: z.string().min(1).optional(),
  dob: z.string().optional().nullable(),
  gender: z.enum(["male", "female", "other"]).optional(),
  phone: z.string().optional().nullable(),
  email: z.string().optional().nullable(),
  address: z.string().optional().nullable(),
  bloodType: z.string().optional().nullable(),
  allergies: z.string().optional().nullable(),
  status: z.enum(["active", "inactive", "critical"]).optional(),
  assignedDoctorId: z.string().uuid().optional().nullable(),
});

type RouteParams = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const body = await request.json().catch(() => null);
  const parsed = patientUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid patient data.", issues: parsed.error.issues }, { status: 400 });
  }

  const [updated] = await db
    .update(patients)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(patients.id, id))
    .returning();

  if (!updated) {
    return NextResponse.json({ message: "Patient not found." }, { status: 404 });
  }

  return NextResponse.json({ patient: updated });
}

export async function DELETE(_request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const [deleted] = await db.delete(patients).where(eq(patients.id, id)).returning();

  if (!deleted) {
    return NextResponse.json({ message: "Patient not found." }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
