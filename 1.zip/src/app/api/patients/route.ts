import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { patients, users } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const patientSchema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  dob: z.string().optional().nullable(),
  gender: z.enum(["male", "female", "other"]).default("other"),
  phone: z.string().optional().nullable(),
  email: z.string().optional().nullable(),
  address: z.string().optional().nullable(),
  bloodType: z.string().optional().nullable(),
  allergies: z.string().optional().nullable(),
  status: z.enum(["active", "inactive", "critical"]).default("active"),
  assignedDoctorId: z.string().uuid().optional().nullable(),
});

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const rows = await db
    .select({
      id: patients.id,
      mrn: patients.mrn,
      firstName: patients.firstName,
      lastName: patients.lastName,
      dob: patients.dob,
      gender: patients.gender,
      phone: patients.phone,
      email: patients.email,
      address: patients.address,
      bloodType: patients.bloodType,
      allergies: patients.allergies,
      status: patients.status,
      assignedDoctorId: patients.assignedDoctorId,
      assignedDoctorName: users.name,
      createdAt: patients.createdAt,
      updatedAt: patients.updatedAt,
    })
    .from(patients)
    .leftJoin(users, eq(patients.assignedDoctorId, users.id))
    .orderBy(desc(patients.createdAt));

  return NextResponse.json({ patients: rows });
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const body = await request.json().catch(() => null);
  const parsed = patientSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid patient data.", issues: parsed.error.issues }, { status: 400 });
  }

  const mrn = `MED-${Date.now().toString().slice(-6)}${Math.floor(Math.random() * 10)}`;

  const [created] = await db
    .insert(patients)
    .values({ ...parsed.data, mrn })
    .returning();

  return NextResponse.json({ patient: created }, { status: 201 });
}
