import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, hashPassword, verifyPassword } from "@/lib/auth";

const profileSchema = z.object({
  name: z.string().min(1).optional(),
  phone: z.string().optional().nullable(),
  specialty: z.string().optional().nullable(),
  currentPassword: z.string().optional(),
  newPassword: z.string().min(6).optional(),
});

export async function PATCH(request: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  const parsed = profileSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid profile data.", issues: parsed.error.issues }, { status: 400 });
  }

  const { currentPassword, newPassword, ...rest } = parsed.data;
  const updateValues: Record<string, unknown> = { ...rest };

  if (newPassword) {
    if (!currentPassword) {
      return NextResponse.json({ message: "Current password is required to set a new password." }, { status: 400 });
    }
    const [row] = await db.select({ passwordHash: users.passwordHash }).from(users).where(eq(users.id, user.id));
    const valid = row && (await verifyPassword(currentPassword, row.passwordHash));
    if (!valid) {
      return NextResponse.json({ message: "Current password is incorrect." }, { status: 400 });
    }
    updateValues.passwordHash = await hashPassword(newPassword);
  }

  const [updated] = await db
    .update(users)
    .set(updateValues)
    .where(eq(users.id, user.id))
    .returning({
      id: users.id,
      name: users.name,
      email: users.email,
      role: users.role,
      specialty: users.specialty,
      phone: users.phone,
      avatarColor: users.avatarColor,
      status: users.status,
    });

  return NextResponse.json({ user: updated });
}
