import { NextResponse } from "next/server";
import { requireUser } from "@/lib/api-auth";
import { getDashboardStats } from "@/lib/dashboard";

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const stats = await getDashboardStats();
  return NextResponse.json(stats);
}
