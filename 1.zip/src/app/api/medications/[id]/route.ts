import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { medications } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const medicationUpdateSchema = z.object({
  name: z.string().min(1).optional(),
  category: z.string().min(1).optional(),
  stockQuantity: z.coerce.number().int().min(0).optional(),
  unit: z.string().min(1).optional(),
  reorderLevel: z.coerce.number().int().min(0).optional(),
  pricePerUnit: z.coerce.number().min(0).optional(),
  expiryDate: z.string().optional().nullable(),
  supplier: z.string().optional().nullable(),
});

type RouteParams = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const body = await request.json().catch(() => null);
  const parsed = medicationUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid medication data.", issues: parsed.error.issues }, { status: 400 });
  }

  const { pricePerUnit, ...rest } = parsed.data;

  const [updated] = await db
    .update(medications)
    .set({ ...rest, ...(pricePerUnit !== undefined ? { pricePerUnit: String(pricePerUnit) } : {}) })
    .where(eq(medications.id, id))
    .returning();

  if (!updated) {
    return NextResponse.json({ message: "Medication not found." }, { status: 404 });
  }

  return NextResponse.json({ medication: updated });
}

export async function DELETE(_request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const [deleted] = await db.delete(medications).where(eq(medications.id, id)).returning();

  if (!deleted) {
    return NextResponse.json({ message: "Medication not found." }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
