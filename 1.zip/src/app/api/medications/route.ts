import { NextResponse } from "next/server";
import { asc } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { medications } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const medicationSchema = z.object({
  name: z.string().min(1),
  category: z.string().min(1).default("General"),
  stockQuantity: z.coerce.number().int().min(0).default(0),
  unit: z.string().min(1).default("units"),
  reorderLevel: z.coerce.number().int().min(0).default(10),
  pricePerUnit: z.coerce.number().min(0).default(0),
  expiryDate: z.string().optional().nullable(),
  supplier: z.string().optional().nullable(),
});

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const rows = await db.select().from(medications).orderBy(asc(medications.name));
  return NextResponse.json({ medications: rows });
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const body = await request.json().catch(() => null);
  const parsed = medicationSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid medication data.", issues: parsed.error.issues }, { status: 400 });
  }

  const [created] = await db
    .insert(medications)
    .values({ ...parsed.data, pricePerUnit: String(parsed.data.pricePerUnit) })
    .returning();

  return NextResponse.json({ medication: created }, { status: 201 });
}
