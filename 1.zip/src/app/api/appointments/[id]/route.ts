import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { appointments } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const appointmentUpdateSchema = z.object({
  patientId: z.string().uuid().optional(),
  doctorId: z.string().uuid().optional().nullable(),
  scheduledAt: z.string().optional(),
  durationMinutes: z.coerce.number().int().min(5).max(480).optional(),
  type: z.enum(["checkup", "follow_up", "consultation", "emergency", "surgery", "vaccination"]).optional(),
  status: z.enum(["scheduled", "completed", "cancelled", "no_show"]).optional(),
  reason: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

type RouteParams = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const body = await request.json().catch(() => null);
  const parsed = appointmentUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid appointment data.", issues: parsed.error.issues }, { status: 400 });
  }

  const { scheduledAt, ...rest } = parsed.data;

  const [updated] = await db
    .update(appointments)
    .set({ ...rest, ...(scheduledAt ? { scheduledAt: new Date(scheduledAt) } : {}) })
    .where(eq(appointments.id, id))
    .returning();

  if (!updated) {
    return NextResponse.json({ message: "Appointment not found." }, { status: 404 });
  }

  return NextResponse.json({ appointment: updated });
}

export async function DELETE(_request: Request, { params }: RouteParams) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const { id } = await params;
  const [deleted] = await db.delete(appointments).where(eq(appointments.id, id)).returning();

  if (!deleted) {
    return NextResponse.json({ message: "Appointment not found." }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
