import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { appointments, patients, users } from "@/db/schema";
import { requireUser } from "@/lib/api-auth";

const appointmentSchema = z.object({
  patientId: z.string().uuid(),
  doctorId: z.string().uuid().optional().nullable(),
  scheduledAt: z.string().min(1),
  durationMinutes: z.coerce.number().int().min(5).max(480).default(30),
  type: z.enum(["checkup", "follow_up", "consultation", "emergency", "surgery", "vaccination"]).default("checkup"),
  status: z.enum(["scheduled", "completed", "cancelled", "no_show"]).default("scheduled"),
  reason: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const rows = await db
    .select({
      id: appointments.id,
      patientId: appointments.patientId,
      patientName: users.name,
      doctorId: appointments.doctorId,
      scheduledAt: appointments.scheduledAt,
      durationMinutes: appointments.durationMinutes,
      type: appointments.type,
      status: appointments.status,
      reason: appointments.reason,
      notes: appointments.notes,
      createdAt: appointments.createdAt,
    })
    .from(appointments)
    .leftJoin(users, eq(appointments.doctorId, users.id))
    .orderBy(asc(appointments.scheduledAt));

  const patientRows = await db
    .select({ id: patients.id, firstName: patients.firstName, lastName: patients.lastName, mrn: patients.mrn })
    .from(patients);

  const patientMap = new Map(patientRows.map((p) => [p.id, p]));

  const result = rows.map((row) => {
    const patient = patientMap.get(row.patientId);
    return {
      ...row,
      doctorName: row.patientName,
      patientName: patient ? `${patient.firstName} ${patient.lastName}` : "Unknown patient",
      patientMrn: patient?.mrn ?? "",
    };
  });

  return NextResponse.json({ appointments: result });
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;

  const body = await request.json().catch(() => null);
  const parsed = appointmentSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid appointment data.", issues: parsed.error.issues }, { status: 400 });
  }

  const [created] = await db
    .insert(appointments)
    .values({ ...parsed.data, scheduledAt: new Date(parsed.data.scheduledAt) })
    .returning();

  return NextResponse.json({ appointment: created }, { status: 201 });
}
