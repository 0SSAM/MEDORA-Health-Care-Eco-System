"use client";

import { useEffect, useMemo, useState } from "react";
import { PageHeader } from "@/components/page-header";
import {
  Avatar,
  Badge,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  Select,
  TableSkeleton,
  Textarea,
} from "@/components/ui";
import { useCrud } from "@/lib/use-crud";
import { calculateAge, formatDate, patientStatusColors } from "@/lib/format";

type Patient = {
  id: string;
  mrn: string;
  firstName: string;
  lastName: string;
  dob: string | null;
  gender: "male" | "female" | "other";
  phone: string | null;
  email: string | null;
  address: string | null;
  bloodType: string | null;
  allergies: string | null;
  status: "active" | "inactive" | "critical";
  assignedDoctorId: string | null;
  assignedDoctorName: string | null;
  createdAt: string;
};

type Doctor = { id: string; name: string; role: string; status: string };

const emptyForm = {
  firstName: "",
  lastName: "",
  dob: "",
  gender: "other" as Patient["gender"],
  phone: "",
  email: "",
  address: "",
  bloodType: "",
  allergies: "",
  status: "active" as Patient["status"],
  assignedDoctorId: "",
};

export default function PatientsPage() {
  const { items: patients, loading, error, create, update, remove } = useCrud<Patient>("/api/patients", "patients");
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Patient | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Patient | null>(null);

  useEffect(() => {
    fetch("/api/staff")
      .then((res) => res.json())
      .then((data) => setDoctors((data.staff ?? []).filter((s: Doctor) => s.role === "doctor")))
      .catch(() => setDoctors([]));
  }, []);

  const filtered = useMemo(() => {
    return patients.filter((p) => {
      const matchesSearch =
        !search ||
        `${p.firstName} ${p.lastName} ${p.mrn} ${p.email ?? ""}`.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === "all" || p.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [patients, search, statusFilter]);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(patient: Patient) {
    setEditing(patient);
    setForm({
      firstName: patient.firstName,
      lastName: patient.lastName,
      dob: patient.dob ?? "",
      gender: patient.gender,
      phone: patient.phone ?? "",
      email: patient.email ?? "",
      address: patient.address ?? "",
      bloodType: patient.bloodType ?? "",
      allergies: patient.allergies ?? "",
      status: patient.status,
      assignedDoctorId: patient.assignedDoctorId ?? "",
    });
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const payload = {
      ...form,
      dob: form.dob || null,
      phone: form.phone || null,
      email: form.email || null,
      address: form.address || null,
      bloodType: form.bloodType || null,
      allergies: form.allergies || null,
      assignedDoctorId: form.assignedDoctorId || null,
    };
    try {
      if (editing) {
        await update(editing.id, payload, "patient");
      } else {
        await create(payload, "patient", {
          mrn: "Pending…",
          assignedDoctorName: doctors.find((d) => d.id === form.assignedDoctorId)?.name ?? null,
          createdAt: new Date().toISOString(),
        });
      }
      setModalOpen(false);
    } catch {
      // toast already shown
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await remove(deleteTarget.id).catch(() => {});
    setDeleteTarget(null);
  }

  return (
    <div>
      <PageHeader
        title="Patients"
        description="Manage patient profiles, contact details and assigned care providers."
        action={<Button onClick={openCreate}>+ Add Patient</Button>}
      />

      <Card className="mb-4 flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <Input
          placeholder="Search by name, MRN or email…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="sm:max-w-xs"
        />
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="sm:max-w-[160px]">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="critical">Critical</option>
          <option value="inactive">Inactive</option>
        </Select>
        <span className="text-sm text-slate-400 sm:ml-auto">{filtered.length} patients</span>
      </Card>

      <Card className="overflow-hidden">
        {loading ? (
          <TableSkeleton rows={6} cols={5} />
        ) : error ? (
          <EmptyState icon="⚠️" title="Something went wrong" description={error} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="🧑‍⚕️"
            title={patients.length === 0 ? "No patients yet" : "No matching patients"}
            description={
              patients.length === 0
                ? "Add your first patient profile to start building your care roster."
                : "Try adjusting your search or filters."
            }
            action={
              patients.length === 0 ? <Button onClick={openCreate}>+ Add Patient</Button> : undefined
            }
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                  <th className="px-5 py-3 font-medium">Patient</th>
                  <th className="px-5 py-3 font-medium">Contact</th>
                  <th className="px-5 py-3 font-medium">Doctor</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p) => {
                  const age = calculateAge(p.dob);
                  const pending = p.id.startsWith("temp-");
                  return (
                    <tr key={p.id} className={`border-b border-slate-50 last:border-0 hover:bg-slate-50/60 ${pending ? "opacity-60" : ""}`}>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-3">
                          <Avatar name={`${p.firstName} ${p.lastName}`} color="#2563eb" size={34} />
                          <div className="min-w-0">
                            <p className="truncate font-semibold text-slate-800">
                              {p.firstName} {p.lastName}
                            </p>
                            <p className="text-xs text-slate-400">
                              {p.mrn} {age !== null ? `· ${age} yrs` : ""}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3 text-slate-600">
                        <p>{p.phone ?? "—"}</p>
                        <p className="text-xs text-slate-400">{p.email ?? "—"}</p>
                      </td>
                      <td className="px-5 py-3 text-slate-600">{p.assignedDoctorName ?? "Unassigned"}</td>
                      <td className="px-5 py-3">
                        <Badge color={patientStatusColors[p.status]}>{p.status}</Badge>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="secondary" onClick={() => openEdit(p)} disabled={pending}>
                            Edit
                          </Button>
                          <Button size="sm" variant="danger" onClick={() => setDeleteTarget(p)} disabled={pending}>
                            Delete
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? "Edit Patient" : "Add Patient"}
        description={editing ? `Updating ${editing.firstName} ${editing.lastName}` : "Create a new patient record"}
        wide
      >
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="First name">
            <Input required value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
          </Field>
          <Field label="Last name">
            <Input required value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
          </Field>
          <Field label="Date of birth">
            <Input type="date" value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} />
          </Field>
          <Field label="Gender">
            <Select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value as Patient["gender"] })}>
              <option value="female">Female</option>
              <option value="male">Male</option>
              <option value="other">Other</option>
            </Select>
          </Field>
          <Field label="Phone">
            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </Field>
          <Field label="Email">
            <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </Field>
          <Field label="Blood type">
            <Input placeholder="O+" value={form.bloodType} onChange={(e) => setForm({ ...form, bloodType: e.target.value })} />
          </Field>
          <Field label="Status">
            <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Patient["status"] })}>
              <option value="active">Active</option>
              <option value="critical">Critical</option>
              <option value="inactive">Inactive</option>
            </Select>
          </Field>
          <Field label="Assigned doctor">
            <Select
              value={form.assignedDoctorId}
              onChange={(e) => setForm({ ...form, assignedDoctorId: e.target.value })}
            >
              <option value="">Unassigned</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Address">
            <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Allergies">
              <Textarea
                placeholder="e.g. Penicillin, Peanuts"
                value={form.allergies}
                onChange={(e) => setForm({ ...form, allergies: e.target.value })}
              />
            </Field>
          </div>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : editing ? "Save changes" : "Add patient"}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete patient"
        description={`This will permanently remove ${deleteTarget?.firstName} ${deleteTarget?.lastName} and their records.`}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
