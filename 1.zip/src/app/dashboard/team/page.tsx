import { getCurrentUser } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { Card, EmptyState } from "@/components/ui";
import { TeamManager } from "@/components/team-manager";

export const dynamic = "force-dynamic";

export default async function TeamPage() {
  const user = await getCurrentUser();
  const isAdmin = user?.role === "admin";

  return (
    <div>
      <PageHeader
        title="Team"
        description="Manage staff accounts, roles and access across your care organization."
      />
      {isAdmin ? (
        <TeamManager />
      ) : (
        <Card>
          <EmptyState
            icon="🔒"
            title="Admins only"
            description="Team management is restricted to administrators. Contact your MEDORA admin for access changes."
          />
        </Card>
      )}
    </div>
  );
}
