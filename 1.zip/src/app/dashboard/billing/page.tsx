"use client";

import { useEffect, useMemo, useState } from "react";
import { PageHeader } from "@/components/page-header";
import {
  Badge,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  Select,
  TableSkeleton,
} from "@/components/ui";
import { useCrud } from "@/lib/use-crud";
import { formatCurrency, formatDate, invoiceStatusColors } from "@/lib/format";

type Invoice = {
  id: string;
  invoiceNumber: string;
  patientId: string;
  patientName: string;
  mrn: string;
  description: string;
  amount: string | number;
  status: "paid" | "pending" | "overdue" | "cancelled";
  issuedDate: string;
  dueDate: string | null;
};

type Option = { id: string; firstName?: string; lastName?: string };

const emptyForm = {
  patientId: "",
  description: "",
  amount: 0,
  status: "pending" as Invoice["status"],
  issuedDate: new Date().toISOString().slice(0, 10),
  dueDate: "",
};

export default function BillingPage() {
  const { items: invoices, loading, error, create, update, remove } = useCrud<Invoice>("/api/invoices", "invoices");
  const [patients, setPatients] = useState<Option[]>([]);
  const [statusFilter, setStatusFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Invoice | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Invoice | null>(null);

  useEffect(() => {
    fetch("/api/patients").then((res) => res.json()).then((data) => setPatients(data.patients ?? [])).catch(() => {});
  }, []);

  const filtered = useMemo(
    () => invoices.filter((i) => statusFilter === "all" || i.status === statusFilter),
    [invoices, statusFilter],
  );

  const totals = useMemo(() => {
    const paid = invoices.filter((i) => i.status === "paid").reduce((s, i) => s + Number(i.amount), 0);
    const outstanding = invoices
      .filter((i) => i.status === "pending" || i.status === "overdue")
      .reduce((s, i) => s + Number(i.amount), 0);
    return { paid, outstanding };
  }, [invoices]);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(inv: Invoice) {
    setEditing(inv);
    setForm({
      patientId: inv.patientId,
      description: inv.description,
      amount: Number(inv.amount),
      status: inv.status,
      issuedDate: inv.issuedDate,
      dueDate: inv.dueDate ?? "",
    });
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const patient = patients.find((p) => p.id === form.patientId);
    const payload = { ...form, dueDate: form.dueDate || null };
    try {
      if (editing) {
        await update(editing.id, payload, "invoice");
      } else {
        await create(payload, "invoice", {
          invoiceNumber: "Pending…",
          patientName: patient ? `${patient.firstName} ${patient.lastName}` : "Patient",
          mrn: "",
        });
      }
      setModalOpen(false);
    } catch {
      // toast shown
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await remove(deleteTarget.id).catch(() => {});
    setDeleteTarget(null);
  }

  return (
    <div>
      <PageHeader
        title="Billing & Invoices"
        description="Track patient charges, payments and outstanding balances."
        action={<Button onClick={openCreate}>+ New Invoice</Button>}
      />

      <div className="mb-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Card className="p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">Total collected</p>
          <p className="mt-1 text-2xl font-bold text-emerald-600">{formatCurrency(totals.paid)}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">Outstanding balance</p>
          <p className="mt-1 text-2xl font-bold text-amber-600">{formatCurrency(totals.outstanding)}</p>
        </Card>
      </div>

      <Card className="mb-4 flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="sm:max-w-[180px]">
          <option value="all">All statuses</option>
          <option value="paid">Paid</option>
          <option value="pending">Pending</option>
          <option value="overdue">Overdue</option>
          <option value="cancelled">Cancelled</option>
        </Select>
        <span className="text-sm text-slate-400 sm:ml-auto">{filtered.length} invoices</span>
      </Card>

      <Card className="overflow-hidden">
        {loading ? (
          <TableSkeleton rows={6} cols={6} />
        ) : error ? (
          <EmptyState icon="⚠️" title="Something went wrong" description={error} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="💳"
            title={invoices.length === 0 ? "No invoices yet" : "No matching invoices"}
            description={
              invoices.length === 0 ? "Create an invoice to start billing patients." : "Try a different status filter."
            }
            action={invoices.length === 0 ? <Button onClick={openCreate}>+ New Invoice</Button> : undefined}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px] text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                  <th className="px-5 py-3 font-medium">Invoice</th>
                  <th className="px-5 py-3 font-medium">Patient</th>
                  <th className="px-5 py-3 font-medium">Amount</th>
                  <th className="px-5 py-3 font-medium">Due date</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((inv) => {
                  const pending = inv.id.startsWith("temp-");
                  return (
                    <tr key={inv.id} className={`border-b border-slate-50 last:border-0 hover:bg-slate-50/60 ${pending ? "opacity-60" : ""}`}>
                      <td className="px-5 py-3">
                        <p className="font-semibold text-slate-800">{inv.invoiceNumber}</p>
                        <p className="text-xs text-slate-400">{inv.description}</p>
                      </td>
                      <td className="px-5 py-3 text-slate-600">{inv.patientName}</td>
                      <td className="px-5 py-3 font-medium text-slate-700">{formatCurrency(inv.amount)}</td>
                      <td className="px-5 py-3 text-slate-600">{formatDate(inv.dueDate)}</td>
                      <td className="px-5 py-3">
                        <Badge color={invoiceStatusColors[inv.status]}>{inv.status}</Badge>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="secondary" onClick={() => openEdit(inv)} disabled={pending}>
                            Edit
                          </Button>
                          <Button size="sm" variant="danger" onClick={() => setDeleteTarget(inv)} disabled={pending}>
                            Delete
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Invoice" : "New Invoice"} wide>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Patient">
            <Select required value={form.patientId} onChange={(e) => setForm({ ...form, patientId: e.target.value })}>
              <option value="">Select patient</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Amount ($)">
            <Input
              type="number"
              min={0}
              step="0.01"
              required
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })}
            />
          </Field>
          <Field label="Issued date">
            <Input type="date" required value={form.issuedDate} onChange={(e) => setForm({ ...form, issuedDate: e.target.value })} />
          </Field>
          <Field label="Due date">
            <Input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
          </Field>
          <Field label="Status">
            <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Invoice["status"] })}>
              <option value="pending">Pending</option>
              <option value="paid">Paid</option>
              <option value="overdue">Overdue</option>
              <option value="cancelled">Cancelled</option>
            </Select>
          </Field>
          <div className="sm:col-span-2">
            <Field label="Description">
              <Input required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </Field>
          </div>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : editing ? "Save changes" : "Create invoice"}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete invoice"
        description={`Remove invoice ${deleteTarget?.invoiceNumber}?`}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
