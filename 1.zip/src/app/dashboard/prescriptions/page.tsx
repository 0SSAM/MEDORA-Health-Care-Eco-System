"use client";

import { useEffect, useMemo, useState } from "react";
import { PageHeader } from "@/components/page-header";
import {
  Badge,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  Select,
  TableSkeleton,
  Textarea,
} from "@/components/ui";
import { useCrud } from "@/lib/use-crud";
import { formatDate, prescriptionStatusColors } from "@/lib/format";

type Prescription = {
  id: string;
  patientId: string;
  patientName: string;
  mrn: string;
  doctorId: string | null;
  doctorName: string | null;
  medicationId: string | null;
  medicationName: string;
  dosage: string;
  frequency: string;
  durationDays: number;
  status: "active" | "completed" | "cancelled";
  notes: string | null;
  createdAt: string;
};

type Option = { id: string; name?: string; firstName?: string; lastName?: string; role?: string };
type Medication = { id: string; name: string };

const emptyForm = {
  patientId: "",
  doctorId: "",
  medicationId: "",
  medicationName: "",
  dosage: "",
  frequency: "",
  durationDays: 7,
  status: "active" as Prescription["status"],
  notes: "",
};

export default function PrescriptionsPage() {
  const { items: prescriptions, loading, error, create, update, remove } = useCrud<Prescription>(
    "/api/prescriptions",
    "prescriptions",
  );
  const [patients, setPatients] = useState<Option[]>([]);
  const [doctors, setDoctors] = useState<Option[]>([]);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [statusFilter, setStatusFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Prescription | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Prescription | null>(null);

  useEffect(() => {
    fetch("/api/patients").then((res) => res.json()).then((data) => setPatients(data.patients ?? [])).catch(() => {});
    fetch("/api/staff")
      .then((res) => res.json())
      .then((data) => setDoctors((data.staff ?? []).filter((s: Option) => s.role === "doctor")))
      .catch(() => {});
    fetch("/api/medications").then((res) => res.json()).then((data) => setMedications(data.medications ?? [])).catch(() => {});
  }, []);

  const filtered = useMemo(
    () => prescriptions.filter((p) => statusFilter === "all" || p.status === statusFilter),
    [prescriptions, statusFilter],
  );

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(rx: Prescription) {
    setEditing(rx);
    setForm({
      patientId: rx.patientId,
      doctorId: rx.doctorId ?? "",
      medicationId: rx.medicationId ?? "",
      medicationName: rx.medicationName,
      dosage: rx.dosage,
      frequency: rx.frequency,
      durationDays: rx.durationDays,
      status: rx.status,
      notes: rx.notes ?? "",
    });
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const patient = patients.find((p) => p.id === form.patientId);
    const doctor = doctors.find((d) => d.id === form.doctorId);
    const payload = {
      ...form,
      doctorId: form.doctorId || null,
      medicationId: form.medicationId || null,
      notes: form.notes || null,
    };
    try {
      if (editing) {
        await update(editing.id, payload, "prescription");
      } else {
        await create(payload, "prescription", {
          patientName: patient ? `${patient.firstName} ${patient.lastName}` : "Patient",
          mrn: "",
          doctorName: doctor?.name ?? null,
          createdAt: new Date().toISOString(),
        });
      }
      setModalOpen(false);
    } catch {
      // toast shown
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await remove(deleteTarget.id).catch(() => {});
    setDeleteTarget(null);
  }

  return (
    <div>
      <PageHeader
        title="Prescriptions"
        description="Track medication orders linked to patients and pharmacy stock."
        action={<Button onClick={openCreate}>+ New Prescription</Button>}
      />

      <Card className="mb-4 flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="sm:max-w-[180px]">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
        </Select>
        <span className="text-sm text-slate-400 sm:ml-auto">{filtered.length} prescriptions</span>
      </Card>

      <Card className="overflow-hidden">
        {loading ? (
          <TableSkeleton rows={6} cols={5} />
        ) : error ? (
          <EmptyState icon="⚠️" title="Something went wrong" description={error} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="💊"
            title={prescriptions.length === 0 ? "No prescriptions yet" : "No matching prescriptions"}
            description={
              prescriptions.length === 0
                ? "Create a prescription to send medication orders to the pharmacy."
                : "Try a different status filter."
            }
            action={prescriptions.length === 0 ? <Button onClick={openCreate}>+ New Prescription</Button> : undefined}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                  <th className="px-5 py-3 font-medium">Patient</th>
                  <th className="px-5 py-3 font-medium">Medication</th>
                  <th className="px-5 py-3 font-medium">Dosage / Frequency</th>
                  <th className="px-5 py-3 font-medium">Prescribed by</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((rx) => {
                  const pending = rx.id.startsWith("temp-");
                  return (
                    <tr key={rx.id} className={`border-b border-slate-50 last:border-0 hover:bg-slate-50/60 ${pending ? "opacity-60" : ""}`}>
                      <td className="px-5 py-3">
                        <p className="font-semibold text-slate-800">{rx.patientName}</p>
                        <p className="text-xs text-slate-400">{formatDate(rx.createdAt)}</p>
                      </td>
                      <td className="px-5 py-3 text-slate-600">{rx.medicationName}</td>
                      <td className="px-5 py-3 text-slate-600">
                        {rx.dosage} · {rx.frequency}
                        <p className="text-xs text-slate-400">{rx.durationDays} days</p>
                      </td>
                      <td className="px-5 py-3 text-slate-600">{rx.doctorName ?? "Unassigned"}</td>
                      <td className="px-5 py-3">
                        <Badge color={prescriptionStatusColors[rx.status]}>{rx.status}</Badge>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="secondary" onClick={() => openEdit(rx)} disabled={pending}>
                            Edit
                          </Button>
                          <Button size="sm" variant="danger" onClick={() => setDeleteTarget(rx)} disabled={pending}>
                            Delete
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Prescription" : "New Prescription"} wide>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Patient">
            <Select required value={form.patientId} onChange={(e) => setForm({ ...form, patientId: e.target.value })}>
              <option value="">Select patient</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Prescribing doctor">
            <Select value={form.doctorId} onChange={(e) => setForm({ ...form, doctorId: e.target.value })}>
              <option value="">Unassigned</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Medication from inventory (optional)">
            <Select
              value={form.medicationId}
              onChange={(e) => {
                const med = medications.find((m) => m.id === e.target.value);
                setForm({ ...form, medicationId: e.target.value, medicationName: med ? med.name : form.medicationName });
              }}
            >
              <option value="">Custom medication</option>
              {medications.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Medication name">
            <Input required value={form.medicationName} onChange={(e) => setForm({ ...form, medicationName: e.target.value })} />
          </Field>
          <Field label="Dosage">
            <Input required placeholder="10mg" value={form.dosage} onChange={(e) => setForm({ ...form, dosage: e.target.value })} />
          </Field>
          <Field label="Frequency">
            <Input required placeholder="Once daily" value={form.frequency} onChange={(e) => setForm({ ...form, frequency: e.target.value })} />
          </Field>
          <Field label="Duration (days)">
            <Input
              type="number"
              min={1}
              value={form.durationDays}
              onChange={(e) => setForm({ ...form, durationDays: Number(e.target.value) })}
            />
          </Field>
          <Field label="Status">
            <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Prescription["status"] })}>
              <option value="active">Active</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </Select>
          </Field>
          <div className="sm:col-span-2">
            <Field label="Notes">
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </Field>
          </div>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : editing ? "Save changes" : "Create prescription"}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete prescription"
        description={`Remove this prescription for ${deleteTarget?.patientName}?`}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
