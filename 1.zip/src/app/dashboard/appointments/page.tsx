"use client";

import { useEffect, useMemo, useState } from "react";
import { PageHeader } from "@/components/page-header";
import {
  Badge,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  Select,
  TableSkeleton,
  Textarea,
} from "@/components/ui";
import { useCrud } from "@/lib/use-crud";
import { appointmentStatusColors, appointmentTypeLabels, formatDateTime } from "@/lib/format";

type Appointment = {
  id: string;
  patientId: string;
  patientName: string;
  patientMrn: string;
  doctorId: string | null;
  doctorName: string | null;
  scheduledAt: string;
  durationMinutes: number;
  type: keyof typeof appointmentTypeLabels;
  status: "scheduled" | "completed" | "cancelled" | "no_show";
  reason: string | null;
  notes: string | null;
};

type Option = { id: string; name?: string; firstName?: string; lastName?: string; role?: string };

function toLocalInputValue(date: Date) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

const emptyForm = {
  patientId: "",
  doctorId: "",
  scheduledAt: toLocalInputValue(new Date(Date.now() + 60 * 60 * 1000)),
  durationMinutes: 30,
  type: "checkup" as Appointment["type"],
  status: "scheduled" as Appointment["status"],
  reason: "",
  notes: "",
};

export default function AppointmentsPage() {
  const { items: appointments, loading, error, create, update, remove } = useCrud<Appointment>(
    "/api/appointments",
    "appointments",
  );
  const [patients, setPatients] = useState<Option[]>([]);
  const [doctors, setDoctors] = useState<Option[]>([]);
  const [statusFilter, setStatusFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Appointment | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Appointment | null>(null);

  useEffect(() => {
    fetch("/api/patients")
      .then((res) => res.json())
      .then((data) => setPatients(data.patients ?? []))
      .catch(() => setPatients([]));
    fetch("/api/staff")
      .then((res) => res.json())
      .then((data) => setDoctors((data.staff ?? []).filter((s: Option) => s.role === "doctor")))
      .catch(() => setDoctors([]));
  }, []);

  const filtered = useMemo(() => {
    return appointments.filter((a) => statusFilter === "all" || a.status === statusFilter);
  }, [appointments, statusFilter]);

  const sorted = useMemo(
    () => [...filtered].sort((a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime()),
    [filtered],
  );

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(appt: Appointment) {
    setEditing(appt);
    setForm({
      patientId: appt.patientId,
      doctorId: appt.doctorId ?? "",
      scheduledAt: toLocalInputValue(new Date(appt.scheduledAt)),
      durationMinutes: appt.durationMinutes,
      type: appt.type,
      status: appt.status,
      reason: appt.reason ?? "",
      notes: appt.notes ?? "",
    });
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const patient = patients.find((p) => p.id === form.patientId);
    const doctor = doctors.find((d) => d.id === form.doctorId);
    const payload = {
      ...form,
      doctorId: form.doctorId || null,
      scheduledAt: new Date(form.scheduledAt).toISOString(),
      reason: form.reason || null,
      notes: form.notes || null,
    };
    try {
      if (editing) {
        await update(editing.id, payload, "appointment");
      } else {
        await create(payload, "appointment", {
          patientName: patient ? `${patient.firstName} ${patient.lastName}` : "Patient",
          patientMrn: "",
          doctorName: doctor?.name ?? null,
        });
      }
      setModalOpen(false);
    } catch {
      // handled by toast
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await remove(deleteTarget.id).catch(() => {});
    setDeleteTarget(null);
  }

  return (
    <div>
      <PageHeader
        title="Appointments"
        description="Schedule, track and manage patient visits across your care team."
        action={<Button onClick={openCreate}>+ New Appointment</Button>}
      />

      <Card className="mb-4 flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="sm:max-w-[180px]">
          <option value="all">All statuses</option>
          <option value="scheduled">Scheduled</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
          <option value="no_show">No show</option>
        </Select>
        <span className="text-sm text-slate-400 sm:ml-auto">{sorted.length} appointments</span>
      </Card>

      <Card className="overflow-hidden">
        {loading ? (
          <TableSkeleton rows={6} cols={5} />
        ) : error ? (
          <EmptyState icon="⚠️" title="Something went wrong" description={error} />
        ) : sorted.length === 0 ? (
          <EmptyState
            icon="📅"
            title={appointments.length === 0 ? "No appointments yet" : "No matching appointments"}
            description={
              appointments.length === 0
                ? "Schedule your first appointment to get the calendar moving."
                : "Try a different status filter."
            }
            action={appointments.length === 0 ? <Button onClick={openCreate}>+ New Appointment</Button> : undefined}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                  <th className="px-5 py-3 font-medium">Patient</th>
                  <th className="px-5 py-3 font-medium">Doctor</th>
                  <th className="px-5 py-3 font-medium">Date &amp; time</th>
                  <th className="px-5 py-3 font-medium">Type</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {sorted.map((a) => {
                  const pending = a.id.startsWith("temp-");
                  return (
                    <tr key={a.id} className={`border-b border-slate-50 last:border-0 hover:bg-slate-50/60 ${pending ? "opacity-60" : ""}`}>
                      <td className="px-5 py-3">
                        <p className="font-semibold text-slate-800">{a.patientName}</p>
                        <p className="text-xs text-slate-400">{a.patientMrn || a.reason}</p>
                      </td>
                      <td className="px-5 py-3 text-slate-600">{a.doctorName ?? "Unassigned"}</td>
                      <td className="px-5 py-3 text-slate-600">
                        {formatDateTime(a.scheduledAt)}
                        <span className="ml-1 text-xs text-slate-400">({a.durationMinutes}m)</span>
                      </td>
                      <td className="px-5 py-3 text-slate-600">{appointmentTypeLabels[a.type]}</td>
                      <td className="px-5 py-3">
                        <Badge color={appointmentStatusColors[a.status]}>{a.status.replace("_", " ")}</Badge>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="secondary" onClick={() => openEdit(a)} disabled={pending}>
                            Edit
                          </Button>
                          <Button size="sm" variant="danger" onClick={() => setDeleteTarget(a)} disabled={pending}>
                            Delete
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? "Edit Appointment" : "New Appointment"}
        wide
      >
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Patient">
            <Select required value={form.patientId} onChange={(e) => setForm({ ...form, patientId: e.target.value })}>
              <option value="">Select patient</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Doctor">
            <Select value={form.doctorId} onChange={(e) => setForm({ ...form, doctorId: e.target.value })}>
              <option value="">Unassigned</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Date &amp; time">
            <Input
              type="datetime-local"
              required
              value={form.scheduledAt}
              onChange={(e) => setForm({ ...form, scheduledAt: e.target.value })}
            />
          </Field>
          <Field label="Duration (minutes)">
            <Input
              type="number"
              min={5}
              step={5}
              value={form.durationMinutes}
              onChange={(e) => setForm({ ...form, durationMinutes: Number(e.target.value) })}
            />
          </Field>
          <Field label="Type">
            <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as Appointment["type"] })}>
              {Object.entries(appointmentTypeLabels).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Status">
            <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Appointment["status"] })}>
              <option value="scheduled">Scheduled</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
              <option value="no_show">No show</option>
            </Select>
          </Field>
          <div className="sm:col-span-2">
            <Field label="Reason for visit">
              <Input value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} />
            </Field>
          </div>
          <div className="sm:col-span-2">
            <Field label="Notes">
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </Field>
          </div>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : editing ? "Save changes" : "Create appointment"}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete appointment"
        description={`This will remove the appointment for ${deleteTarget?.patientName}.`}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
