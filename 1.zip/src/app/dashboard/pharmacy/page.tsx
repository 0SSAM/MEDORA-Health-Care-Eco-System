"use client";

import { useMemo, useState } from "react";
import { PageHeader } from "@/components/page-header";
import {
  Badge,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  TableSkeleton,
} from "@/components/ui";
import { useCrud } from "@/lib/use-crud";
import { formatCurrency, formatDate } from "@/lib/format";

type Medication = {
  id: string;
  name: string;
  category: string;
  stockQuantity: number;
  unit: string;
  reorderLevel: number;
  pricePerUnit: string | number;
  expiryDate: string | null;
  supplier: string | null;
};

const emptyForm = {
  name: "",
  category: "",
  stockQuantity: 0,
  unit: "tablets",
  reorderLevel: 10,
  pricePerUnit: 0,
  expiryDate: "",
  supplier: "",
};

export default function PharmacyPage() {
  const { items: medications, loading, error, create, update, remove } = useCrud<Medication>(
    "/api/medications",
    "medications",
  );
  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Medication | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Medication | null>(null);

  const filtered = useMemo(() => {
    const sorted = [...medications].sort((a, b) => a.name.localeCompare(b.name));
    if (!search) return sorted;
    return sorted.filter((m) => `${m.name} ${m.category}`.toLowerCase().includes(search.toLowerCase()));
  }, [medications, search]);

  const lowStockCount = medications.filter((m) => m.stockQuantity <= m.reorderLevel).length;

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(med: Medication) {
    setEditing(med);
    setForm({
      name: med.name,
      category: med.category,
      stockQuantity: med.stockQuantity,
      unit: med.unit,
      reorderLevel: med.reorderLevel,
      pricePerUnit: Number(med.pricePerUnit),
      expiryDate: med.expiryDate ?? "",
      supplier: med.supplier ?? "",
    });
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const payload = { ...form, expiryDate: form.expiryDate || null, supplier: form.supplier || null };
    try {
      if (editing) {
        await update(editing.id, payload, "medication");
      } else {
        await create(payload, "medication");
      }
      setModalOpen(false);
    } catch {
      // toast shown
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await remove(deleteTarget.id).catch(() => {});
    setDeleteTarget(null);
  }

  return (
    <div>
      <PageHeader
        title="Pharmacy Inventory"
        description="Monitor medication stock levels, pricing and suppliers."
        action={<Button onClick={openCreate}>+ Add Medication</Button>}
      />

      <Card className="mb-4 flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <Input placeholder="Search medications…" value={search} onChange={(e) => setSearch(e.target.value)} className="sm:max-w-xs" />
        {lowStockCount > 0 ? <Badge color="amber">{lowStockCount} items low on stock</Badge> : null}
        <span className="text-sm text-slate-400 sm:ml-auto">{filtered.length} medications</span>
      </Card>

      <Card className="overflow-hidden">
        {loading ? (
          <TableSkeleton rows={6} cols={6} />
        ) : error ? (
          <EmptyState icon="⚠️" title="Something went wrong" description={error} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="🏥"
            title={medications.length === 0 ? "No medications yet" : "No matching medications"}
            description={
              medications.length === 0
                ? "Add medications to start tracking your pharmacy inventory."
                : "Try a different search term."
            }
            action={medications.length === 0 ? <Button onClick={openCreate}>+ Add Medication</Button> : undefined}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px] text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                  <th className="px-5 py-3 font-medium">Medication</th>
                  <th className="px-5 py-3 font-medium">Category</th>
                  <th className="px-5 py-3 font-medium">Stock</th>
                  <th className="px-5 py-3 font-medium">Price / unit</th>
                  <th className="px-5 py-3 font-medium">Expiry</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((med) => {
                  const low = med.stockQuantity <= med.reorderLevel;
                  const pending = med.id.startsWith("temp-");
                  return (
                    <tr key={med.id} className={`border-b border-slate-50 last:border-0 hover:bg-slate-50/60 ${pending ? "opacity-60" : ""}`}>
                      <td className="px-5 py-3">
                        <p className="font-semibold text-slate-800">{med.name}</p>
                        <p className="text-xs text-slate-400">{med.supplier ?? "No supplier listed"}</p>
                      </td>
                      <td className="px-5 py-3 text-slate-600">{med.category}</td>
                      <td className="px-5 py-3">
                        <span className="font-medium text-slate-700">
                          {med.stockQuantity} {med.unit}
                        </span>
                        {low ? (
                          <span className="ml-2">
                            <Badge color="red">Reorder</Badge>
                          </span>
                        ) : null}
                      </td>
                      <td className="px-5 py-3 text-slate-600">{formatCurrency(med.pricePerUnit)}</td>
                      <td className="px-5 py-3 text-slate-600">{formatDate(med.expiryDate)}</td>
                      <td className="px-5 py-3">
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="secondary" onClick={() => openEdit(med)} disabled={pending}>
                            Edit
                          </Button>
                          <Button size="sm" variant="danger" onClick={() => setDeleteTarget(med)} disabled={pending}>
                            Delete
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Medication" : "Add Medication"} wide>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Medication name">
            <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </Field>
          <Field label="Category">
            <Input required value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
          </Field>
          <Field label="Stock quantity">
            <Input
              type="number"
              min={0}
              value={form.stockQuantity}
              onChange={(e) => setForm({ ...form, stockQuantity: Number(e.target.value) })}
            />
          </Field>
          <Field label="Unit">
            <Input required value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} />
          </Field>
          <Field label="Reorder level">
            <Input
              type="number"
              min={0}
              value={form.reorderLevel}
              onChange={(e) => setForm({ ...form, reorderLevel: Number(e.target.value) })}
            />
          </Field>
          <Field label="Price per unit ($)">
            <Input
              type="number"
              min={0}
              step="0.01"
              value={form.pricePerUnit}
              onChange={(e) => setForm({ ...form, pricePerUnit: Number(e.target.value) })}
            />
          </Field>
          <Field label="Expiry date">
            <Input type="date" value={form.expiryDate} onChange={(e) => setForm({ ...form, expiryDate: e.target.value })} />
          </Field>
          <Field label="Supplier">
            <Input value={form.supplier} onChange={(e) => setForm({ ...form, supplier: e.target.value })} />
          </Field>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : editing ? "Save changes" : "Add medication"}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete medication"
        description={`Remove ${deleteTarget?.name} from inventory?`}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
