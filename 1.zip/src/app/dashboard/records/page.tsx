"use client";

import { useEffect, useMemo, useState } from "react";
import { PageHeader } from "@/components/page-header";
import {
  Badge,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  Select,
  TableSkeleton,
  Textarea,
} from "@/components/ui";
import { useCrud } from "@/lib/use-crud";
import { formatDate } from "@/lib/format";

type MedicalRecord = {
  id: string;
  patientId: string;
  patientName: string;
  mrn: string;
  doctorId: string | null;
  doctorName: string | null;
  visitDate: string;
  diagnosis: string;
  treatment: string | null;
  bloodPressure: string | null;
  heartRate: number | null;
  temperature: string | number | null;
  weightKg: string | number | null;
  notes: string | null;
};

type Option = { id: string; name?: string; firstName?: string; lastName?: string; role?: string };

const emptyForm = {
  patientId: "",
  doctorId: "",
  visitDate: new Date().toISOString().slice(0, 10),
  diagnosis: "",
  treatment: "",
  bloodPressure: "",
  heartRate: "",
  temperature: "",
  weightKg: "",
  notes: "",
};

export default function RecordsPage() {
  const { items: records, loading, error, create, update, remove } = useCrud<MedicalRecord>("/api/records", "records");
  const [patients, setPatients] = useState<Option[]>([]);
  const [doctors, setDoctors] = useState<Option[]>([]);
  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<MedicalRecord | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<MedicalRecord | null>(null);

  useEffect(() => {
    fetch("/api/patients")
      .then((res) => res.json())
      .then((data) => setPatients(data.patients ?? []))
      .catch(() => setPatients([]));
    fetch("/api/staff")
      .then((res) => res.json())
      .then((data) => setDoctors((data.staff ?? []).filter((s: Option) => s.role === "doctor")))
      .catch(() => setDoctors([]));
  }, []);

  const filtered = useMemo(() => {
    const sorted = [...records].sort((a, b) => new Date(b.visitDate).getTime() - new Date(a.visitDate).getTime());
    if (!search) return sorted;
    return sorted.filter((r) =>
      `${r.patientName} ${r.diagnosis} ${r.mrn}`.toLowerCase().includes(search.toLowerCase()),
    );
  }, [records, search]);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(record: MedicalRecord) {
    setEditing(record);
    setForm({
      patientId: record.patientId,
      doctorId: record.doctorId ?? "",
      visitDate: record.visitDate.slice(0, 10),
      diagnosis: record.diagnosis,
      treatment: record.treatment ?? "",
      bloodPressure: record.bloodPressure ?? "",
      heartRate: record.heartRate?.toString() ?? "",
      temperature: record.temperature?.toString() ?? "",
      weightKg: record.weightKg?.toString() ?? "",
      notes: record.notes ?? "",
    });
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const patient = patients.find((p) => p.id === form.patientId);
    const doctor = doctors.find((d) => d.id === form.doctorId);
    const payload = {
      ...form,
      doctorId: form.doctorId || null,
      treatment: form.treatment || null,
      bloodPressure: form.bloodPressure || null,
      heartRate: form.heartRate ? Number(form.heartRate) : null,
      temperature: form.temperature ? Number(form.temperature) : null,
      weightKg: form.weightKg ? Number(form.weightKg) : null,
      notes: form.notes || null,
    };
    try {
      if (editing) {
        await update(editing.id, payload, "record");
      } else {
        await create(payload, "record", {
          patientName: patient ? `${patient.firstName} ${patient.lastName}` : "Patient",
          mrn: "",
          doctorName: doctor?.name ?? null,
        });
      }
      setModalOpen(false);
    } catch {
      // toast shown
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await remove(deleteTarget.id).catch(() => {});
    setDeleteTarget(null);
  }

  return (
    <div>
      <PageHeader
        title="Medical Records"
        description="Clinical visit history, diagnoses and vitals for every patient."
        action={<Button onClick={openCreate}>+ Add Record</Button>}
      />

      <Card className="mb-4 flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <Input
          placeholder="Search by patient or diagnosis…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="sm:max-w-xs"
        />
        <span className="text-sm text-slate-400 sm:ml-auto">{filtered.length} records</span>
      </Card>

      {loading ? (
        <Card className="overflow-hidden">
          <TableSkeleton rows={5} cols={5} />
        </Card>
      ) : error ? (
        <Card>
          <EmptyState icon="⚠️" title="Something went wrong" description={error} />
        </Card>
      ) : filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon="📋"
            title={records.length === 0 ? "No medical records yet" : "No matching records"}
            description={
              records.length === 0
                ? "Log a visit to start building a patient's clinical history."
                : "Try a different search term."
            }
            action={records.length === 0 ? <Button onClick={openCreate}>+ Add Record</Button> : undefined}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {filtered.map((record) => {
            const pending = record.id.startsWith("temp-");
            return (
              <Card key={record.id} className={`p-5 ${pending ? "opacity-60" : ""}`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{record.patientName}</p>
                    <p className="text-xs text-slate-400">{formatDate(record.visitDate)} · {record.doctorName ?? "Unassigned"}</p>
                  </div>
                  <Badge color="blue">{formatDate(record.visitDate, { month: "short", year: "numeric" })}</Badge>
                </div>
                <p className="mt-3 text-sm font-medium text-slate-700">Diagnosis: {record.diagnosis}</p>
                {record.treatment ? <p className="mt-1 text-sm text-slate-500">Treatment: {record.treatment}</p> : null}
                <div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-500">
                  {record.bloodPressure ? <span className="rounded-full bg-slate-100 px-2.5 py-1">BP {record.bloodPressure}</span> : null}
                  {record.heartRate ? <span className="rounded-full bg-slate-100 px-2.5 py-1">HR {record.heartRate} bpm</span> : null}
                  {record.temperature ? <span className="rounded-full bg-slate-100 px-2.5 py-1">Temp {record.temperature}°F</span> : null}
                  {record.weightKg ? <span className="rounded-full bg-slate-100 px-2.5 py-1">{record.weightKg} kg</span> : null}
                </div>
                {record.notes ? <p className="mt-3 text-sm text-slate-500">{record.notes}</p> : null}
                <div className="mt-4 flex justify-end gap-2">
                  <Button size="sm" variant="secondary" onClick={() => openEdit(record)} disabled={pending}>
                    Edit
                  </Button>
                  <Button size="sm" variant="danger" onClick={() => setDeleteTarget(record)} disabled={pending}>
                    Delete
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Record" : "Add Medical Record"} wide>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Patient">
            <Select required value={form.patientId} onChange={(e) => setForm({ ...form, patientId: e.target.value })}>
              <option value="">Select patient</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Doctor">
            <Select value={form.doctorId} onChange={(e) => setForm({ ...form, doctorId: e.target.value })}>
              <option value="">Unassigned</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Visit date">
            <Input type="date" required value={form.visitDate} onChange={(e) => setForm({ ...form, visitDate: e.target.value })} />
          </Field>
          <Field label="Blood pressure">
            <Input placeholder="120/80" value={form.bloodPressure} onChange={(e) => setForm({ ...form, bloodPressure: e.target.value })} />
          </Field>
          <Field label="Heart rate (bpm)">
            <Input type="number" value={form.heartRate} onChange={(e) => setForm({ ...form, heartRate: e.target.value })} />
          </Field>
          <Field label="Temperature (°F)">
            <Input type="number" step="0.1" value={form.temperature} onChange={(e) => setForm({ ...form, temperature: e.target.value })} />
          </Field>
          <Field label="Weight (kg)">
            <Input type="number" step="0.1" value={form.weightKg} onChange={(e) => setForm({ ...form, weightKg: e.target.value })} />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Diagnosis">
              <Input required value={form.diagnosis} onChange={(e) => setForm({ ...form, diagnosis: e.target.value })} />
            </Field>
          </div>
          <div className="sm:col-span-2">
            <Field label="Treatment">
              <Textarea value={form.treatment} onChange={(e) => setForm({ ...form, treatment: e.target.value })} />
            </Field>
          </div>
          <div className="sm:col-span-2">
            <Field label="Notes">
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </Field>
          </div>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : editing ? "Save changes" : "Add record"}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete medical record"
        description={`This will remove this visit record for ${deleteTarget?.patientName}.`}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
