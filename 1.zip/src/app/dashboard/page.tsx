import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { getDashboardStats } from "@/lib/dashboard";
import { Badge, Card } from "@/components/ui";
import { PageHeader } from "@/components/page-header";
import {
  appointmentStatusColors,
  appointmentTypeLabels,
  formatCurrency,
  formatDateTime,
  patientStatusColors,
} from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function DashboardOverviewPage() {
  const [user, stats] = await Promise.all([getCurrentUser(), getDashboardStats()]);

  const statCards = [
    {
      label: "Total Patients",
      value: stats.totalPatients,
      icon: "🧑‍⚕️",
      accent: "bg-blue-50 text-blue-600",
      href: "/dashboard/patients",
    },
    {
      label: "Critical Patients",
      value: stats.criticalPatients,
      icon: "🚨",
      accent: "bg-rose-50 text-rose-600",
      href: "/dashboard/patients",
    },
    {
      label: "Appointments Today",
      value: stats.appointmentsToday,
      icon: "📅",
      accent: "bg-cyan-50 text-cyan-600",
      href: "/dashboard/appointments",
    },
    {
      label: "Active Staff",
      value: stats.activeStaff,
      icon: "👥",
      accent: "bg-violet-50 text-violet-600",
      href: "/dashboard/team",
    },
    {
      label: "Low Stock Medications",
      value: stats.lowStockCount,
      icon: "⚠️",
      accent: "bg-amber-50 text-amber-600",
      href: "/dashboard/pharmacy",
    },
    {
      label: "Outstanding Invoices",
      value: formatCurrency(stats.pendingInvoicesTotal),
      icon: "💳",
      accent: "bg-emerald-50 text-emerald-600",
      href: "/dashboard/billing",
      sub: `${stats.pendingInvoicesCount} unpaid`,
    },
  ];

  return (
    <div>
      <PageHeader
        title={`Welcome back, ${user?.name.split(" ")[0] ?? "there"} 👋`}
        description="Here's what's happening across your care team today."
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {statCards.map((card) => (
          <Link key={card.label} href={card.href}>
            <Card className="flex items-center gap-4 p-5 transition hover:-translate-y-0.5 hover:shadow-md">
              <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl text-xl ${card.accent}`}>
                {card.icon}
              </span>
              <div className="min-w-0">
                <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{card.label}</p>
                <p className="mt-0.5 truncate text-2xl font-bold text-slate-900">{card.value}</p>
                {card.sub ? <p className="text-xs text-slate-400">{card.sub}</p> : null}
              </div>
            </Card>
          </Link>
        ))}
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 xl:grid-cols-5">
        <Card className="xl:col-span-3">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 className="text-sm font-semibold text-slate-800">Today &amp; upcoming appointments</h2>
            <Link href="/dashboard/appointments" className="text-xs font-medium text-blue-600 hover:underline">
              View all
            </Link>
          </div>
          {stats.upcomingAppointments.length === 0 ? (
            <div className="px-5 py-10 text-center text-sm text-slate-400">
              No upcoming appointments scheduled. Enjoy the calm 🌿
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {stats.upcomingAppointments.map((appt) => (
                <li key={appt.id} className="flex items-center justify-between gap-3 px-5 py-4">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-slate-800">{appt.patientName}</p>
                    <p className="text-xs text-slate-400">
                      {appt.patientMrn} · {appt.doctorName ?? "Unassigned"} · {appointmentTypeLabels[appt.type]}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-3">
                    <span className="text-xs font-medium text-slate-500">{formatDateTime(appt.scheduledAt)}</span>
                    <Badge color={appointmentStatusColors[appt.status]}>{appt.status.replace("_", " ")}</Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="xl:col-span-2">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 className="text-sm font-semibold text-slate-800">Recently added patients</h2>
            <Link href="/dashboard/patients" className="text-xs font-medium text-blue-600 hover:underline">
              View all
            </Link>
          </div>
          {stats.recentPatients.length === 0 ? (
            <div className="px-5 py-10 text-center text-sm text-slate-400">No patients registered yet.</div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {stats.recentPatients.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 px-5 py-4">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-slate-800">
                      {p.firstName} {p.lastName}
                    </p>
                    <p className="text-xs text-slate-400">{p.mrn}</p>
                  </div>
                  <Badge color={patientStatusColors[p.status]}>{p.status}</Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
