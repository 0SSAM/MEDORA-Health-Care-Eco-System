export const appointmentTypeLabels: Record<string, string> = {
  checkup: "Checkup",
  follow_up: "Follow-up",
  consultation: "Consultation",
  emergency: "Emergency",
  surgery: "Surgery",
  vaccination: "Vaccination",
};

export const appointmentStatusColors: Record<string, string> = {
  scheduled: "blue",
  completed: "green",
  cancelled: "slate",
  no_show: "red",
};

export const patientStatusColors: Record<string, string> = {
  active: "green",
  inactive: "slate",
  critical: "red",
};

export const invoiceStatusColors: Record<string, string> = {
  paid: "green",
  pending: "amber",
  overdue: "red",
  cancelled: "slate",
};

export const prescriptionStatusColors: Record<string, string> = {
  active: "blue",
  completed: "green",
  cancelled: "slate",
};

export const roleColors: Record<string, string> = {
  admin: "purple",
  doctor: "blue",
  nurse: "cyan",
  receptionist: "amber",
  pharmacist: "orange",
};

export const roleLabels: Record<string, string> = {
  admin: "Administrator",
  doctor: "Doctor",
  nurse: "Nurse",
  receptionist: "Receptionist",
  pharmacist: "Pharmacist",
};

export function formatCurrency(value: number | string) {
  const num = typeof value === "string" ? Number(value) : value;
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(num || 0);
}

export function formatDate(value: string | Date | null | undefined, opts?: Intl.DateTimeFormatOptions) {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-US", opts ?? { month: "short", day: "numeric", year: "numeric" }).format(date);
}

export function formatDateTime(value: string | Date | null | undefined) {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export function formatTime(value: string | Date | null | undefined) {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" }).format(date);
}

export function initials(name: string) {
  return name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export function calculateAge(dob: string | null | undefined) {
  if (!dob) return null;
  const birth = new Date(dob);
  if (Number.isNaN(birth.getTime())) return null;
  const diff = Date.now() - birth.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
}
