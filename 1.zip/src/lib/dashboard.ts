import { and, desc, eq, gte, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { appointments, invoices, medications, patients, users } from "@/db/schema";

export async function getDashboardStats() {
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const endOfToday = new Date();
  endOfToday.setHours(23, 59, 59, 999);

  const [
    [{ count: totalPatients }],
    [{ count: criticalPatients }],
    [{ count: activeStaff }],
    todaysAppointments,
    [{ count: lowStockCount }],
    pendingInvoices,
    upcomingAppointments,
  ] = await Promise.all([
    db.select({ count: sql<number>`count(*)::int` }).from(patients),
    db.select({ count: sql<number>`count(*)::int` }).from(patients).where(eq(patients.status, "critical")),
    db.select({ count: sql<number>`count(*)::int` }).from(users).where(eq(users.status, "active")),
    db
      .select({ id: appointments.id })
      .from(appointments)
      .where(and(gte(appointments.scheduledAt, startOfToday), lte(appointments.scheduledAt, endOfToday))),
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(medications)
      .where(sql`${medications.stockQuantity} <= ${medications.reorderLevel}`),
    db.select({ amount: invoices.amount }).from(invoices).where(sql`${invoices.status} in ('pending', 'overdue')`),
    db
      .select({
        id: appointments.id,
        scheduledAt: appointments.scheduledAt,
        status: appointments.status,
        type: appointments.type,
        patientId: appointments.patientId,
        doctorName: users.name,
      })
      .from(appointments)
      .leftJoin(users, eq(appointments.doctorId, users.id))
      .where(gte(appointments.scheduledAt, startOfToday))
      .orderBy(appointments.scheduledAt)
      .limit(6),
  ]);

  const patientRows = await db
    .select({ id: patients.id, firstName: patients.firstName, lastName: patients.lastName, mrn: patients.mrn })
    .from(patients);
  const patientMap = new Map(patientRows.map((p) => [p.id, p]));

  const upcoming = upcomingAppointments.map((row) => {
    const patient = patientMap.get(row.patientId);
    return {
      ...row,
      patientName: patient ? `${patient.firstName} ${patient.lastName}` : "Unknown patient",
      patientMrn: patient?.mrn ?? "",
    };
  });

  const recentPatients = await db
    .select({
      id: patients.id,
      firstName: patients.firstName,
      lastName: patients.lastName,
      mrn: patients.mrn,
      status: patients.status,
      createdAt: patients.createdAt,
    })
    .from(patients)
    .orderBy(desc(patients.createdAt))
    .limit(5);

  const pendingTotal = pendingInvoices.reduce((sum, inv) => sum + Number(inv.amount), 0);

  return {
    totalPatients,
    criticalPatients,
    activeStaff,
    appointmentsToday: todaysAppointments.length,
    lowStockCount,
    pendingInvoicesTotal: pendingTotal,
    pendingInvoicesCount: pendingInvoices.length,
    upcomingAppointments: upcoming,
    recentPatients,
  };
}
