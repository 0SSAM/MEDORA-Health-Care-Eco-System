"use client";

import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/components/toast";

type WithId = { id: string };

export function useCrud<T extends WithId>(endpoint: string, listKey: string) {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { showToast } = useToast();

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(endpoint, { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load data");
      const data = await res.json();
      setItems(data[listKey] ?? []);
    } catch {
      setError("We couldn't load this data. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [endpoint, listKey]);

  useEffect(() => {
    load();
  }, [load]);

  const create = useCallback(
    async (payload: Record<string, unknown>, itemKey: string, optimisticExtra: Partial<T> = {}) => {
      const tempId = `temp-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const optimisticItem = { ...payload, ...optimisticExtra, id: tempId } as unknown as T;
      setItems((prev) => [optimisticItem, ...prev]);
      try {
        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.message || "Failed to create item");
        setItems((prev) => prev.map((item) => (item.id === tempId ? data[itemKey] : item)));
        showToast("Created successfully.");
        return data[itemKey] as T;
      } catch (err) {
        setItems((prev) => prev.filter((item) => item.id !== tempId));
        showToast(err instanceof Error ? err.message : "Failed to create item", "error");
        throw err;
      }
    },
    [endpoint, showToast],
  );

  const update = useCallback(
    async (id: string, payload: Record<string, unknown>, itemKey: string) => {
      const previous = items;
      setItems((prev) => prev.map((item) => (item.id === id ? { ...item, ...payload } : item)));
      try {
        const res = await fetch(`${endpoint}/${id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.message || "Failed to update item");
        setItems((prev) => prev.map((item) => (item.id === id ? data[itemKey] : item)));
        showToast("Updated successfully.");
        return data[itemKey] as T;
      } catch (err) {
        setItems(previous);
        showToast(err instanceof Error ? err.message : "Failed to update item", "error");
        throw err;
      }
    },
    [endpoint, items, showToast],
  );

  const remove = useCallback(
    async (id: string) => {
      const previous = items;
      setItems((prev) => prev.filter((item) => item.id !== id));
      try {
        const res = await fetch(`${endpoint}/${id}`, { method: "DELETE" });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.message || "Failed to delete item");
        showToast("Deleted successfully.");
      } catch (err) {
        setItems(previous);
        showToast(err instanceof Error ? err.message : "Failed to delete item", "error");
        throw err;
      }
    },
    [endpoint, items, showToast],
  );

  return { items, setItems, loading, error, reload: load, create, update, remove };
}
