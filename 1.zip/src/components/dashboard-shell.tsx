"use client";

import { useState, type ReactNode } from "react";
import type { SessionUser } from "@/lib/auth";
import { Sidebar } from "@/components/sidebar";
import { ToastProvider } from "@/components/toast";

export function DashboardShell({ user, children }: { user: SessionUser; children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <ToastProvider>
      <div className="flex min-h-screen bg-slate-100">
        <Sidebar user={user} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
        <div className="flex min-h-screen flex-1 flex-col lg:pl-0">
          <header className="sticky top-0 z-30 flex items-center justify-between border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur lg:hidden">
            <button
              onClick={() => setMobileOpen(true)}
              className="rounded-lg border border-slate-200 p-2 text-slate-600"
              aria-label="Open menu"
            >
              ☰
            </button>
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-blue-600 text-white">🩺</span>
              MEDORA
            </div>
            <span className="w-9" />
          </header>
          <main className="flex-1 px-4 py-6 sm:px-6 lg:px-10 lg:py-8">{children}</main>
        </div>
      </div>
    </ToastProvider>
  );
}
