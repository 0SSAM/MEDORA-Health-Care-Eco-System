"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Avatar, Badge, Button, Card, Field, Input } from "@/components/ui";
import { useToast } from "@/components/toast";
import type { SessionUser } from "@/lib/auth";
import { roleColors, roleLabels } from "@/lib/format";

export function ProfileForm({ user }: { user: SessionUser }) {
  const router = useRouter();
  const { showToast } = useToast();
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone ?? "");
  const [specialty, setSpecialty] = useState(user.specialty ?? "");
  const [savingProfile, setSavingProfile] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [savingPassword, setSavingPassword] = useState(false);

  async function handleProfileSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const res = await fetch("/api/auth/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone, specialty }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.message || "Failed to update profile");
      showToast("Profile updated successfully.");
      router.refresh();
    } catch (err) {
      showToast(err instanceof Error ? err.message : "Failed to update profile", "error");
    } finally {
      setSavingProfile(false);
    }
  }

  async function handlePasswordSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSavingPassword(true);
    try {
      const res = await fetch("/api/auth/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.message || "Failed to update password");
      showToast("Password updated successfully.");
      setCurrentPassword("");
      setNewPassword("");
    } catch (err) {
      showToast(err instanceof Error ? err.message : "Failed to update password", "error");
    } finally {
      setSavingPassword(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <Card className="p-6 lg:col-span-1">
        <div className="flex flex-col items-center text-center">
          <Avatar name={user.name} color={user.avatarColor} size={72} />
          <h2 className="mt-4 text-lg font-semibold text-slate-900">{user.name}</h2>
          <p className="text-sm text-slate-400">{user.email}</p>
          <div className="mt-3">
            <Badge color={roleColors[user.role]}>{roleLabels[user.role]}</Badge>
          </div>
        </div>
      </Card>

      <div className="space-y-6 lg:col-span-2">
        <Card className="p-6">
          <h3 className="text-sm font-semibold text-slate-800">Personal information</h3>
          <form onSubmit={handleProfileSubmit} className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Full name">
              <Input required value={name} onChange={(e) => setName(e.target.value)} />
            </Field>
            <Field label="Email">
              <Input value={user.email} disabled className="bg-slate-50 text-slate-400" />
            </Field>
            <Field label="Phone">
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
            </Field>
            <Field label="Specialty / Department">
              <Input value={specialty} onChange={(e) => setSpecialty(e.target.value)} />
            </Field>
            <div className="sm:col-span-2">
              <Button type="submit" disabled={savingProfile}>
                {savingProfile ? "Saving…" : "Save changes"}
              </Button>
            </div>
          </form>
        </Card>

        <Card className="p-6">
          <h3 className="text-sm font-semibold text-slate-800">Change password</h3>
          <form onSubmit={handlePasswordSubmit} className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Current password">
              <Input
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
              />
            </Field>
            <Field label="New password" hint="Minimum 6 characters.">
              <Input type="password" required minLength={6} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            </Field>
            <div className="sm:col-span-2">
              <Button type="submit" disabled={savingPassword}>
                {savingPassword ? "Updating…" : "Update password"}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
