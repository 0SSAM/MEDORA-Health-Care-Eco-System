"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import type { SessionUser } from "@/lib/auth";
import { Avatar } from "@/components/ui";

const navItems = [
  { href: "/dashboard", label: "Overview", icon: "📊", roles: null },
  { href: "/dashboard/patients", label: "Patients", icon: "🧑‍⚕️", roles: null },
  { href: "/dashboard/appointments", label: "Appointments", icon: "📅", roles: null },
  { href: "/dashboard/records", label: "Medical Records", icon: "📋", roles: null },
  { href: "/dashboard/prescriptions", label: "Prescriptions", icon: "💊", roles: null },
  { href: "/dashboard/pharmacy", label: "Pharmacy Inventory", icon: "🏥", roles: null },
  { href: "/dashboard/billing", label: "Billing", icon: "💳", roles: null },
  { href: "/dashboard/team", label: "Team", icon: "👥", roles: ["admin"] as const },
];

const roleLabels: Record<string, string> = {
  admin: "Administrator",
  doctor: "Doctor",
  nurse: "Nurse",
  receptionist: "Receptionist",
  pharmacist: "Pharmacist",
};

export function Sidebar({ user, mobileOpen, onClose }: { user: SessionUser; mobileOpen: boolean; onClose: () => void }) {
  const pathname = usePathname();
  const router = useRouter();
  const [loggingOut, setLoggingOut] = useState(false);

  async function handleLogout() {
    setLoggingOut(true);
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  const items = navItems.filter((item) => !item.roles || item.roles.includes(user.role as "admin"));

  return (
    <>
      {mobileOpen ? (
        <div className="fixed inset-0 z-40 bg-slate-900/40 lg:hidden" onClick={onClose} />
      ) : null}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-72 flex-col border-r border-slate-200 bg-white transition-transform duration-200 lg:static lg:z-0 lg:translate-x-0 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center gap-2 px-6 py-6">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-blue-600 text-lg text-white">🩺</span>
          <div>
            <p className="text-base font-bold leading-none text-slate-900">MEDORA</p>
            <p className="mt-1 text-[11px] font-medium uppercase tracking-wide text-slate-400">Care Ecosystem</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3">
          {items.map((item) => {
            const active = item.href === "/dashboard" ? pathname === item.href : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onClose}
                className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                  active
                    ? "bg-blue-50 text-blue-700"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                }`}
              >
                <span className="text-base">{item.icon}</span>
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-slate-100 p-4">
          <Link
            href="/dashboard/profile"
            onClick={onClose}
            className="flex items-center gap-3 rounded-xl p-2 transition hover:bg-slate-50"
          >
            <Avatar name={user.name} color={user.avatarColor} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-slate-800">{user.name}</p>
              <p className="truncate text-xs text-slate-400">{roleLabels[user.role] ?? user.role}</p>
            </div>
          </Link>
          <button
            onClick={handleLogout}
            disabled={loggingOut}
            className="mt-2 flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-50 disabled:opacity-60"
          >
            {loggingOut ? "Signing out…" : "Sign out"}
          </button>
        </div>
      </aside>
    </>
  );
}
