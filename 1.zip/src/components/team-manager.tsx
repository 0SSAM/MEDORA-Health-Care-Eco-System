"use client";

import { useMemo, useState } from "react";
import {
  Avatar,
  Badge,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  Select,
  TableSkeleton,
} from "@/components/ui";
import { useCrud } from "@/lib/use-crud";
import { roleColors, roleLabels } from "@/lib/format";

type Staff = {
  id: string;
  name: string;
  email: string;
  role: "admin" | "doctor" | "nurse" | "receptionist" | "pharmacist";
  specialty: string | null;
  phone: string | null;
  avatarColor: string;
  status: "active" | "inactive";
  createdAt: string;
};

const emptyForm = {
  name: "",
  email: "",
  password: "",
  role: "doctor" as Staff["role"],
  specialty: "",
  phone: "",
  status: "active" as Staff["status"],
};

export function TeamManager() {
  const { items: staff, loading, error, create, update, remove } = useCrud<Staff>("/api/staff", "staff");
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Staff | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Staff | null>(null);

  const filtered = useMemo(() => {
    return staff.filter((s) => {
      const matchesSearch = !search || `${s.name} ${s.email}`.toLowerCase().includes(search.toLowerCase());
      const matchesRole = roleFilter === "all" || s.role === roleFilter;
      return matchesSearch && matchesRole;
    });
  }, [staff, search, roleFilter]);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(member: Staff) {
    setEditing(member);
    setForm({
      name: member.name,
      email: member.email,
      password: "",
      role: member.role,
      specialty: member.specialty ?? "",
      phone: member.phone ?? "",
      status: member.status,
    });
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        const payload: Record<string, unknown> = {
          name: form.name,
          email: form.email,
          role: form.role,
          specialty: form.specialty || null,
          phone: form.phone || null,
          status: form.status,
        };
        if (form.password) payload.password = form.password;
        await update(editing.id, payload, "staff");
      } else {
        await create(
          {
            name: form.name,
            email: form.email,
            password: form.password,
            role: form.role,
            specialty: form.specialty || null,
            phone: form.phone || null,
            status: form.status,
          },
          "staff",
          { avatarColor: "#2563eb", createdAt: new Date().toISOString() },
        );
      }
      setModalOpen(false);
    } catch {
      // toast shown
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    await remove(deleteTarget.id).catch(() => {});
    setDeleteTarget(null);
  }

  return (
    <div>
      <Card className="mb-4 flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <Input placeholder="Search team members…" value={search} onChange={(e) => setSearch(e.target.value)} className="sm:max-w-xs" />
        <Select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} className="sm:max-w-[180px]">
          <option value="all">All roles</option>
          <option value="admin">Admin</option>
          <option value="doctor">Doctor</option>
          <option value="nurse">Nurse</option>
          <option value="receptionist">Receptionist</option>
          <option value="pharmacist">Pharmacist</option>
        </Select>
        <div className="sm:ml-auto">
          <Button onClick={openCreate}>+ Add Team Member</Button>
        </div>
      </Card>

      <Card className="overflow-hidden">
        {loading ? (
          <TableSkeleton rows={6} cols={5} />
        ) : error ? (
          <EmptyState icon="⚠️" title="Something went wrong" description={error} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="👥"
            title={staff.length === 0 ? "No team members yet" : "No matching team members"}
            description={staff.length === 0 ? "Invite your first team member to get started." : "Try a different search or filter."}
            action={staff.length === 0 ? <Button onClick={openCreate}>+ Add Team Member</Button> : undefined}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                  <th className="px-5 py-3 font-medium">Name</th>
                  <th className="px-5 py-3 font-medium">Role</th>
                  <th className="px-5 py-3 font-medium">Contact</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((member) => {
                  const pending = member.id.startsWith("temp-");
                  return (
                    <tr key={member.id} className={`border-b border-slate-50 last:border-0 hover:bg-slate-50/60 ${pending ? "opacity-60" : ""}`}>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-3">
                          <Avatar name={member.name} color={member.avatarColor} size={34} />
                          <div className="min-w-0">
                            <p className="truncate font-semibold text-slate-800">{member.name}</p>
                            <p className="text-xs text-slate-400">{member.specialty ?? "—"}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3">
                        <Badge color={roleColors[member.role]}>{roleLabels[member.role]}</Badge>
                      </td>
                      <td className="px-5 py-3 text-slate-600">
                        <p>{member.email}</p>
                        <p className="text-xs text-slate-400">{member.phone ?? "—"}</p>
                      </td>
                      <td className="px-5 py-3">
                        <Badge color={member.status === "active" ? "green" : "slate"}>{member.status}</Badge>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="secondary" onClick={() => openEdit(member)} disabled={pending}>
                            Edit
                          </Button>
                          <Button size="sm" variant="danger" onClick={() => setDeleteTarget(member)} disabled={pending}>
                            Remove
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Team Member" : "Add Team Member"} wide>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Full name">
            <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </Field>
          <Field label="Email">
            <Input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </Field>
          <Field label={editing ? "New password (optional)" : "Password"} hint={editing ? "Leave blank to keep the current password." : "Minimum 6 characters."}>
            <Input
              type="password"
              required={!editing}
              minLength={editing ? undefined : 6}
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
          </Field>
          <Field label="Role">
            <Select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as Staff["role"] })}>
              <option value="admin">Admin</option>
              <option value="doctor">Doctor</option>
              <option value="nurse">Nurse</option>
              <option value="receptionist">Receptionist</option>
              <option value="pharmacist">Pharmacist</option>
            </Select>
          </Field>
          <Field label="Specialty / Department">
            <Input value={form.specialty} onChange={(e) => setForm({ ...form, specialty: e.target.value })} />
          </Field>
          <Field label="Phone">
            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </Field>
          <Field label="Status">
            <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Staff["status"] })}>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </Select>
          </Field>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : editing ? "Save changes" : "Add team member"}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Remove team member"
        description={`Remove ${deleteTarget?.name} from the team? They will lose access immediately.`}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
