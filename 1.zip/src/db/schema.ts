import {
  boolean,
  date,
  integer,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export const userRoleEnum = pgEnum("user_role", [
  "admin",
  "doctor",
  "nurse",
  "receptionist",
  "pharmacist",
]);

export const staffStatusEnum = pgEnum("staff_status", ["active", "inactive"]);

export const genderEnum = pgEnum("gender", ["male", "female", "other"]);

export const patientStatusEnum = pgEnum("patient_status", [
  "active",
  "inactive",
  "critical",
]);

export const appointmentTypeEnum = pgEnum("appointment_type", [
  "checkup",
  "follow_up",
  "consultation",
  "emergency",
  "surgery",
  "vaccination",
]);

export const appointmentStatusEnum = pgEnum("appointment_status", [
  "scheduled",
  "completed",
  "cancelled",
  "no_show",
]);

export const prescriptionStatusEnum = pgEnum("prescription_status", [
  "active",
  "completed",
  "cancelled",
]);

export const invoiceStatusEnum = pgEnum("invoice_status", [
  "paid",
  "pending",
  "overdue",
  "cancelled",
]);

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: userRoleEnum("role").notNull().default("doctor"),
  specialty: text("specialty"),
  phone: text("phone"),
  avatarColor: text("avatar_color").notNull().default("#2563eb"),
  status: staffStatusEnum("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const patients = pgTable("patients", {
  id: uuid("id").primaryKey().defaultRandom(),
  mrn: text("mrn").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  dob: date("dob"),
  gender: genderEnum("gender").notNull().default("other"),
  phone: text("phone"),
  email: text("email"),
  address: text("address"),
  bloodType: text("blood_type"),
  allergies: text("allergies"),
  status: patientStatusEnum("status").notNull().default("active"),
  assignedDoctorId: uuid("assigned_doctor_id").references(() => users.id, {
    onDelete: "set null",
  }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const appointments = pgTable("appointments", {
  id: uuid("id").primaryKey().defaultRandom(),
  patientId: uuid("patient_id")
    .notNull()
    .references(() => patients.id, { onDelete: "cascade" }),
  doctorId: uuid("doctor_id").references(() => users.id, { onDelete: "set null" }),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  durationMinutes: integer("duration_minutes").notNull().default(30),
  type: appointmentTypeEnum("type").notNull().default("checkup"),
  status: appointmentStatusEnum("status").notNull().default("scheduled"),
  reason: text("reason"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const medicalRecords = pgTable("medical_records", {
  id: uuid("id").primaryKey().defaultRandom(),
  patientId: uuid("patient_id")
    .notNull()
    .references(() => patients.id, { onDelete: "cascade" }),
  doctorId: uuid("doctor_id").references(() => users.id, { onDelete: "set null" }),
  visitDate: timestamp("visit_date", { withTimezone: true }).notNull().defaultNow(),
  diagnosis: text("diagnosis").notNull(),
  treatment: text("treatment"),
  bloodPressure: text("blood_pressure"),
  heartRate: integer("heart_rate"),
  temperature: numeric("temperature", { precision: 4, scale: 1 }),
  weightKg: numeric("weight_kg", { precision: 5, scale: 1 }),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const medications = pgTable("medications", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  category: text("category").notNull().default("General"),
  stockQuantity: integer("stock_quantity").notNull().default(0),
  unit: text("unit").notNull().default("units"),
  reorderLevel: integer("reorder_level").notNull().default(10),
  pricePerUnit: numeric("price_per_unit", { precision: 10, scale: 2 }).notNull().default("0"),
  expiryDate: date("expiry_date"),
  supplier: text("supplier"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const prescriptions = pgTable("prescriptions", {
  id: uuid("id").primaryKey().defaultRandom(),
  patientId: uuid("patient_id")
    .notNull()
    .references(() => patients.id, { onDelete: "cascade" }),
  doctorId: uuid("doctor_id").references(() => users.id, { onDelete: "set null" }),
  medicationId: uuid("medication_id").references(() => medications.id, {
    onDelete: "set null",
  }),
  medicationName: text("medication_name").notNull(),
  dosage: text("dosage").notNull(),
  frequency: text("frequency").notNull(),
  durationDays: integer("duration_days").notNull().default(7),
  status: prescriptionStatusEnum("status").notNull().default("active"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const invoices = pgTable("invoices", {
  id: uuid("id").primaryKey().defaultRandom(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  patientId: uuid("patient_id")
    .notNull()
    .references(() => patients.id, { onDelete: "cascade" }),
  appointmentId: uuid("appointment_id").references(() => appointments.id, {
    onDelete: "set null",
  }),
  description: text("description").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  status: invoiceStatusEnum("status").notNull().default("pending"),
  issuedDate: date("issued_date").notNull().defaultNow(),
  dueDate: date("due_date"),
  paid: boolean("paid").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
