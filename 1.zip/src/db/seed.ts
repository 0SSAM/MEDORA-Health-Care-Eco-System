import { db } from "@/db";
import {
  appointments,
  invoices,
  medicalRecords,
  medications,
  patients,
  prescriptions,
  users,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { sql } from "drizzle-orm";

function daysFromNow(days: number, hour = 9, minute = 0) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  d.setHours(hour, minute, 0, 0);
  return d;
}

function isoDate(days: number) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export async function seedDatabase() {
  const existing = await db.select({ id: users.id }).from(users).limit(1);
  if (existing.length > 0) {
    return { seeded: false };
  }

  const defaultPassword = await hashPassword("password123");

  const staffSeed = [
    { name: "Amina Haddad", email: "admin@medora.health", role: "admin" as const, specialty: "Platform Administrator", phone: "+1 (415) 555-0110", avatarColor: "#7c3aed" },
    { name: "Dr. Samuel Osei", email: "s.osei@medora.health", role: "doctor" as const, specialty: "Cardiology", phone: "+1 (415) 555-0121", avatarColor: "#2563eb" },
    { name: "Dr. Layla Karimi", email: "l.karimi@medora.health", role: "doctor" as const, specialty: "Pediatrics", phone: "+1 (415) 555-0132", avatarColor: "#0891b2" },
    { name: "Dr. Marco Rossi", email: "m.rossi@medora.health", role: "doctor" as const, specialty: "Orthopedics", phone: "+1 (415) 555-0143", avatarColor: "#059669" },
    { name: "Nadia Ferreira", email: "n.ferreira@medora.health", role: "nurse" as const, specialty: "General Nursing", phone: "+1 (415) 555-0154", avatarColor: "#d97706" },
    { name: "Tomás Almeida", email: "t.almeida@medora.health", role: "nurse" as const, specialty: "ICU Nursing", phone: "+1 (415) 555-0165", avatarColor: "#ea580c" },
    { name: "Grace Mwangi", email: "g.mwangi@medora.health", role: "receptionist" as const, specialty: "Front Desk", phone: "+1 (415) 555-0176", avatarColor: "#db2777" },
    { name: "Farid Belkacem", email: "f.belkacem@medora.health", role: "pharmacist" as const, specialty: "Clinical Pharmacy", phone: "+1 (415) 555-0187", avatarColor: "#4f46e5" },
  ];

  const insertedStaff = await db
    .insert(users)
    .values(staffSeed.map((s) => ({ ...s, passwordHash: defaultPassword })))
    .returning();

  const admin = insertedStaff.find((u) => u.role === "admin")!;
  const drOsei = insertedStaff.find((u) => u.email === "s.osei@medora.health")!;
  const drKarimi = insertedStaff.find((u) => u.email === "l.karimi@medora.health")!;
  const drRossi = insertedStaff.find((u) => u.email === "m.rossi@medora.health")!;
  const nurseFerreira = insertedStaff.find((u) => u.email === "n.ferreira@medora.health")!;
  void admin;
  void nurseFerreira;

  const patientSeed = [
    { mrn: "MED-10001", firstName: "Olivia", lastName: "Bennett", dob: "1988-04-12", gender: "female" as const, phone: "+1 (628) 555-2001", email: "olivia.bennett@example.com", address: "412 Maple Ave, San Francisco, CA", bloodType: "O+", allergies: "Penicillin", status: "active" as const, assignedDoctorId: drOsei.id },
    { mrn: "MED-10002", firstName: "Ethan", lastName: "Carter", dob: "1975-11-02", gender: "male" as const, phone: "+1 (628) 555-2002", email: "ethan.carter@example.com", address: "88 Sunset Blvd, San Francisco, CA", bloodType: "A-", allergies: "None known", status: "critical" as const, assignedDoctorId: drOsei.id },
    { mrn: "MED-10003", firstName: "Sofia", lastName: "Nguyen", dob: "2016-06-23", gender: "female" as const, phone: "+1 (628) 555-2003", email: "sofia.parent@example.com", address: "231 Oakwood Dr, Oakland, CA", bloodType: "B+", allergies: "Peanuts", status: "active" as const, assignedDoctorId: drKarimi.id },
    { mrn: "MED-10004", firstName: "Liam", lastName: "Johnson", dob: "1995-01-30", gender: "male" as const, phone: "+1 (628) 555-2004", email: "liam.johnson@example.com", address: "77 Pine St, Berkeley, CA", bloodType: "AB+", allergies: "Latex", status: "active" as const, assignedDoctorId: drRossi.id },
    { mrn: "MED-10005", firstName: "Ava", lastName: "Martinez", dob: "2001-09-18", gender: "female" as const, phone: "+1 (628) 555-2005", email: "ava.martinez@example.com", address: "9 Harbor View, San Mateo, CA", bloodType: "O-", allergies: "Sulfa drugs", status: "inactive" as const, assignedDoctorId: drKarimi.id },
    { mrn: "MED-10006", firstName: "Noah", lastName: "Thompson", dob: "1962-03-05", gender: "male" as const, phone: "+1 (628) 555-2006", email: "noah.thompson@example.com", address: "1500 Ridge Rd, San Jose, CA", bloodType: "A+", allergies: "None known", status: "critical" as const, assignedDoctorId: drOsei.id },
    { mrn: "MED-10007", firstName: "Isabella", lastName: "Garcia", dob: "1990-07-14", gender: "female" as const, phone: "+1 (628) 555-2007", email: "isabella.garcia@example.com", address: "64 Elm St, Palo Alto, CA", bloodType: "B-", allergies: "Aspirin", status: "active" as const, assignedDoctorId: drRossi.id },
    { mrn: "MED-10008", firstName: "Mason", lastName: "Lee", dob: "2010-12-01", gender: "male" as const, phone: "+1 (628) 555-2008", email: "mason.parent@example.com", address: "310 Birch Ln, Fremont, CA", bloodType: "O+", allergies: "None known", status: "active" as const, assignedDoctorId: drKarimi.id },
    { mrn: "MED-10009", firstName: "Mia", lastName: "Davis", dob: "1983-05-27", gender: "female" as const, phone: "+1 (628) 555-2009", email: "mia.davis@example.com", address: "22 Cedar Ct, Redwood City, CA", bloodType: "A+", allergies: "Shellfish", status: "active" as const, assignedDoctorId: drOsei.id },
    { mrn: "MED-10010", firstName: "James", lastName: "Wilson", dob: "1970-08-09", gender: "male" as const, phone: "+1 (628) 555-2010", email: "james.wilson@example.com", address: "48 Valley Dr, Mountain View, CA", bloodType: "AB-", allergies: "None known", status: "inactive" as const, assignedDoctorId: drRossi.id },
  ];

  const insertedPatients = await db.insert(patients).values(patientSeed).returning();

  const findPatient = (mrn: string) => insertedPatients.find((p) => p.mrn === mrn)!;

  const appointmentSeed = [
    { patientId: findPatient("MED-10001").id, doctorId: drOsei.id, scheduledAt: daysFromNow(1, 9, 30), durationMinutes: 30, type: "follow_up" as const, status: "scheduled" as const, reason: "Blood pressure follow-up" },
    { patientId: findPatient("MED-10002").id, doctorId: drOsei.id, scheduledAt: daysFromNow(0, 14, 0), durationMinutes: 45, type: "emergency" as const, status: "scheduled" as const, reason: "Chest pain evaluation" },
    { patientId: findPatient("MED-10003").id, doctorId: drKarimi.id, scheduledAt: daysFromNow(2, 10, 0), durationMinutes: 20, type: "vaccination" as const, status: "scheduled" as const, reason: "Routine immunization" },
    { patientId: findPatient("MED-10004").id, doctorId: drRossi.id, scheduledAt: daysFromNow(3, 11, 15), durationMinutes: 40, type: "consultation" as const, status: "scheduled" as const, reason: "Knee pain assessment" },
    { patientId: findPatient("MED-10005").id, doctorId: drKarimi.id, scheduledAt: daysFromNow(-2, 9, 0), durationMinutes: 30, type: "checkup" as const, status: "completed" as const, reason: "Annual physical" },
    { patientId: findPatient("MED-10006").id, doctorId: drOsei.id, scheduledAt: daysFromNow(-1, 15, 30), durationMinutes: 60, type: "emergency" as const, status: "completed" as const, reason: "Cardiac arrhythmia monitoring" },
    { patientId: findPatient("MED-10007").id, doctorId: drRossi.id, scheduledAt: daysFromNow(-4, 13, 0), durationMinutes: 30, type: "follow_up" as const, status: "no_show" as const, reason: "Post-surgery follow-up" },
    { patientId: findPatient("MED-10008").id, doctorId: drKarimi.id, scheduledAt: daysFromNow(5, 9, 45), durationMinutes: 20, type: "checkup" as const, status: "scheduled" as const, reason: "Growth check" },
    { patientId: findPatient("MED-10009").id, doctorId: drOsei.id, scheduledAt: daysFromNow(-6, 10, 30), durationMinutes: 30, type: "consultation" as const, status: "cancelled" as const, reason: "Cholesterol review" },
    { patientId: findPatient("MED-10010").id, doctorId: drRossi.id, scheduledAt: daysFromNow(4, 16, 0), durationMinutes: 30, type: "surgery" as const, status: "scheduled" as const, reason: "Pre-op consultation" },
  ];

  await db.insert(appointments).values(appointmentSeed);

  const medicalRecordSeed = [
    { patientId: findPatient("MED-10001").id, doctorId: drOsei.id, visitDate: daysFromNow(-30, 9, 0), diagnosis: "Mild hypertension", treatment: "Prescribed low-sodium diet and Lisinopril", bloodPressure: "138/89", heartRate: 78, temperature: "98.4", weightKg: "68.2", notes: "Recommend follow-up in 4 weeks." },
    { patientId: findPatient("MED-10002").id, doctorId: drOsei.id, visitDate: daysFromNow(-3, 14, 0), diagnosis: "Unstable angina", treatment: "Started on nitrates, scheduled stress test", bloodPressure: "150/95", heartRate: 102, temperature: "99.1", weightKg: "82.5", notes: "Patient advised to seek ER care if pain recurs." },
    { patientId: findPatient("MED-10003").id, doctorId: drKarimi.id, visitDate: daysFromNow(-14, 10, 0), diagnosis: "Seasonal allergic rhinitis", treatment: "Antihistamine prescribed", bloodPressure: "100/65", heartRate: 90, temperature: "98.6", weightKg: "22.0", notes: "Symptoms improving." },
    { patientId: findPatient("MED-10006").id, doctorId: drOsei.id, visitDate: daysFromNow(-1, 15, 30), diagnosis: "Atrial fibrillation", treatment: "Beta-blocker adjusted, anticoagulation continued", bloodPressure: "128/82", heartRate: 110, temperature: "98.2", weightKg: "79.4", notes: "Referred to cardiology for ablation evaluation." },
    { patientId: findPatient("MED-10007").id, doctorId: drRossi.id, visitDate: daysFromNow(-20, 13, 0), diagnosis: "Post ACL reconstruction recovery", treatment: "Physical therapy plan continued", bloodPressure: "118/76", heartRate: 72, temperature: "98.5", weightKg: "61.0", notes: "Range of motion improving steadily." },
    { patientId: findPatient("MED-10009").id, doctorId: drOsei.id, visitDate: daysFromNow(-8, 10, 30), diagnosis: "Borderline hyperlipidemia", treatment: "Statin therapy initiated", bloodPressure: "122/80", heartRate: 74, temperature: "98.3", weightKg: "70.1", notes: "Diet and exercise counseling provided." },
  ];

  await db.insert(medicalRecords).values(medicalRecordSeed);

  const medicationSeed = [
    { name: "Amoxicillin 500mg", category: "Antibiotic", stockQuantity: 420, unit: "capsules", reorderLevel: 100, pricePerUnit: "0.35", expiryDate: isoDate(210), supplier: "PharmaCore Distribution" },
    { name: "Lisinopril 10mg", category: "Cardiovascular", stockQuantity: 260, unit: "tablets", reorderLevel: 80, pricePerUnit: "0.22", expiryDate: isoDate(340), supplier: "MedSource Inc." },
    { name: "Metformin 500mg", category: "Endocrine", stockQuantity: 55, unit: "tablets", reorderLevel: 100, pricePerUnit: "0.18", expiryDate: isoDate(150), supplier: "MedSource Inc." },
    { name: "Atorvastatin 20mg", category: "Cardiovascular", stockQuantity: 180, unit: "tablets", reorderLevel: 60, pricePerUnit: "0.41", expiryDate: isoDate(400), supplier: "PharmaCore Distribution" },
    { name: "Salbutamol Inhaler", category: "Respiratory", stockQuantity: 40, unit: "inhalers", reorderLevel: 25, pricePerUnit: "6.75", expiryDate: isoDate(500), supplier: "RespiCare Ltd." },
    { name: "Ibuprofen 200mg", category: "Analgesic", stockQuantity: 18, unit: "tablets", reorderLevel: 150, pricePerUnit: "0.09", expiryDate: isoDate(280), supplier: "MedSource Inc." },
    { name: "Cetirizine 10mg", category: "Antihistamine", stockQuantity: 300, unit: "tablets", reorderLevel: 90, pricePerUnit: "0.14", expiryDate: isoDate(600), supplier: "PharmaCore Distribution" },
    { name: "Insulin Glargine", category: "Endocrine", stockQuantity: 24, unit: "pens", reorderLevel: 20, pricePerUnit: "32.50", expiryDate: isoDate(120), supplier: "BioLife Pharma" },
    { name: "Amlodipine 5mg", category: "Cardiovascular", stockQuantity: 210, unit: "tablets", reorderLevel: 70, pricePerUnit: "0.19", expiryDate: isoDate(365), supplier: "MedSource Inc." },
    { name: "Azithromycin 250mg", category: "Antibiotic", stockQuantity: 8, unit: "capsules", reorderLevel: 60, pricePerUnit: "0.95", expiryDate: isoDate(95), supplier: "PharmaCore Distribution" },
  ];

  const insertedMedications = await db.insert(medications).values(medicationSeed).returning();
  const findMed = (name: string) => insertedMedications.find((m) => m.name === name)!;

  const prescriptionSeed = [
    { patientId: findPatient("MED-10001").id, doctorId: drOsei.id, medicationId: findMed("Lisinopril 10mg").id, medicationName: "Lisinopril 10mg", dosage: "10mg", frequency: "Once daily", durationDays: 90, status: "active" as const, notes: "Monitor blood pressure weekly." },
    { patientId: findPatient("MED-10002").id, doctorId: drOsei.id, medicationId: findMed("Atorvastatin 20mg").id, medicationName: "Atorvastatin 20mg", dosage: "20mg", frequency: "Once nightly", durationDays: 180, status: "active" as const, notes: "" },
    { patientId: findPatient("MED-10003").id, doctorId: drKarimi.id, medicationId: findMed("Cetirizine 10mg").id, medicationName: "Cetirizine 10mg", dosage: "5ml", frequency: "Once daily", durationDays: 14, status: "active" as const, notes: "Pediatric dose." },
    { patientId: findPatient("MED-10004").id, doctorId: drRossi.id, medicationId: findMed("Ibuprofen 200mg").id, medicationName: "Ibuprofen 200mg", dosage: "400mg", frequency: "Every 8 hours as needed", durationDays: 10, status: "active" as const, notes: "Take with food." },
    { patientId: findPatient("MED-10006").id, doctorId: drOsei.id, medicationId: findMed("Amlodipine 5mg").id, medicationName: "Amlodipine 5mg", dosage: "5mg", frequency: "Once daily", durationDays: 90, status: "active" as const, notes: "" },
    { patientId: findPatient("MED-10007").id, doctorId: drRossi.id, medicationId: findMed("Ibuprofen 200mg").id, medicationName: "Ibuprofen 200mg", dosage: "200mg", frequency: "Twice daily", durationDays: 7, status: "completed" as const, notes: "Course completed without complications." },
    { patientId: findPatient("MED-10009").id, doctorId: drOsei.id, medicationId: findMed("Atorvastatin 20mg").id, medicationName: "Atorvastatin 20mg", dosage: "20mg", frequency: "Once nightly", durationDays: 120, status: "active" as const, notes: "" },
    { patientId: findPatient("MED-10005").id, doctorId: drKarimi.id, medicationId: findMed("Azithromycin 250mg").id, medicationName: "Azithromycin 250mg", dosage: "250mg", frequency: "Once daily", durationDays: 5, status: "cancelled" as const, notes: "Discontinued due to allergy concern." },
  ];

  await db.insert(prescriptions).values(prescriptionSeed);

  const insertedAppointments = await db.select().from(appointments);
  const findAppt = (patientId: string) =>
    insertedAppointments.find((a) => a.patientId === patientId);

  const invoiceSeed = [
    { invoiceNumber: "INV-2024-0001", patientId: findPatient("MED-10001").id, appointmentId: findAppt(findPatient("MED-10001").id)?.id, description: "Cardiology follow-up consultation", amount: "180.00", status: "paid" as const, issuedDate: isoDate(-10), dueDate: isoDate(4), paid: true },
    { invoiceNumber: "INV-2024-0002", patientId: findPatient("MED-10002").id, appointmentId: findAppt(findPatient("MED-10002").id)?.id, description: "Emergency evaluation and ECG", amount: "420.50", status: "pending" as const, issuedDate: isoDate(-1), dueDate: isoDate(13), paid: false },
    { invoiceNumber: "INV-2024-0003", patientId: findPatient("MED-10003").id, appointmentId: findAppt(findPatient("MED-10003").id)?.id, description: "Pediatric vaccination", amount: "95.00", status: "paid" as const, issuedDate: isoDate(-5), dueDate: isoDate(9), paid: true },
    { invoiceNumber: "INV-2024-0004", patientId: findPatient("MED-10004").id, description: "Orthopedic imaging (MRI knee)", amount: "650.00", status: "overdue" as const, issuedDate: isoDate(-40), dueDate: isoDate(-10), paid: false },
    { invoiceNumber: "INV-2024-0005", patientId: findPatient("MED-10005").id, description: "Annual physical examination", amount: "150.00", status: "paid" as const, issuedDate: isoDate(-15), dueDate: isoDate(-1), paid: true },
    { invoiceNumber: "INV-2024-0006", patientId: findPatient("MED-10006").id, description: "Cardiac monitoring and arrhythmia panel", amount: "780.25", status: "pending" as const, issuedDate: isoDate(-2), dueDate: isoDate(12), paid: false },
    { invoiceNumber: "INV-2024-0007", patientId: findPatient("MED-10007").id, description: "Physical therapy session bundle", amount: "320.00", status: "overdue" as const, issuedDate: isoDate(-35), dueDate: isoDate(-5), paid: false },
    { invoiceNumber: "INV-2024-0008", patientId: findPatient("MED-10009").id, description: "Lipid panel and consultation", amount: "210.00", status: "cancelled" as const, issuedDate: isoDate(-20), dueDate: isoDate(-6), paid: false },
    { invoiceNumber: "INV-2024-0009", patientId: findPatient("MED-10010").id, description: "Pre-operative assessment", amount: "275.00", status: "pending" as const, issuedDate: isoDate(0), dueDate: isoDate(14), paid: false },
  ];

  await db.insert(invoices).values(invoiceSeed);

  return { seeded: true };
}

export async function ensureSeeded() {
  try {
    await db.execute(sql`select 1`);
    return await seedDatabase();
  } catch (error) {
    console.error("Seeding skipped due to error:", error);
    return { seeded: false, error: true };
  }
}
