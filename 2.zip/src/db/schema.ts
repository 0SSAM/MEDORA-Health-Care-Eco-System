import {
  boolean,
  date,
  integer,
  numeric,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export type UserRole =
  | "admin"
  | "doctor"
  | "nurse"
  | "pharmacist"
  | "billing"
  | "front_desk";

export type PatientStatus = "active" | "recovering" | "critical" | "inactive";
export type StaffStatus = "on_duty" | "available" | "on_leave" | "off_duty";
export type AppointmentStatus =
  | "scheduled"
  | "confirmed"
  | "completed"
  | "cancelled"
  | "no_show";
export type PrescriptionStatus =
  | "pending"
  | "active"
  | "completed"
  | "cancelled";
export type InvoiceStatus = "draft" | "pending" | "paid" | "overdue" | "void";
export type ClaimStatus =
  | "submitted"
  | "under_review"
  | "approved"
  | "rejected"
  | "paid";

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").$type<UserRole>().notNull().default("front_desk"),
  department: text("department").notNull().default("General"),
  phone: text("phone").notNull().default(""),
  isActive: boolean("is_active").notNull().default(true),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const staff = pgTable("staff", {
  id: uuid("id").defaultRandom().primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().default(""),
  phone: text("phone").notNull().default(""),
  title: text("title").notNull().default("Clinician"),
  department: text("department").notNull().default("General Medicine"),
  specialty: text("specialty").notNull().default("General"),
  licenseNumber: text("license_number").notNull().default(""),
  shift: text("shift").notNull().default("Morning"),
  status: text("status").$type<StaffStatus>().notNull().default("available"),
  rating: numeric("rating", { precision: 3, scale: 2 }).notNull().default("4.5"),
  patientsAssigned: integer("patients_assigned").notNull().default(0),
  hireDate: date("hire_date").notNull().default("2024-01-01"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const patients = pgTable("patients", {
  id: uuid("id").defaultRandom().primaryKey(),
  mrn: text("mrn").notNull().default(""),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().default(""),
  phone: text("phone").notNull().default(""),
  gender: text("gender").notNull().default("female"),
  dateOfBirth: date("date_of_birth").notNull().default("1990-01-01"),
  bloodType: text("blood_type").notNull().default("O+"),
  city: text("city").notNull().default("Riyadh"),
  address: text("address").notNull().default(""),
  insuranceProvider: text("insurance_provider").notNull().default("Self-pay"),
  insuranceNumber: text("insurance_number").notNull().default(""),
  allergies: text("allergies").notNull().default("None recorded"),
  conditions: text("conditions").notNull().default("None recorded"),
  status: text("status").$type<PatientStatus>().notNull().default("active"),
  riskLevel: text("risk_level").notNull().default("low"),
  primaryStaffId: uuid("primary_staff_id"),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const appointments = pgTable("appointments", {
  id: uuid("id").defaultRandom().primaryKey(),
  patientId: uuid("patient_id").notNull(),
  staffId: uuid("staff_id"),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  durationMinutes: integer("duration_minutes").notNull().default(30),
  type: text("type").notNull().default("consultation"),
  status: text("status")
    .$type<AppointmentStatus>()
    .notNull()
    .default("scheduled"),
  reason: text("reason").notNull().default("General consultation"),
  room: text("room").notNull().default("OPD-1"),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const medications = pgTable("medications", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull().default("General"),
  form: text("form").notNull().default("tablet"),
  strength: text("strength").notNull().default("500mg"),
  manufacturer: text("manufacturer").notNull().default("Medora Labs"),
  batchNumber: text("batch_number").notNull().default(""),
  supplier: text("supplier").notNull().default("Medora Supply Co."),
  stock: integer("stock").notNull().default(0),
  reorderLevel: integer("reorder_level").notNull().default(40),
  unitPrice: numeric("unit_price", { precision: 10, scale: 2 })
    .notNull()
    .default("0"),
  expiryDate: date("expiry_date").notNull().default("2027-01-01"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const prescriptions = pgTable("prescriptions", {
  id: uuid("id").defaultRandom().primaryKey(),
  patientId: uuid("patient_id").notNull(),
  staffId: uuid("staff_id"),
  medicationId: uuid("medication_id"),
  dosage: text("dosage").notNull().default("1 tablet"),
  frequency: text("frequency").notNull().default("Twice daily"),
  durationDays: integer("duration_days").notNull().default(7),
  refills: integer("refills").notNull().default(0),
  status: text("status")
    .$type<PrescriptionStatus>()
    .notNull()
    .default("pending"),
  issuedAt: timestamp("issued_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  notes: text("notes").notNull().default(""),
});

export const invoices = pgTable("invoices", {
  id: uuid("id").defaultRandom().primaryKey(),
  invoiceNumber: text("invoice_number").notNull().default(""),
  patientId: uuid("patient_id").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull().default("0"),
  insuranceCovered: numeric("insurance_covered", { precision: 12, scale: 2 })
    .notNull()
    .default("0"),
  status: text("status").$type<InvoiceStatus>().notNull().default("pending"),
  itemsSummary: text("items_summary").notNull().default("Consultation"),
  paymentMethod: text("payment_method").notNull().default("card"),
  issuedAt: timestamp("issued_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  dueDate: date("due_date").notNull().default("2026-01-01"),
  paidAt: timestamp("paid_at", { withTimezone: true }),
});

export const insuranceClaims = pgTable("insurance_claims", {
  id: uuid("id").defaultRandom().primaryKey(),
  claimNumber: text("claim_number").notNull().default(""),
  patientId: uuid("patient_id").notNull(),
  provider: text("provider").notNull().default("MedGulf"),
  invoiceId: uuid("invoice_id"),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull().default("0"),
  approvedAmount: numeric("approved_amount", { precision: 12, scale: 2 })
    .notNull()
    .default("0"),
  status: text("status").$type<ClaimStatus>().notNull().default("submitted"),
  submittedAt: timestamp("submitted_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  notes: text("notes").notNull().default(""),
});

export const activityLog = pgTable("activity_log", {
  id: uuid("id").defaultRandom().primaryKey(),
  actorName: text("actor_name").notNull().default("System"),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: text("entity_id").notNull().default(""),
  detail: text("detail").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export type User = typeof users.$inferSelect;
export type Staff = typeof staff.$inferSelect;
export type Patient = typeof patients.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type Medication = typeof medications.$inferSelect;
export type Prescription = typeof prescriptions.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
export type InsuranceClaim = typeof insuranceClaims.$inferSelect;
export type Activity = typeof activityLog.$inferSelect;
