import "server-only";

import { sql } from "drizzle-orm";

import { db } from "@/db";
import {
  activityLog,
  appointments,
  insuranceClaims,
  invoices,
  medications,
  patients,
  prescriptions,
  staff,
  users,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";

function makeRandom(seed: number) {
  let state = seed;
  return () => {
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
}

const rand = makeRandom(20260214);
const pick = <T,>(list: readonly T[]): T => list[Math.floor(rand() * list.length)];
const between = (min: number, max: number) =>
  Math.floor(rand() * (max - min + 1)) + min;

function at(dayOffset: number, hour = 9, minute = 0) {
  const date = new Date();
  date.setHours(hour, minute, 0, 0);
  date.setDate(date.getDate() + dayOffset);
  return date;
}

function isoDate(dayOffset: number) {
  return at(dayOffset, 12).toISOString().slice(0, 10);
}

const DEMO_PASSWORD = "medora123";

const TEAM = [
  {
    name: "Dr. Samir Haddad",
    email: "admin@medora.health",
    role: "admin" as const,
    department: "Executive",
    phone: "+966 55 010 2233",
  },
  {
    name: "Dr. Lina Farouk",
    email: "doctor@medora.health",
    role: "doctor" as const,
    department: "Cardiology",
    phone: "+966 55 441 9087",
  },
  {
    name: "Nora Bishara",
    email: "nurse@medora.health",
    role: "nurse" as const,
    department: "Emergency",
    phone: "+966 56 220 7781",
  },
  {
    name: "Yousef Karim",
    email: "pharmacy@medora.health",
    role: "pharmacist" as const,
    department: "Pharmacy",
    phone: "+966 50 918 4422",
  },
  {
    name: "Dalia Mansour",
    email: "billing@medora.health",
    role: "billing" as const,
    department: "Revenue Cycle",
    phone: "+966 53 771 3390",
  },
  {
    name: "Rami Aziz",
    email: "reception@medora.health",
    role: "front_desk" as const,
    department: "Front Office",
    phone: "+966 54 663 1120",
  },
];

const CLINICIANS = [
  { fullName: "Dr. Lina Farouk", title: "Consultant Cardiologist", department: "Cardiology", specialty: "Interventional Cardiology" },
  { fullName: "Dr. Omar Nasser", title: "Consultant Physician", department: "Internal Medicine", specialty: "Diabetology" },
  { fullName: "Dr. Hala Zaid", title: "Pediatrician", department: "Pediatrics", specialty: "Neonatology" },
  { fullName: "Dr. Karim Suleiman", title: "Orthopedic Surgeon", department: "Orthopedics", specialty: "Sports Injuries" },
  { fullName: "Dr. Maha Rifai", title: "Dermatologist", department: "Dermatology", specialty: "Clinical Dermatology" },
  { fullName: "Dr. Tarek Idris", title: "Neurologist", department: "Neurology", specialty: "Epilepsy Care" },
  { fullName: "Dr. Salma Qasem", title: "Obstetrician", department: "Obstetrics & Gynaecology", specialty: "High-risk Pregnancy" },
  { fullName: "Dr. Fadi Amari", title: "Emergency Physician", department: "Emergency", specialty: "Trauma" },
  { fullName: "Nora Bishara", title: "Charge Nurse", department: "Emergency", specialty: "Triage" },
  { fullName: "Imad Sabri", title: "Pharmacist", department: "Pharmacy", specialty: "Clinical Pharmacy" },
  { fullName: "Rania Doumit", title: "Physiotherapist", department: "Rehabilitation", specialty: "Post-surgical Rehab" },
  { fullName: "Dr. Nabil Haddad", title: "Radiologist", department: "Radiology", specialty: "Musculoskeletal Imaging" },
];

const FIRST_NAMES = ["Amal","Yasmin","Huda","Rasha","Maya","Layla","Dana","Salma","Nour","Farah","Adam","Zaid","Bilal","Hassan","Yusuf","Marwan","Karim","Sami","Talia","Rania","Jana","Omar","Lina","Kamal","Samiya","Nadia","Faisal","Dalia","Rami","Hana"];
const LAST_NAMES = ["Al Harbi","Al Qahtani","Nasser","Haddad","Mansour","Al Otaibi","Khalil","Sabri","Aziz","Farouk","Doumit","Rifai","Zaid","Amari","Idris","Suleiman","Qasem","Bishara","Karim","Saleh"];

const CITIES = ["Riyadh","Jeddah","Dammam","Khobar","Mecca","Medina","Abha","Tabuk"];
const BLOOD = ["O+","O-","A+","A-","B+","B-","AB+","AB-"];
const INSURERS = ["MedGulf","Bupa Arabia","AXA Arabia","Tawuniya","Malath","Self-pay"];
const CONDITIONS = ["Type 2 Diabetes","Hypertension","Asthma","Hypothyroidism","Chronic Migraine","Atrial Fibrillation","Osteoarthritis","None recorded","Anemia","GERD"];
const ALLERGIES = ["Penicillin","None recorded","Peanuts","Sulfa drugs","Latex","Aspirin","Dust mites","Iodine contrast"];
const APPT_TYPES = ["consultation","follow_up","telemedicine","procedure","annual_checkup","lab_review"];
const APPT_STATUS: Array<"scheduled"|"confirmed"|"completed"|"cancelled"|"no_show"> = ["scheduled","confirmed","completed","completed","completed","cancelled","no_show"];
const REASONS = ["Chest discomfort follow-up","Routine antenatal check","Persistent cough","Post-op wound review","Skin rash assessment","Blood pressure management","Migraine consult","Knee pain evaluation","Diabetes review","Annual physical"];
const ROOMS = ["OPD-1","OPD-2","OPD-4","Cardio-A","Tele-Room","ER-Bay-3","Ped-2"];

const MEDS = [
  ["Amoxicillin","Antibiotics","capsule","500mg","GSK",18.5],
  ["Atorvastatin","Cardiovascular","tablet","20mg","Pfizer",24.0],
  ["Metformin","Endocrine","tablet","850mg","Merck",12.75],
  ["Amlodipine","Cardiovascular","tablet","5mg","Novartis",9.4],
  ["Salbutamol Inhaler","Respiratory","inhaler","100mcg","GSK",41.0],
  ["Insulin Glargine","Endocrine","injection","100IU","Sanofi",132.5],
  ["Paracetamol","Analgesics","tablet","500mg","Julphar",3.2],
  ["Ibuprofen","Analgesics","tablet","400mg","Bayer",6.8],
  ["Omeprazole","Gastroenterology","capsule","20mg","Teva",11.9],
  ["Levothyroxine","Endocrine","tablet","50mcg","AbbVie",17.25],
  ["Cetirizine","Antihistamines","tablet","10mg","SPIMACO",5.5],
  ["Azithromycin","Antibiotics","tablet","250mg","Pfizer",28.4],
  ["Enoxaparin","Anticoagulants","injection","40mg","Sanofi",96.0],
  ["Losartan","Cardiovascular","tablet","50mg","MSD",14.6],
  ["Vitamin D3","Supplements","capsule","50000IU","Julphar",22.0],
  ["Prednisolone","Corticosteroids","tablet","5mg","IPCA",8.75],
  ["Metoprolol","Cardiovascular","tablet","25mg","AstraZeneca",16.1],
  ["Ceftriaxone","Antibiotics","injection","1g","Hikma",58.0],
] as const;

const CLAIM_PROVIDERS = ["MedGulf","Bupa Arabia","AXA Arabia","Tawuniya","Malath"];
const CLAIM_STATUS: Array<"submitted"|"under_review"|"approved"|"rejected"|"paid"> = ["submitted","under_review","approved","approved","rejected","paid","paid"];

export async function isSeeded() {
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(users);
  return (row?.count ?? 0) > 0;
}

export async function seedDatabase() {
  const passwordHash = hashPassword(DEMO_PASSWORD);

  await db.insert(users).values(
    TEAM.map((member) => ({
      name: member.name,
      email: member.email,
      passwordHash,
      role: member.role,
      department: member.department,
      phone: member.phone,
    })),
  );

  const staffRows = await db
    .insert(staff)
    .values(
      CLINICIANS.map((person, index) => ({
        ...person,
        email: `${person.fullName.split(" ").slice(-1)[0].toLowerCase()}.care@medora.health`,
        phone: `+966 5${between(0, 9)} ${between(100, 999)} ${between(1000, 9999)}`,
        licenseNumber: `SA-MED-${2015 + (index % 9)}-${between(10000, 99999)}`,
        shift: pick(["Morning", "Evening", "Night", "Rotational"]),
        status: pick(["on_duty", "on_duty", "available", "on_leave", "off_duty"] as const),
        rating: (4 + rand()).toFixed(2),
        patientsAssigned: between(6, 48),
        hireDate: isoDate(-between(200, 2600)),
      })),
    )
    .returning({ id: staff.id, fullName: staff.fullName });

  const patientRows = await db
    .insert(patients)
    .values(
      Array.from({ length: 26 }).map((_, index) => {
        const firstName = FIRST_NAMES[index % FIRST_NAMES.length];
        const lastName = pick(LAST_NAMES);
        const insurer = pick(INSURERS);
        const clinician = pick(staffRows);
        return {
          mrn: `MRN-${104200 + index * 7}`,
          firstName,
          lastName,
          email: `${firstName.toLowerCase()}.${lastName.split(" ").pop()!.toLowerCase()}${index}@mail.com`,
          phone: `+966 5${between(0, 9)} ${between(100, 999)} ${between(1000, 9999)}`,
          gender: pick(["female", "male"]),
          dateOfBirth: isoDate(-between(200, 30000)),
          bloodType: pick(BLOOD),
          city: pick(CITIES),
          address: `${between(1, 320)} ${pick(["Palm", "Olaya", "King Fahd", "Andalus", "Yasmin"])} District`,
          insuranceProvider: insurer,
          insuranceNumber:
            insurer === "Self-pay"
              ? ""
              : `${insurer.slice(0, 3).toUpperCase()}-${between(1000000, 9999999)}`,
          allergies: pick(ALLERGIES),
          conditions: pick(CONDITIONS),
          status: pick(["active", "active", "active", "recovering", "critical", "inactive"] as const),
          riskLevel: pick(["low", "low", "moderate", "high"] as const),
          primaryStaffId: clinician.id,
          notes: pick([
            "Prefers morning appointments, transport via family.",
            "Referred from regional clinic for specialist review.",
            "Enrolled in chronic care management programme.",
            "Requires Arabic-language consent forms.",
          ]),
          createdAt: at(-between(5, 420), 11, 30),
        };
      }),
    )
    .returning({ id: patients.id, firstName: patients.firstName, lastName: patients.lastName });

  await db.insert(medications).values(
    MEDS.map(([name, category, form, strength, manufacturer, unitPrice], index) => {
      const stock = between(0, 420);
      return {
        name: String(name),
        category: String(category),
        form: String(form),
        strength: String(strength),
        manufacturer: String(manufacturer),
        batchNumber: `B-${2026}${String(index + 1).padStart(3, "0")}`,
        supplier: pick(["Medora Supply Co.", "Nupco", "Al-Dawaa Distribution", "Global Pharma Log"]),
        stock,
        reorderLevel: pick([30, 40, 60, 80]),
        unitPrice: Number(unitPrice).toFixed(2),
        expiryDate: isoDate(between(90, 900)),
      };
    }),
  );

  const appointmentValues: (typeof appointments.$inferInsert)[] = [];
  for (let day = -21; day <= 14; day += 1) {
    const perDay = day < 0 ? between(3, 6) : between(4, 8);
    for (let slot = 0; slot < perDay; slot += 1) {
      const patient = pick(patientRows);
      const clinician = pick(staffRows);
      const status =
        day < 0
          ? pick(APPT_STATUS)
          : day === 0
            ? pick(["confirmed", "scheduled", "completed", "scheduled"] as const)
            : pick(["scheduled", "confirmed", "confirmed"] as const);
      appointmentValues.push({
        patientId: patient.id,
        staffId: clinician.id,
        scheduledAt: at(day, between(8, 19), pick([0, 15, 30, 45])),
        durationMinutes: pick([15, 30, 30, 45, 60]),
        type: pick(APPT_TYPES),
        status,
        reason: pick(REASONS),
        room: pick(ROOMS),
        notes: status === "completed" ? "Vitals stable, plan documented." : "",
      });
    }
  }
  const appointmentRows = await db
    .insert(appointments)
    .values(appointmentValues)
    .returning({
      id: appointments.id,
      patientId: appointments.patientId,
      scheduledAt: appointments.scheduledAt,
      status: appointments.status,
    });

  const medicationRows = await db
    .select({ id: medications.id, name: medications.name, strength: medications.strength })
    .from(medications);

  await db.insert(prescriptions).values(
    Array.from({ length: 44 }).map(() => {
      const patient = pick(patientRows);
      const clinician = pick(staffRows);
      const medication = pick(medicationRows);
      const issued = at(-between(0, 40), between(9, 17), pick([0, 30]));
      const status = pick(["pending", "active", "active", "completed", "completed", "cancelled"] as const);
      return {
        patientId: patient.id,
        staffId: clinician.id,
        medicationId: medication.id,
        dosage: pick(["1 tablet", "2 tablets", "10ml", "1 capsule", "0.4ml"]),
        frequency: pick(["Once daily", "Twice daily", "Every 8 hours", "At bedtime", "As needed"]),
        durationDays: pick([5, 7, 10, 14, 30, 90]),
        refills: between(0, 3),
        status,
        issuedAt: issued,
        notes: status === "cancelled" ? "Discontinued due to adverse reaction." : "Take after meals with water.",
      };
    }),
  );

  const invoiceRows = await db
    .insert(invoices)
    .values(
      Array.from({ length: 32 }).map((_, index) => {
        const patient = pick(patientRows);
        const appointment = pick(appointmentRows);
        const amount = between(120, 4200) + rand();
        const insurerCovered = rand() > 0.35 ? Math.round(amount * (rand() * 0.5 + 0.3)) : 0;
        const status = pick(["paid", "paid", "paid", "pending", "pending", "overdue", "draft", "void"] as const);
        const issued = at(-between(1, 60), 13, 15);
        return {
          invoiceNumber: `INV-2026-${String(1041 + index).padStart(4, "0")}`,
          patientId: patient.id,
          amount: amount.toFixed(2),
          insuranceCovered: insurerCovered.toFixed(2),
          status,
          itemsSummary: pick([
            "Consultation + ECG",
            "Lab panel, CBC & HbA1c",
            "Radiology - X-Ray",
            "Physiotherapy session x4",
            "Tele-consultation",
            "Day surgery package",
            "Pharmacy dispensing",
          ]),
          paymentMethod: pick(["card", "cash", "insurance", "bank_transfer"]),
          issuedAt: issued,
          dueDate: isoDate(between(-20, 30)),
          paidAt: status === "paid" ? issued : null,
        };
      }),
    )
    .returning({ id: invoices.id, patientId: invoices.patientId, amount: invoices.amount });

  await db.insert(insuranceClaims).values(
    Array.from({ length: 22 }).map((_, index) => {
      const invoice = pick(invoiceRows);
      const status = pick(CLAIM_STATUS);
      const amount = Number(invoice.amount);
      const approved = status === "rejected" ? 0 : Math.round(amount * (rand() * 0.4 + 0.55));
      const submitted = at(-between(2, 70), 10, 45);
      return {
        claimNumber: `CLM-2026-${String(2201 + index).padStart(4, "0")}`,
        patientId: invoice.patientId,
        provider: pick(CLAIM_PROVIDERS),
        invoiceId: invoice.id,
        amount: amount.toFixed(2),
        approvedAmount: approved.toFixed(2),
        status,
        submittedAt: submitted,
        decidedAt: status === "submitted" || status === "under_review" ? null : submitted,
        notes:
          status === "rejected"
            ? "Missing pre-authorization code for imaging."
            : "Documents complete, awaiting settlement.",
      };
    }),
  );

  await db.insert(activityLog).values([
    { actorName: "Dr. Lina Farouk", action: "completed consultation", entity: "appointment", detail: "Chest discomfort follow-up · Cardio-A" },
    { actorName: "Yousef Karim", action: "dispensed prescription", entity: "prescription", detail: "Amoxicillin 500mg · qty 21" },
    { actorName: "Dalia Mansour", action: "submitted insurance claim", entity: "claim", detail: "Bupa Arabia · CLM-2026-2207" },
    { actorName: "Nora Bishara", action: "admitted patient to ER", entity: "patient", detail: "Triage level 3 · observation" },
    { actorName: "Rami Aziz", action: "registered new patient", entity: "patient", detail: "MRN-104231 · Jeddah" },
    { actorName: "Imad Sabri", action: "flagged low stock", entity: "medication", detail: "Insulin Glargine below reorder level" },
    { actorName: "Dr. Omar Nasser", action: "updated care plan", entity: "patient", detail: "Diabetes review · HbA1c 7.1%" },
    { actorName: "Dalia Mansour", action: "marked invoice paid", entity: "invoice", detail: "INV-2026-1044 · card" },
  ].map((entry, index) => ({ ...entry, createdAt: at(0, 9 + index, index * 7) })));

  return { users: TEAM.length, staff: staffRows.length, patients: patientRows.length };
}

let seedPromise: Promise<void> | null = null;

export async function ensureSeeded() {
  if (seedPromise) return seedPromise;
  seedPromise = (async () => {
    try {
      await db.execute(sql`select pg_advisory_lock(918273645)`);
      if (!(await isSeeded())) {
        await seedDatabase();
      }
    } catch (error) {
      seedPromise = null;
      console.error("[medora] seed skipped:", (error as Error).message);
    } finally {
      try {
        await db.execute(sql`select pg_advisory_unlock(918273645)`);
      } catch {
        /* ignore */
      }
    }
  })();
  return seedPromise;
}

export const DEMO_CREDENTIALS = [
  { label: "Administrator", email: "admin@medora.health" },
  { label: "Physician", email: "doctor@medora.health" },
  { label: "Pharmacist", email: "pharmacy@medora.health" },
  { label: "Billing", email: "billing@medora.health" },
  { label: "Front Desk", email: "reception@medora.health" },
];

export const DEMO_PASSWORD_HINT = DEMO_PASSWORD;
