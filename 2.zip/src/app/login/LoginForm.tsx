"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { AlertTriangle, ArrowRight, Loader2, LogIn } from "lucide-react";

import { apiRequest } from "@/lib/client";

const QUICK_ACCOUNTS = [
  { label: "Admin", email: "admin@medora.health" },
  { label: "Doctor", email: "doctor@medora.health" },
  { label: "Pharmacy", email: "pharmacy@medora.health" },
  { label: "Billing", email: "billing@medora.health" },
];

export default function LoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState("admin@medora.health");
  const [password, setPassword] = useState("medora123");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [pending, startTransition] = useTransition();

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await apiRequest("/api/auth/login", {
        method: "POST",
        json: { email, password },
      });
      startTransition(() => {
        router.replace("/dashboard");
        router.refresh();
      });
    } catch (cause) {
      setError((cause as Error).message);
      setSubmitting(false);
    }
  }

  const busy = submitting || pending;

  return (
    <form onSubmit={submit} className="mt-6 space-y-4">
      <div className="flex flex-wrap gap-2">
        {QUICK_ACCOUNTS.map((account) => (
          <button
            key={account.email}
            type="button"
            onClick={() => {
              setEmail(account.email);
              setPassword("medora123");
            }}
            className={`btn btn-sm ${
              email === account.email
                ? "bg-brand-50 text-brand-700 ring-1 ring-inset ring-brand-200"
                : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            }`}
          >
            {account.label}
          </button>
        ))}
      </div>

      <label className="block">
        <span className="label">Work email</span>
        <input
          type="email"
          required
          autoComplete="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          className="input"
          placeholder="you@medora.health"
        />
      </label>

      <label className="block">
        <span className="label">Password</span>
        <input
          type="password"
          required
          autoComplete="current-password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          className="input"
          placeholder="••••••••"
        />
      </label>

      {error ? (
        <p className="flex items-start gap-2 rounded-xl bg-rose-50 px-3 py-2.5 text-sm text-rose-700 ring-1 ring-inset ring-rose-100">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          {error}
        </p>
      ) : null}

      <button type="submit" className="btn-primary w-full py-2.5" disabled={busy}>
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
        {busy ? "Preparing your workspace…" : "Sign in"}
        {busy ? null : <ArrowRight className="h-4 w-4" />}
      </button>
    </form>
  );
}
