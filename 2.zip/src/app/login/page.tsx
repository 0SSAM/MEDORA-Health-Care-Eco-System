import Link from "next/link";
import { redirect } from "next/navigation";
import { HeartPulse, ShieldCheck, Users, Zap } from "lucide-react";

import { ensureSeeded, DEMO_CREDENTIALS, DEMO_PASSWORD_HINT } from "@/db/seed";
import { getCurrentUser } from "@/lib/auth";
import LoginForm from "./LoginForm";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  await ensureSeeded();
  const user = await getCurrentUser();
  if (user) redirect("/dashboard");

  return (
    <main className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <section className="relative hidden overflow-hidden bg-ink-900 p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="grid-lines absolute inset-0 opacity-50" />
        <div className="absolute -left-24 top-24 h-96 w-96 rounded-full bg-brand-500/25 blur-3xl" />
        <div className="relative">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600">
              <HeartPulse className="h-5 w-5" />
            </span>
            <span className="text-lg font-semibold tracking-tight">MEDORA</span>
          </Link>
          <h1 className="mt-16 max-w-md text-4xl font-semibold leading-tight tracking-tight">
            The clinical control room for your whole care team.
          </h1>
          <p className="mt-4 max-w-md text-white/60">
            Appointments, prescriptions, pharmacy stock, invoices and payer claims —
            synchronised in one secure workspace.
          </p>
          <ul className="mt-10 space-y-4">
            {[
              { icon: ShieldCheck, text: "Role-based access with audited activity trail" },
              { icon: Zap, text: "Optimistic updates — no waiting on page reloads" },
              { icon: Users, text: "26 seeded patients, 12 clinicians, live claims board" },
            ].map((item) => (
              <li key={item.text} className="flex items-center gap-3 text-sm text-white/75">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/10 ring-1 ring-inset ring-white/15">
                  <item.icon className="h-4 w-4 text-brand-200" />
                </span>
                {item.text}
              </li>
            ))}
          </ul>
        </div>
        <p className="relative text-xs text-white/40">
          MEDORA Health Care Eco-System · demo environment
        </p>
      </section>

      <section className="flex items-center justify-center bg-slate-50 px-6 py-12">
        <div className="w-full max-w-md">
          <div className="card card-pad animate-fade-up">
            <h2 className="text-2xl font-semibold tracking-tight text-slate-900">Welcome back</h2>
            <p className="mt-1.5 text-sm text-slate-500">
              Sign in to the MEDORA operations dashboard.
            </p>
            <LoginForm />
          </div>

          <div className="mt-5 rounded-2xl border border-dashed border-slate-300 bg-white/60 p-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              Demo accounts · password {DEMO_PASSWORD_HINT}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {DEMO_CREDENTIALS.map((account) => (
                <span
                  key={account.email}
                  className="rounded-lg bg-slate-100 px-2.5 py-1.5 text-[11px] font-medium text-slate-600"
                >
                  {account.label}: {account.email}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
