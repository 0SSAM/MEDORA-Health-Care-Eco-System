import { Truck } from "lucide-react";

import { getPatientOptions, listDeliveries } from "@/lib/queries";
import DeliveriesClient from "./DeliveriesClient";

export const dynamic = "force-dynamic";

export default async function DeliveriesPage() {
  const [deliveries, patientOptions] = await Promise.all([
    listDeliveries(),
    getPatientOptions(),
  ]);

  if (!deliveries.length) {
    return (
      <div className="card mt-10">
        <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-sky-50 text-sky-600">
            <Truck className="h-6 w-6" />
          </span>
          <p className="text-lg font-semibold text-slate-900">No delivery orders active</p>
          <p className="max-w-sm text-sm text-slate-500">
            Dispatch prescription medications or laboratory samples directly to patients.
          </p>
        </div>
      </div>
    );
  }

  return <DeliveriesClient initialDeliveries={deliveries} patientOptions={patientOptions} />;
}
