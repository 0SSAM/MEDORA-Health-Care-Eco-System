"use client";

import { useMemo, useState } from "react";
import {
  CheckCircle2,
  Navigation,
  Pencil,
  Plus,
  Send,
  ThermometerSnowflake,
  Trash2,
  Truck,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { formatDate, titleCase } from "@/lib/utils";
import type { DeliveryListRow, Option } from "@/lib/queries";
import { ConfirmDialog, EmptyState, StatusBadge, useToast } from "@/components/ui";
import { FormModal, PageHeader, StatCard, Toolbar } from "@/components/resource";

type FormState = {
  patientId: string;
  recipientName: string;
  deliveryAddress: string;
  recipientPhone: string;
  courierName: string;
  status: string;
  temperatureControl: string;
  notes: string;
};

const STATUSES = ["pending", "dispatched", "in_transit", "delivered", "failed"];
const COURIERS = [
  "Medora Express Fleet",
  "CareShip Express",
  "ColdChain Direct",
  "PharmaCourier Logistics",
  "Regional Health Courier",
];
const TEMP_CONTROLS = ["ambient", "cold_chain_2_8c", "controlled_room_temp", "deep_freeze"];

export default function DeliveriesClient({
  initialDeliveries,
  patientOptions,
}: {
  initialDeliveries: DeliveryListRow[];
  patientOptions: Option[];
}) {
  const toast = useToast();
  const [rows, setRows] = useState(initialDeliveries);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<DeliveryListRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<DeliveryListRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState<FormState>({
    patientId: patientOptions[0]?.id ?? "",
    recipientName: patientOptions[0]?.label ?? "",
    deliveryAddress: "King Fahd Road, Riyadh",
    recipientPhone: "+966 50 000 0000",
    courierName: "Medora Express Fleet",
    status: "dispatched",
    temperatureControl: "ambient",
    notes: "Direct home delivery with temperature control verification.",
  });

  const stats = useMemo(() => {
    const inTransit = rows.filter((r) => r.status === "in_transit" || r.status === "dispatched").length;
    const delivered = rows.filter((r) => r.status === "delivered").length;
    const coldChain = rows.filter((r) => r.temperatureControl.includes("cold")).length;
    return {
      total: rows.length,
      inTransit,
      delivered,
      coldChain,
    };
  }, [rows]);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (tab !== "all" && row.status !== tab) return false;
      if (!term) return true;
      return [row.trackingNumber, row.recipientName, row.deliveryAddress, row.courierName]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [rows, query, tab]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: rows.length };
    for (const row of rows) map[row.status] = (map[row.status] ?? 0) + 1;
    return map;
  }, [rows]);

  function openCreate() {
    setEditing(null);
    setForm({
      patientId: patientOptions[0]?.id ?? "",
      recipientName: patientOptions[0]?.label ?? "",
      deliveryAddress: "King Fahd Road, Riyadh",
      recipientPhone: "+966 50 000 0000",
      courierName: "Medora Express Fleet",
      status: "dispatched",
      temperatureControl: "ambient",
      notes: "Direct home delivery with temperature control verification.",
    });
    setOpen(true);
  }

  function openEdit(row: DeliveryListRow) {
    setEditing(row);
    setForm({
      patientId: row.patientId,
      recipientName: row.recipientName,
      deliveryAddress: row.deliveryAddress,
      recipientPhone: row.recipientPhone,
      courierName: row.courierName,
      status: row.status,
      temperatureControl: row.temperatureControl,
      notes: row.notes,
    });
    setOpen(true);
  }

  function buildOptimistic(id: string): DeliveryListRow {
    return {
      id,
      trackingNumber: editing?.trackingNumber ?? "MED-EXP-pending…",
      patientId: form.patientId,
      patientName: patientOptions.find((p) => p.id === form.patientId)?.label ?? form.recipientName,
      prescriptionId: null,
      courierName: form.courierName,
      recipientName: form.recipientName,
      deliveryAddress: form.deliveryAddress,
      recipientPhone: form.recipientPhone,
      status: form.status,
      temperatureControl: form.temperatureControl,
      estimatedDelivery: new Date(),
      deliveredAt: form.status === "delivered" ? new Date() : null,
      notes: form.notes,
      createdAt: editing?.createdAt ?? new Date(),
    };
  }

  async function markDelivered(row: DeliveryListRow) {
    const previous = rows;
    setRows((current) =>
      current.map((r) =>
        r.id === row.id ? { ...r, status: "delivered", deliveredAt: new Date() } : r,
      ),
    );
    try {
      await apiRequest(`/api/deliveries/${row.id}`, {
        method: "PATCH",
        json: { status: "delivered" },
      });
      toast.push({ title: `Order ${row.trackingNumber} delivered`, tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    }
  }

  async function submit() {
    setBusy(true);
    const payload = { ...form };
    try {
      if (editing) {
        const previous = rows;
        setRows((current) =>
          current.map((row) => (row.id === editing.id ? buildOptimistic(row.id) : row)),
        );
        setOpen(false);
        try {
          await apiRequest(`/api/deliveries/${editing.id}`, { method: "PATCH", json: payload });
          toast.push({ title: "Delivery order updated", tone: "success" });
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic = buildOptimistic(`temp-${Date.now()}`);
        setRows((current) => [optimistic, ...current]);
        setOpen(false);
        try {
          const created = await apiRequest<DeliveryListRow>("/api/deliveries", {
            method: "POST",
            json: payload,
          });
          setRows((current) => current.map((row) => (row.id === optimistic.id ? created : row)));
          toast.push({ title: `Dispatch ${created.trackingNumber} scheduled`, tone: "success" });
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== pendingDelete.id));
    try {
      await apiRequest(`/api/deliveries/${pendingDelete.id}`, { method: "DELETE" });
      toast.push({ title: "Delivery order removed", tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Delivery & Logistics"
        subtitle="Medication dispatch, courier cold-chain status, and patient home deliveries."
      >
        <button type="button" className="btn-primary" onClick={openCreate}>
          <Plus className="h-4 w-4" /> Dispatch medication
        </button>
      </PageHeader>

      <section className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Active shipments"
          value={stats.inTransit}
          footer={`${stats.total} total dispatches`}
          icon={<Truck className="h-4 w-4" />}
        />
        <StatCard
          label="Delivered"
          value={stats.delivered}
          icon={<CheckCircle2 className="h-4 w-4" />}
          tone="violet"
        />
        <StatCard
          label="Cold chain monitoring"
          value={stats.coldChain}
          icon={<ThermometerSnowflake className="h-4 w-4" />}
          tone="sky"
        />
        <StatCard
          label="Average fulfillment"
          value="4.2 hrs"
          icon={<Navigation className="h-4 w-4" />}
          tone="amber"
        />
      </section>

      <Toolbar
        search={query}
        onSearch={setQuery}
        placeholder="Search tracking number, recipient or courier…"
        tabs={[
          { value: "all", label: "All", count: counts.all ?? 0 },
          ...STATUSES.map((status) => ({
            value: status,
            label: titleCase(status),
            count: counts[status] ?? 0,
          })),
        ]}
        activeTab={tab}
        onTab={setTab}
        resultCount={filtered.length}
      />

      <div className="card overflow-hidden">
        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="table-shell">
              <thead>
                <tr>
                  <th>Tracking #</th>
                  <th>Recipient / Patient</th>
                  <th>Destination Address</th>
                  <th>Courier</th>
                  <th>Storage</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.id} className={row.id.startsWith("temp-") ? "opacity-60" : undefined}>
                    <td>
                      <code className="rounded bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-800">
                        {row.trackingNumber}
                      </code>
                      <span className="mt-1 block text-xs text-slate-400">
                        Created {formatDate(row.createdAt)}
                      </span>
                    </td>
                    <td>
                      <span className="block font-semibold text-slate-900">
                        {row.recipientName}
                      </span>
                      <span className="block text-xs text-slate-400">{row.recipientPhone || "—"}</span>
                    </td>
                    <td className="text-sm text-slate-700">{row.deliveryAddress}</td>
                    <td className="text-sm text-slate-600">{row.courierName}</td>
                    <td>
                      <span className="badge bg-sky-50 text-sky-700 text-[10px] ring-1 ring-sky-200">
                        {titleCase(row.temperatureControl.replace(/_/g, " "))}
                      </span>
                    </td>
                    <td>
                      <StatusBadge status={row.status} />
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        {row.status !== "delivered" ? (
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-emerald-600 hover:bg-emerald-50"
                            title="Mark delivered"
                            onClick={() => markDelivered(row)}
                          >
                            <CheckCircle2 className="h-4 w-4" />
                          </button>
                        ) : null}
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2"
                          onClick={() => openEdit(row)}
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                          onClick={() => setPendingDelete(row)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<Truck className="h-6 w-6" />}
            title="No delivery orders found"
            description="Dispatch medications or laboratory logistics to patient homes."
            action={
              <button type="button" className="btn-primary" onClick={openCreate}>
                <Plus className="h-4 w-4" /> Dispatch medication
              </button>
            }
          />
        )}
      </div>

      <FormModal
        open={open}
        mode={editing ? "edit" : "create"}
        title={editing ? `Edit Shipment ${editing.trackingNumber}` : "Dispatch Medication Order"}
        description="Select recipient patient, courier carrier, and cold-chain temperature profile."
        onClose={() => setOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block sm:col-span-2">
            <span className="label">Patient *</span>
            <select
              required
              className="input"
              value={form.patientId}
              onChange={(event) => {
                const opt = patientOptions.find((p) => p.id === event.target.value);
                setForm({
                  ...form,
                  patientId: event.target.value,
                  recipientName: opt?.label ?? form.recipientName,
                });
              }}
            >
              <option value="">Select a patient…</option>
              {patientOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label} ({option.hint})
                </option>
              ))}
            </select>
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Recipient Name *</span>
            <input
              required
              className="input"
              value={form.recipientName}
              onChange={(event) => setForm({ ...form, recipientName: event.target.value })}
            />
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Delivery Address *</span>
            <input
              required
              className="input"
              value={form.deliveryAddress}
              onChange={(event) => setForm({ ...form, deliveryAddress: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Recipient Phone</span>
            <input
              className="input"
              value={form.recipientPhone}
              onChange={(event) => setForm({ ...form, recipientPhone: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Courier Carrier</span>
            <select
              className="input"
              value={form.courierName}
              onChange={(event) => setForm({ ...form, courierName: event.target.value })}
            >
              {COURIERS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Temperature Control</span>
            <select
              className="input"
              value={form.temperatureControl}
              onChange={(event) => setForm({ ...form, temperatureControl: event.target.value })}
            >
              {TEMP_CONTROLS.map((t) => (
                <option key={t} value={t}>
                  {titleCase(t.replace(/_/g, " "))}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Status</span>
            <select
              className="input"
              value={form.status}
              onChange={(event) => setForm({ ...form, status: event.target.value })}
            >
              {STATUSES.map((status) => (
                <option key={status} value={status}>
                  {titleCase(status)}
                </option>
              ))}
            </select>
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Special Delivery Instructions</span>
            <textarea
              rows={3}
              className="input resize-none"
              value={form.notes}
              onChange={(event) => setForm({ ...form, notes: event.target.value })}
            />
          </label>
        </div>
      </FormModal>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete delivery order"
        message={`Delete shipment ${pendingDelete?.trackingNumber} for ${pendingDelete?.recipientName}?`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
