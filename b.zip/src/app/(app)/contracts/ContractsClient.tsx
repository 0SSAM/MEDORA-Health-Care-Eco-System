"use client";

import { useMemo, useState } from "react";
import {
  Building2,
  FileCheck2,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { compactCurrency, currency, formatDate, titleCase, toInputDate } from "@/lib/utils";
import type { ContractListRow } from "@/lib/queries";
import { ConfirmDialog, EmptyState, StatusBadge, useToast } from "@/components/ui";
import { FormModal, PageHeader, StatCard, Toolbar } from "@/components/resource";

type FormState = {
  partnerOrganization: string;
  contractType: string;
  contactPerson: string;
  contactEmail: string;
  contactPhone: string;
  discountRate: string;
  annualValue: string;
  status: string;
  startDate: string;
  endDate: string;
  termsSummary: string;
};

const STATUSES = ["active", "pending_review", "expired", "terminated"];
const CONTRACT_TYPES = ["corporate", "insurance_provider", "supplier", "government", "research"];

export default function ContractsClient({
  initialContracts,
}: {
  initialContracts: ContractListRow[];
}) {
  const toast = useToast();
  const [rows, setRows] = useState(initialContracts);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ContractListRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<ContractListRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState<FormState>({
    partnerOrganization: "",
    contractType: "corporate",
    contactPerson: "",
    contactEmail: "",
    contactPhone: "",
    discountRate: "15.00",
    annualValue: "50000.00",
    status: "active",
    startDate: toInputDate(new Date()),
    endDate: toInputDate(new Date(Date.now() + 365 * 86400000)),
    termsSummary: "Full outpatient & pharmacy coverage with 15% corporate concession.",
  });

  const stats = useMemo(() => {
    const totalVal = rows.reduce((sum, r) => sum + Number(r.annualValue), 0);
    const activeVal = rows
      .filter((r) => r.status === "active")
      .reduce((sum, r) => sum + Number(r.annualValue), 0);
    const activeCount = rows.filter((r) => r.status === "active").length;
    return {
      total: rows.length,
      totalVal,
      activeVal,
      activeCount,
    };
  }, [rows]);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (tab !== "all" && row.status !== tab) return false;
      if (!term) return true;
      return [row.partnerOrganization, row.contractNumber, row.contactPerson, row.contractType]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [rows, query, tab]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: rows.length };
    for (const row of rows) map[row.status] = (map[row.status] ?? 0) + 1;
    return map;
  }, [rows]);

  function openCreate() {
    setEditing(null);
    setForm({
      partnerOrganization: "",
      contractType: "corporate",
      contactPerson: "",
      contactEmail: "",
      contactPhone: "",
      discountRate: "15.00",
      annualValue: "50000.00",
      status: "active",
      startDate: toInputDate(new Date()),
      endDate: toInputDate(new Date(Date.now() + 365 * 86400000)),
      termsSummary: "Full outpatient & pharmacy coverage with 15% corporate concession.",
    });
    setOpen(true);
  }

  function openEdit(row: ContractListRow) {
    setEditing(row);
    setForm({
      partnerOrganization: row.partnerOrganization,
      contractType: row.contractType,
      contactPerson: row.contactPerson,
      contactEmail: row.contactEmail,
      contactPhone: row.contactPhone,
      discountRate: row.discountRate,
      annualValue: row.annualValue,
      status: row.status,
      startDate: row.startDate,
      endDate: row.endDate,
      termsSummary: row.termsSummary,
    });
    setOpen(true);
  }

  function buildOptimistic(id: string): ContractListRow {
    return {
      id,
      contractNumber: editing?.contractNumber ?? "CTR pending…",
      partnerOrganization: form.partnerOrganization,
      contractType: form.contractType,
      contactPerson: form.contactPerson,
      contactEmail: form.contactEmail,
      contactPhone: form.contactPhone,
      discountRate: form.discountRate,
      annualValue: form.annualValue,
      status: form.status,
      startDate: form.startDate,
      endDate: form.endDate,
      termsSummary: form.termsSummary,
      createdAt: editing?.createdAt ?? new Date(),
    };
  }

  async function submit() {
    setBusy(true);
    const payload = {
      ...form,
      discountRate: Number(form.discountRate || 0).toFixed(2),
      annualValue: Number(form.annualValue || 0).toFixed(2),
    };
    try {
      if (editing) {
        const previous = rows;
        setRows((current) =>
          current.map((row) => (row.id === editing.id ? buildOptimistic(row.id) : row)),
        );
        setOpen(false);
        try {
          await apiRequest(`/api/contracts/${editing.id}`, { method: "PATCH", json: payload });
          toast.push({ title: "Contract agreement updated", tone: "success" });
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic = buildOptimistic(`temp-${Date.now()}`);
        setRows((current) => [optimistic, ...current]);
        setOpen(false);
        try {
          const created = await apiRequest<ContractListRow>("/api/contracts", {
            method: "POST",
            json: payload,
          });
          setRows((current) => current.map((row) => (row.id === optimistic.id ? created : row)));
          toast.push({ title: `${created.partnerOrganization} agreement active`, tone: "success" });
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== pendingDelete.id));
    try {
      await apiRequest(`/api/contracts/${pendingDelete.id}`, { method: "DELETE" });
      toast.push({ title: "Contract removed", tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Medical Contracts & Alliances"
        subtitle="Corporate partnerships, insurer concession terms, and healthcare agreements."
      >
        <button type="button" className="btn-primary" onClick={openCreate}>
          <Plus className="h-4 w-4" /> New contract
        </button>
      </PageHeader>

      <section className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Active contracts"
          value={stats.activeCount}
          footer={`${stats.total} total agreements`}
          icon={<FileCheck2 className="h-4 w-4" />}
        />
        <StatCard
          label="Active portfolio"
          value={compactCurrency(stats.activeVal)}
          icon={<Building2 className="h-4 w-4" />}
          tone="violet"
        />
        <StatCard
          label="Annual contract value"
          value={compactCurrency(stats.totalVal)}
          icon={<Building2 className="h-4 w-4" />}
          tone="sky"
        />
        <StatCard
          label="Avg Concession Rate"
          value="16.7%"
          icon={<FileCheck2 className="h-4 w-4" />}
          tone="amber"
        />
      </section>

      <Toolbar
        search={query}
        onSearch={setQuery}
        placeholder="Search partner, contact person or contract number…"
        tabs={[
          { value: "all", label: "All", count: counts.all ?? 0 },
          ...STATUSES.map((status) => ({
            value: status,
            label: titleCase(status),
            count: counts[status] ?? 0,
          })),
        ]}
        activeTab={tab}
        onTab={setTab}
        resultCount={filtered.length}
      />

      <div className="card overflow-hidden">
        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="table-shell">
              <thead>
                <tr>
                  <th>Partner / Organization</th>
                  <th>Type</th>
                  <th>Contact Person</th>
                  <th>Discount Rate</th>
                  <th>Annual Value</th>
                  <th>Term Duration</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.id} className={row.id.startsWith("temp-") ? "opacity-60" : undefined}>
                    <td>
                      <span className="block font-semibold text-slate-900">
                        {row.partnerOrganization}
                      </span>
                      <span className="block text-xs text-slate-400">{row.contractNumber}</span>
                    </td>
                    <td className="text-sm text-slate-600">{titleCase(row.contractType)}</td>
                    <td>
                      <span className="block text-sm text-slate-700">
                        {row.contactPerson || "—"}
                      </span>
                      <span className="block text-xs text-slate-400">
                        {row.contactEmail || row.contactPhone || "—"}
                      </span>
                    </td>
                    <td className="text-sm font-semibold text-brand-700">
                      {row.discountRate}% off
                    </td>
                    <td className="whitespace-nowrap font-medium text-slate-900">
                      {currency(row.annualValue)}
                    </td>
                    <td className="text-xs text-slate-600">
                      {formatDate(row.startDate)} → {formatDate(row.endDate)}
                    </td>
                    <td>
                      <StatusBadge status={row.status} />
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2"
                          onClick={() => openEdit(row)}
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                          onClick={() => setPendingDelete(row)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<FileCheck2 className="h-6 w-6" />}
            title="No medical contracts found"
            description="Create a corporate or healthcare provider concession agreement."
            action={
              <button type="button" className="btn-primary" onClick={openCreate}>
                <Plus className="h-4 w-4" /> New contract
              </button>
            }
          />
        )}
      </div>

      <FormModal
        open={open}
        mode={editing ? "edit" : "create"}
        title={editing ? `Edit ${editing.partnerOrganization}` : "New Medical Contract"}
        description="Specify partner details, concession rates, and annual agreement cap."
        onClose={() => setOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block sm:col-span-2">
            <span className="label">Partner Organization *</span>
            <input
              required
              className="input"
              value={form.partnerOrganization}
              onChange={(event) => setForm({ ...form, partnerOrganization: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Contract Type</span>
            <select
              className="input"
              value={form.contractType}
              onChange={(event) => setForm({ ...form, contractType: event.target.value })}
            >
              {CONTRACT_TYPES.map((type) => (
                <option key={type} value={type}>
                  {titleCase(type)}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Status</span>
            <select
              className="input"
              value={form.status}
              onChange={(event) => setForm({ ...form, status: event.target.value })}
            >
              {STATUSES.map((status) => (
                <option key={status} value={status}>
                  {titleCase(status)}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Contact Person</span>
            <input
              className="input"
              value={form.contactPerson}
              onChange={(event) => setForm({ ...form, contactPerson: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Contact Email</span>
            <input
              type="email"
              className="input"
              value={form.contactEmail}
              onChange={(event) => setForm({ ...form, contactEmail: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Discount / Concession (%)</span>
            <input
              type="number"
              min={0}
              max={100}
              step="0.1"
              className="input"
              value={form.discountRate}
              onChange={(event) => setForm({ ...form, discountRate: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Annual Agreement Value ($)</span>
            <input
              type="number"
              min={0}
              step="1000"
              className="input"
              value={form.annualValue}
              onChange={(event) => setForm({ ...form, annualValue: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Effective Start Date</span>
            <input
              type="date"
              className="input"
              value={form.startDate}
              onChange={(event) => setForm({ ...form, startDate: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Expiry Date</span>
            <input
              type="date"
              className="input"
              value={form.endDate}
              onChange={(event) => setForm({ ...form, endDate: event.target.value })}
            />
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Agreement Summary &amp; Concessions</span>
            <textarea
              rows={3}
              className="input resize-none"
              value={form.termsSummary}
              onChange={(event) => setForm({ ...form, termsSummary: event.target.value })}
            />
          </label>
        </div>
      </FormModal>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete medical contract"
        message={`Delete ${pendingDelete?.partnerOrganization} (${pendingDelete?.contractNumber})?`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
