import { FileCheck2 } from "lucide-react";

import { listContracts } from "@/lib/queries";
import ContractsClient from "./ContractsClient";

export const dynamic = "force-dynamic";

export default async function ContractsPage() {
  const contracts = await listContracts();

  if (!contracts.length) {
    return (
      <div className="card mt-10">
        <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-emerald-50 text-emerald-600">
            <FileCheck2 className="h-6 w-6" />
          </span>
          <p className="text-lg font-semibold text-slate-900">No medical contracts on file</p>
          <p className="max-w-sm text-sm text-slate-500">
            Register corporate health alliances, HMOs, or concession agreements.
          </p>
        </div>
      </div>
    );
  }

  return <ContractsClient initialContracts={contracts} />;
}
