"use client";

import { useEffect, useState } from "react";
import {
  AlertCircle,
  AlertTriangle,
  Bot,
  Building2,
  CalendarClock,
  CheckCircle2,
  Database,
  Download,
  FileCheck2,
  HeartPulse,
  Layers,
  Loader2,
  Play,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  TestTube2,
  Truck,
  Users,
  Wallet,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { BarList, DonutChart, TrendChart } from "@/components/charts";
import { PageHeader, StatCard } from "@/components/resource";
import { Avatar, EmptyState, Pill, StatusBadge, TableSkeleton, useToast } from "@/components/ui";

type TestResult = {
  id: string;
  category: "Database" | "Auth" | "AI Engine" | "CRUD & Operations" | "Offline Readiness";
  name: string;
  status: "passed" | "failed" | "warning";
  durationMs: number;
  message: string;
};

type TestSummary = {
  total: number;
  passed: number;
  failed: number;
  allPassed: boolean;
  totalDurationMs: number;
  timestamp: string;
};

export default function DiagnosticsClient() {
  const toast = useToast();
  const [running, setRunning] = useState(false);
  const [testSummary, setTestSummary] = useState<TestSummary | null>(null);
  const [testList, setTestList] = useState<TestResult[]>([]);
  const [activeVisualTab, setActiveVisualTab] = useState<"visual" | "system" | "ai" | "portable">("system");
  
  // AI Interactive Demo State
  const [aiMeds, setAiMeds] = useState("Amoxicillin, Atorvastatin, Ibuprofen");
  const [aiAllergies, setAiAllergies] = useState("Penicillin");
  const [aiConditions, setAiConditions] = useState("Asthma");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<{
    status: string;
    overallSafetyScore: number;
    clinicalAdvice: string;
    warnings: Array<{ type: string; severity: string; title: string; details: string; recommendation: string }>;
  } | null>(null);

  async function runAllTests() {
    setRunning(true);
    try {
      const res = await apiRequest<{ summary: TestSummary; tests: TestResult[] }>("/api/system-tests");
      setTestSummary(res.summary);
      setTestList(res.tests);
      toast.push({
        title: res.summary.allPassed ? "All system tests passed successfully!" : "Some tests flagged warnings.",
        tone: res.summary.allPassed ? "success" : "error",
      });
    } catch (err) {
      toast.push({ title: (err as Error).message, tone: "error" });
    } finally {
      setRunning(false);
    }
  }

  async function testAiPrescription() {
    setAiLoading(true);
    try {
      const medsArray = aiMeds.split(",").map((s) => s.trim()).filter(Boolean);
      const res = await apiRequest<{
        status: string;
        overallSafetyScore: number;
        clinicalAdvice: string;
        warnings: Array<{ type: string; severity: string; title: string; details: string; recommendation: string }>;
      }>("/api/ai/prescriptions", {
        method: "POST",
        json: {
          medications: medsArray,
          allergies: aiAllergies,
          conditions: aiConditions,
        },
      });
      setAiResult(res);
      toast.push({ title: `AI Analysis complete (${res.warnings.length} alerts detected)`, tone: "info" });
    } catch (err) {
      toast.push({ title: (err as Error).message, tone: "error" });
    } finally {
      setAiLoading(false);
    }
  }

  useEffect(() => {
    runAllTests();
  }, []);

  return (
    <div className="space-y-6">
      <PageHeader
        title="System Diagnostics & Test Suite"
        subtitle="End-to-end verification of database integrity, AI engine, visual design components, and offline runtime."
      >
        <button
          type="button"
          className="btn-secondary"
          onClick={runAllTests}
          disabled={running}
        >
          {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          {running ? "Running tests…" : "Rerun all tests"}
        </button>
        <a
          href="/medora-offline-standalone.html"
          target="_blank"
          rel="noreferrer"
          className="btn-primary"
        >
          <Download className="h-4 w-4" /> Open Offline Standalone
        </a>
      </PageHeader>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveVisualTab("system")}
          className={`btn btn-sm ${
            activeVisualTab === "system"
              ? "bg-brand-600 text-white"
              : "bg-white text-slate-700 hover:bg-slate-100"
          }`}
        >
          <TestTube2 className="h-4 w-4" />
          <span>System Tests ({testSummary ? `${testSummary.passed}/${testSummary.total}` : "..."})</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveVisualTab("visual")}
          className={`btn btn-sm ${
            activeVisualTab === "visual"
              ? "bg-brand-600 text-white"
              : "bg-white text-slate-700 hover:bg-slate-100"
          }`}
        >
          <Layers className="h-4 w-4" />
          <span>Visual Test Gallery</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveVisualTab("ai")}
          className={`btn btn-sm ${
            activeVisualTab === "ai"
              ? "bg-brand-600 text-white"
              : "bg-white text-slate-700 hover:bg-slate-100"
          }`}
        >
          <Bot className="h-4 w-4" />
          <span>Prescription-AI Live Simulator</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveVisualTab("portable")}
          className={`btn btn-sm ${
            activeVisualTab === "portable"
              ? "bg-brand-600 text-white"
              : "bg-white text-slate-700 hover:bg-slate-100"
          }`}
        >
          <Download className="h-4 w-4" />
          <span>Windows Portable Runtime (.cmd / .html)</span>
        </button>
      </div>

      {/* 1. SYSTEM TESTS TAB */}
      {activeVisualTab === "system" && (
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-4">
            <StatCard
              label="Tests Executed"
              value={testSummary?.total ?? 0}
              icon={<TestTube2 className="h-4 w-4" />}
            />
            <StatCard
              label="Passed"
              value={testSummary?.passed ?? 0}
              icon={<CheckCircle2 className="h-4 w-4" />}
              tone="brand"
            />
            <StatCard
              label="Failed"
              value={testSummary?.failed ?? 0}
              icon={<AlertCircle className="h-4 w-4" />}
              tone={testSummary?.failed === 0 ? "brand" : "rose"}
            />
            <StatCard
              label="Execution Time"
              value={`${testSummary?.totalDurationMs ?? 0} ms`}
              icon={<Sparkles className="h-4 w-4" />}
              tone="violet"
            />
          </div>

          <div className="card overflow-hidden">
            <div className="border-b border-slate-100 px-5 py-4">
              <h2 className="section-title">Automated Test Results</h2>
              <p className="muted mt-0.5">Database connectivity, Admin auth, and AI engine integrity</p>
            </div>
            <ul className="divide-y divide-slate-100">
              {testList.map((test) => (
                <li key={test.id} className="flex items-start gap-3 px-5 py-4 hover:bg-slate-50/60">
                  {test.status === "passed" ? (
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-500" />
                  ) : test.status === "warning" ? (
                    <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-500" />
                  ) : (
                    <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-rose-500" />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-slate-900">{test.name}</span>
                      <Pill tone="blue">{test.category}</Pill>
                    </div>
                    <p className="mt-1 text-xs text-slate-600">{test.message}</p>
                  </div>
                  <span className="shrink-0 text-xs text-slate-400">{test.durationMs}ms</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* 2. VISUAL TEST GALLERY */}
      {activeVisualTab === "visual" && (
        <div className="space-y-6">
          {/* Status Badges Section */}
          <div className="card card-pad">
            <h2 className="section-title mb-3">1. Visual Status Badges (All Healthcare States)</h2>
            <div className="flex flex-wrap gap-2.5">
              <StatusBadge status="active" />
              <StatusBadge status="on_duty" />
              <StatusBadge status="available" />
              <StatusBadge status="completed" />
              <StatusBadge status="confirmed" />
              <StatusBadge status="paid" />
              <StatusBadge status="approved" />
              <StatusBadge status="pending" />
              <StatusBadge status="under_review" />
              <StatusBadge status="recovering" />
              <StatusBadge status="critical" />
              <StatusBadge status="rejected" />
              <StatusBadge status="overdue" />
              <StatusBadge status="cancelled" />
              <StatusBadge status="no_show" />
              <StatusBadge status="draft" />
              <StatusBadge status="in_transit" />
            </div>
          </div>

          {/* Avatars & Care Team Badges */}
          <div className="card card-pad">
            <h2 className="section-title mb-3">2. Clinician &amp; Patient Avatar Gradients</h2>
            <div className="grid gap-4 sm:grid-cols-3">
              <Avatar name="Dr. Samir Haddad" subtitle="Executive · Admin" size="md" />
              <Avatar name="Dr. Lina Farouk" subtitle="Cardiology · Consultant" size="md" />
              <Avatar name="Amal Al Harbi" subtitle="MRN-104201 · Active Patient" size="md" />
            </div>
          </div>

          {/* Interactive Charts Preview */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="card card-pad">
              <h2 className="section-title mb-2">3. SVG Revenue Trend Visualizer</h2>
              <TrendChart
                data={[
                  { day: "Day 1", total: 1200 },
                  { day: "Day 2", total: 2400 },
                  { day: "Day 3", total: 1800 },
                  { day: "Day 4", total: 3900 },
                  { day: "Day 5", total: 4200 },
                  { day: "Day 6", total: 5100 },
                ]}
              />
            </div>
            <div className="card card-pad">
              <h2 className="section-title mb-2">4. SVG Distribution Donut Chart</h2>
              <DonutChart
                data={[
                  { label: "Approved", value: 45 },
                  { label: "Under Review", value: 20 },
                  { label: "Settled", value: 30 },
                  { label: "Rejected", value: 5 },
                ]}
                centerLabel="Total Claims"
                centerValue="100"
              />
            </div>
          </div>

          {/* Skeletons & Empty States */}
          <div className="card card-pad">
            <h2 className="section-title mb-3">5. Empty State & Shimmer Skeletons</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-dashed border-slate-200 p-4">
                <EmptyState
                  icon={<HeartPulse className="h-6 w-6" />}
                  title="All Systems Verified"
                  description="All components render with zero errors."
                />
              </div>
              <div className="rounded-2xl border border-slate-200 p-4">
                <TableSkeleton rows={3} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. AI PRESCRIPTION SIMULATOR */}
      {activeVisualTab === "ai" && (
        <div className="card card-pad space-y-5">
          <div className="flex items-center gap-2.5">
            <Bot className="h-5 w-5 text-brand-600" />
            <div>
              <h2 className="section-title">Prescription-AI Drug Interaction Engine</h2>
              <p className="muted text-xs">Simulate clinical triaging and cross-reactivity warnings</p>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <label className="block">
              <span className="label">Medications (comma separated)</span>
              <input
                className="input"
                value={aiMeds}
                onChange={(e) => setAiMeds(e.target.value)}
                placeholder="Amoxicillin, Atorvastatin, Ibuprofen"
              />
            </label>
            <label className="block">
              <span className="label">Patient Allergies</span>
              <input
                className="input"
                value={aiAllergies}
                onChange={(e) => setAiAllergies(e.target.value)}
                placeholder="Penicillin"
              />
            </label>
            <label className="block">
              <span className="label">Chronic Conditions</span>
              <input
                className="input"
                value={aiConditions}
                onChange={(e) => setAiConditions(e.target.value)}
                placeholder="Asthma, Diabetes"
              />
            </label>
          </div>

          <button
            type="button"
            className="btn-primary"
            onClick={testAiPrescription}
            disabled={aiLoading}
          >
            {aiLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            <span>Run AI Safety & Interaction Check</span>
          </button>

          {aiResult && (
            <div className="mt-4 rounded-2xl border border-slate-200 bg-slate-50/70 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Safety Status
                  </span>
                  <p className="text-lg font-bold text-slate-900">
                    {aiResult.status === "safe_to_dispense"
                      ? "✅ Safe to Dispense"
                      : aiResult.status === "contraindicated"
                        ? "🚨 Contraindicated"
                        : "⚠️ Caution Advised"}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Safety Score
                  </span>
                  <p className="text-2xl font-black text-brand-600">
                    {aiResult.overallSafetyScore} / 100
                  </p>
                </div>
              </div>

              <p className="text-sm text-slate-700 bg-white p-3 rounded-xl border border-slate-200/80">
                <strong>Clinical Advice:</strong> {aiResult.clinicalAdvice}
              </p>

              {aiResult.warnings.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Detected Warnings ({aiResult.warnings.length})
                  </span>
                  {aiResult.warnings.map((w, i) => (
                    <div
                      key={i}
                      className={`p-3.5 rounded-xl border text-sm ${
                        w.severity === "critical"
                          ? "bg-rose-50 border-rose-200 text-rose-900"
                          : "bg-amber-50 border-amber-200 text-amber-900"
                      }`}
                    >
                      <div className="font-semibold flex items-center gap-2">
                        {w.severity === "critical" ? "⛔" : "⚠️"} {w.title}
                      </div>
                      <div className="text-xs mt-1 opacity-90">{w.details}</div>
                      <div className="text-xs mt-2 font-medium bg-white/70 p-2 rounded-lg">
                        <strong>Action:</strong> {w.recommendation}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 4. PORTABLE EDITION TAB */}
      {activeVisualTab === "portable" && (
        <div className="card card-pad space-y-4">
          <div className="flex items-center gap-2.5">
            <Download className="h-5 w-5 text-emerald-600" />
            <div>
              <h2 className="section-title">Standalone Offline &amp; Portable Package for Windows</h2>
              <p className="muted text-xs">Zero dependencies · runs offline on any Windows or Web environment</p>
            </div>
          </div>

          <div className="rounded-2xl bg-emerald-50/60 p-4 border border-emerald-200 text-sm text-emerald-900 space-y-2">
            <p className="font-semibold">📦 Standalone Package Ready:</p>
            <ul className="list-disc list-inside space-y-1 text-xs text-emerald-800">
              <li>Single-file HTML with embedded offline storage, full CRM, Pharmacy, Billing, and Medical Contracts.</li>
              <li>Windows batch launcher <code>start-medora-windows.cmd</code> included.</li>
              <li>Pre-seeded with Administrator account (<strong>username: <code>admin</code></strong> / <strong>password: <code>admin</code></strong>).</li>
              <li>Works 100% without Node.js, PostgreSQL, or Internet connection.</li>
            </ul>
          </div>

          <div className="flex flex-wrap gap-3 pt-2">
            <a
              href="/medora-offline-standalone.html"
              download="medora-offline-standalone.html"
              className="btn btn-primary"
            >
              <Download className="h-4 w-4" />
              <span>Download Standalone .HTML (Direct Run)</span>
            </a>
            <a
              href="/api/backup"
              className="btn btn-secondary"
            >
              <Database className="h-4 w-4" />
              <span>Export Full JSON Database Backup</span>
            </a>
          </div>
        </div>
      )}
    </div>
  );
}
