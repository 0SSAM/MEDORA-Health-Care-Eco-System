import { TestTube2 } from "lucide-react";

import DiagnosticsClient from "./DiagnosticsClient";

export const dynamic = "force-dynamic";

export default async function DiagnosticsPage() {
  return <DiagnosticsClient />;
}
