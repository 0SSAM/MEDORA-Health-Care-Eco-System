"use client";

import { useMemo, useState } from "react";
import {
  AlertTriangle,
  Bot,
  CheckCircle2,
  ClipboardList,
  Loader2,
  Pencil,
  Plus,
  Send,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { formatDate, titleCase } from "@/lib/utils";
import type { Option, PrescriptionListRow } from "@/lib/queries";
import { ConfirmDialog, EmptyState, StatusBadge, useToast } from "@/components/ui";
import { FormModal, PageHeader, Toolbar } from "@/components/resource";

type FormState = {
  patientId: string;
  staffId: string;
  medicationId: string;
  dosage: string;
  frequency: string;
  durationDays: string;
  refills: string;
  status: string;
  notes: string;
};

const STATUSES = ["pending", "active", "completed", "cancelled"];
const FREQUENCIES = [
  "Once daily",
  "Twice daily",
  "Three times daily",
  "Every 8 hours",
  "At bedtime",
  "As needed",
];

export default function PrescriptionsClient({
  initialPrescriptions,
  patientOptions,
  staffOptions,
  medicationOptions,
}: {
  initialPrescriptions: PrescriptionListRow[];
  patientOptions: Option[];
  staffOptions: Option[];
  medicationOptions: Option[];
}) {
  const toast = useToast();
  const [rows, setRows] = useState(initialPrescriptions);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<PrescriptionListRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<PrescriptionListRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  
  // AI Safety Modal State
  const [aiModalOpen, setAiModalOpen] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<{
    overallSafetyScore: number;
    status: string;
    clinicalAdvice: string;
    warnings: Array<{ type: string; severity: string; title: string; details: string; recommendation: string }>;
  } | null>(null);

  const [form, setForm] = useState<FormState>({
    patientId: patientOptions[0]?.id ?? "",
    staffId: staffOptions[0]?.id ?? "",
    medicationId: medicationOptions[0]?.id ?? "",
    dosage: "1 tablet",
    frequency: "Twice daily",
    durationDays: "7",
    refills: "0",
    status: "pending",
    notes: "Take after meals with water.",
  });

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (tab !== "all" && row.status !== tab) return false;
      if (!term) return true;
      return [
        row.patientName,
        row.medicationName,
        row.staffName,
        row.dosage,
        row.frequency,
        row.notes,
      ]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [rows, query, tab]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: rows.length };
    for (const row of rows) map[row.status] = (map[row.status] ?? 0) + 1;
    return map;
  }, [rows]);

  function openCreate() {
    setEditing(null);
    setForm({
      patientId: patientOptions[0]?.id ?? "",
      staffId: staffOptions[0]?.id ?? "",
      medicationId: medicationOptions[0]?.id ?? "",
      dosage: "1 tablet",
      frequency: "Twice daily",
      durationDays: "7",
      refills: "0",
      status: "pending",
      notes: "Take after meals with water.",
    });
    setOpen(true);
  }

  function openEdit(row: PrescriptionListRow) {
    setEditing(row);
    setForm({
      patientId: row.patientId,
      staffId: row.staffId ?? "",
      medicationId: row.medicationId ?? "",
      dosage: row.dosage,
      frequency: row.frequency,
      durationDays: String(row.durationDays),
      refills: String(row.refills),
      status: row.status,
      notes: row.notes,
    });
    setOpen(true);
  }

  async function patchStatus(row: PrescriptionListRow, status: string) {
    const previous = rows;
    setRows((current) =>
      current.map((item) => (item.id === row.id ? { ...item, status } : item)),
    );
    try {
      await apiRequest(`/api/prescriptions/${row.id}`, { method: "PATCH", json: { status } });
      toast.push({ title: `Prescription ${titleCase(status)}`, tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    }
  }

  function buildOptimistic(id: string): PrescriptionListRow {
    return {
      id,
      patientId: form.patientId,
      patientName: patientOptions.find((option) => option.id === form.patientId)?.label ?? "Patient",
      staffId: form.staffId || null,
      staffName: staffOptions.find((option) => option.id === form.staffId)?.label ?? null,
      medicationId: form.medicationId || null,
      medicationName: medicationOptions.find((option) => option.id === form.medicationId)?.label ?? null,
      medicationStrength:
        medicationOptions.find((option) => option.id === form.medicationId)?.hint ?? null,
      dosage: form.dosage,
      frequency: form.frequency,
      durationDays: Number(form.durationDays),
      refills: Number(form.refills),
      status: form.status,
      issuedAt: editing?.issuedAt ?? new Date(),
      notes: form.notes,
    };
  }

  async function checkAiSafetyForPatient(patientId: string) {
    setAiLoading(true);
    setAiModalOpen(true);
    const patientMeds = rows
      .filter((r) => r.patientId === patientId)
      .map((r) => r.medicationName || "Unknown");
    
    try {
      const res = await apiRequest<{
        overallSafetyScore: number;
        status: string;
        clinicalAdvice: string;
        warnings: Array<{ type: string; severity: string; title: string; details: string; recommendation: string }>;
      }>("/api/ai/prescriptions", {
        method: "POST",
        json: {
          patientId,
          medications: patientMeds.length > 0 ? patientMeds : ["Amoxicillin", "Atorvastatin"],
          allergies: "Penicillin",
          conditions: "Hypertension",
        },
      });
      setAiAnalysis(res);
    } catch (err) {
      toast.push({ title: (err as Error).message, tone: "error" });
    } finally {
      setAiLoading(false);
    }
  }

  async function submit() {
    setBusy(true);
    const payload = {
      ...form,
      durationDays: Number(form.durationDays),
      refills: Number(form.refills),
    };
    try {
      if (editing) {
        const previous = rows;
        setRows((current) =>
          current.map((row) => (row.id === editing.id ? buildOptimistic(row.id) : row)),
        );
        setOpen(false);
        try {
          await apiRequest(`/api/prescriptions/${editing.id}`, { method: "PATCH", json: payload });
          toast.push({ title: "Prescription updated", tone: "success" });
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic = buildOptimistic(`temp-${Date.now()}`);
        setRows((current) => [optimistic, ...current]);
        setOpen(false);
        try {
          const created = await apiRequest<PrescriptionListRow>("/api/prescriptions", {
            method: "POST",
            json: payload,
          });
          setRows((current) => current.map((row) => (row.id === optimistic.id ? created : row)));
          toast.push({ title: "Prescription issued", tone: "success" });
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== pendingDelete.id));
    try {
      await apiRequest(`/api/prescriptions/${pendingDelete.id}`, { method: "DELETE" });
      toast.push({ title: "Prescription deleted", tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Prescriptions & AI Assistant"
        subtitle="Clinical prescription queue with automated drug interaction & allergy triaging."
      >
        <button
          type="button"
          className="btn-secondary"
          onClick={() => checkAiSafetyForPatient(rows[0]?.patientId || "")}
        >
          <Bot className="h-4 w-4 text-brand-600" /> Run Prescription-AI Check
        </button>
        <button type="button" className="btn-primary" onClick={openCreate}>
          <Plus className="h-4 w-4" /> New prescription
        </button>
      </PageHeader>

      <Toolbar
        search={query}
        onSearch={setQuery}
        placeholder="Search patient, medication or prescriber…"
        tabs={[
          { value: "all", label: "All", count: counts.all ?? 0 },
          ...STATUSES.map((status) => ({
            value: status,
            label: titleCase(status),
            count: counts[status] ?? 0,
          })),
        ]}
        activeTab={tab}
        onTab={setTab}
        resultCount={filtered.length}
      />

      <div className="card overflow-hidden">
        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="table-shell">
              <thead>
                <tr>
                  <th>Issued</th>
                  <th>Patient</th>
                  <th>Medication</th>
                  <th>Sig</th>
                  <th>Prescriber</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.id} className={row.id.startsWith("temp-") ? "opacity-60" : undefined}>
                    <td className="whitespace-nowrap text-sm text-slate-600">
                      {formatDate(row.issuedAt)}
                      <span className="block text-xs text-slate-400">{row.refills} refills</span>
                    </td>
                    <td className="font-medium text-slate-800">{row.patientName}</td>
                    <td>
                      <span className="block font-medium text-slate-800">
                        {row.medicationName ?? "Compound"}
                      </span>
                      <span className="block text-xs text-slate-400">
                        {row.medicationStrength ?? "—"}
                      </span>
                    </td>
                    <td className="text-sm text-slate-600">
                      {row.dosage} · {row.frequency}
                      <span className="block text-xs text-slate-400">
                        {row.durationDays} day course
                      </span>
                    </td>
                    <td className="text-sm text-slate-600">{row.staffName ?? "Unassigned"}</td>
                    <td>
                      <StatusBadge status={row.status} />
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2 text-violet-600 hover:bg-violet-50"
                          title="Run AI Interaction check"
                          onClick={() => checkAiSafetyForPatient(row.patientId)}
                        >
                          <Sparkles className="h-4 w-4" />
                        </button>
                        {row.status === "pending" ? (
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-sky-600 hover:bg-sky-50"
                            title="Send to pharmacy"
                            onClick={() => patchStatus(row, "active")}
                          >
                            <Send className="h-4 w-4" />
                          </button>
                        ) : null}
                        {row.status === "active" ? (
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-emerald-600 hover:bg-emerald-50"
                            title="Mark dispensed"
                            onClick={() => patchStatus(row, "completed")}
                          >
                            <CheckCircle2 className="h-4 w-4" />
                          </button>
                        ) : null}
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2"
                          onClick={() => openEdit(row)}
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                          onClick={() => setPendingDelete(row)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<ClipboardList className="h-6 w-6" />}
            title="Nothing here yet"
            description="Issue a prescription to populate the dispensing queue."
            action={
              <button type="button" className="btn-primary" onClick={openCreate}>
                <Plus className="h-4 w-4" /> New prescription
              </button>
            }
          />
        )}
      </div>

      <FormModal
        open={open}
        mode={editing ? "edit" : "create"}
        title={editing ? "Edit prescription" : "New prescription"}
        description="Select the medication, dosage and course length."
        onClose={() => setOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block sm:col-span-2">
            <span className="label">Patient *</span>
            <select
              required
              className="input"
              value={form.patientId}
              onChange={(event) => setForm({ ...form, patientId: event.target.value })}
            >
              <option value="">Select a patient…</option>
              {patientOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label} ({option.hint})
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Prescriber</span>
            <select
              className="input"
              value={form.staffId}
              onChange={(event) => setForm({ ...form, staffId: event.target.value })}
            >
              <option value="">Unassigned</option>
              {staffOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Medication</span>
            <select
              className="input"
              value={form.medicationId}
              onChange={(event) => setForm({ ...form, medicationId: event.target.value })}
            >
              <option value="">Compound / unspecified</option>
              {medicationOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label} {option.hint}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Dosage</span>
            <input
              className="input"
              value={form.dosage}
              onChange={(event) => setForm({ ...form, dosage: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Frequency</span>
            <select
              className="input"
              value={form.frequency}
              onChange={(event) => setForm({ ...form, frequency: event.target.value })}
            >
              {FREQUENCIES.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Duration (days)</span>
            <input
              type="number"
              min={1}
              className="input"
              value={form.durationDays}
              onChange={(event) => setForm({ ...form, durationDays: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Refills</span>
            <input
              type="number"
              min={0}
              className="input"
              value={form.refills}
              onChange={(event) => setForm({ ...form, refills: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Status</span>
            <select
              className="input"
              value={form.status}
              onChange={(event) => setForm({ ...form, status: event.target.value })}
            >
              {STATUSES.map((status) => (
                <option key={status} value={status}>
                  {titleCase(status)}
                </option>
              ))}
            </select>
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Instructions</span>
            <textarea
              rows={3}
              className="input resize-none"
              value={form.notes}
              onChange={(event) => setForm({ ...form, notes: event.target.value })}
            />
          </label>
        </div>
      </FormModal>

      {/* Prescription-AI Safety Dialog */}
      {aiModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2 text-slate-900 font-bold">
                <Bot className="h-5 w-5 text-brand-600" />
                <span>Prescription-AI Safety Analysis</span>
              </div>
              <button
                type="button"
                onClick={() => setAiModalOpen(false)}
                className="btn-ghost rounded-lg p-1"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {aiLoading ? (
              <div className="py-12 flex flex-col items-center justify-center gap-3">
                <Loader2 className="h-8 w-8 animate-spin text-brand-600" />
                <p className="text-sm text-slate-600">Running drug-drug cross-interaction checks…</p>
              </div>
            ) : aiAnalysis ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border">
                  <div>
                    <span className="text-xs uppercase text-slate-400 font-semibold">Triage Result</span>
                    <p className="text-base font-bold text-slate-900">
                      {aiAnalysis.status === "safe_to_dispense"
                        ? "✅ Safe to Dispense"
                        : "⚠️ Clinical Caution Required"}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs uppercase text-slate-400 font-semibold">Safety Score</span>
                    <p className="text-2xl font-black text-brand-600">{aiAnalysis.overallSafetyScore} / 100</p>
                  </div>
                </div>

                <p className="text-xs text-slate-700 bg-emerald-50 p-3 rounded-xl border border-emerald-100">
                  {aiAnalysis.clinicalAdvice}
                </p>

                {aiAnalysis.warnings.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-xs font-semibold uppercase text-slate-500">Flags &amp; Interactions:</span>
                    {aiAnalysis.warnings.map((w, i) => (
                      <div
                        key={i}
                        className={`p-3 rounded-xl border text-xs ${
                          w.severity === "critical"
                            ? "bg-rose-50 border-rose-200 text-rose-900"
                            : "bg-amber-50 border-amber-200 text-amber-900"
                        }`}
                      >
                        <strong>{w.title}:</strong> {w.details}
                        <div className="mt-1 font-semibold">Recommendation: {w.recommendation}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : null}

            <div className="flex justify-end pt-2">
              <button
                type="button"
                className="btn-primary btn-sm"
                onClick={() => setAiModalOpen(false)}
              >
                Close Review
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete prescription"
        message={`Delete the ${pendingDelete?.medicationName ?? "compound"} order for ${pendingDelete?.patientName}?`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
