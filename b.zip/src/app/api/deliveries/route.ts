import { createCollectionRoute } from "@/lib/crud";
import { deliveryResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createCollectionRoute(deliveryResource);

export const GET = handlers.GET;
export const POST = handlers.POST;
