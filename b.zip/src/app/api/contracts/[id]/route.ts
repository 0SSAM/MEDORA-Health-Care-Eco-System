import { createItemRoute } from "@/lib/crud";
import { contractResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createItemRoute(contractResource);

export const GET = handlers.GET;
export const PATCH = handlers.PATCH;
export const DELETE = handlers.DELETE;
