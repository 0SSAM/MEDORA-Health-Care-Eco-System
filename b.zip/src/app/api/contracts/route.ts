import { createCollectionRoute } from "@/lib/crud";
import { contractResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createCollectionRoute(contractResource);

export const GET = handlers.GET;
export const POST = handlers.POST;
