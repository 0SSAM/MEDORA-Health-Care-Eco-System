import { getCurrentUser, logActivity } from "@/lib/auth";
import { aiPrescriptionCheckSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

const INTERACTION_DATABASE: Record<string, { interactWith: string[]; risk: "high" | "moderate" | "low"; warning: string; suggestion: string }> = {
  amoxicillin: {
    interactWith: ["methotrexate", "warfarin", "allopurinol"],
    risk: "moderate",
    warning: "Potential increased toxicity or altered anticoagulant response.",
    suggestion: "Monitor INR if on anticoagulants; check renal parameters.",
  },
  atorvastatin: {
    interactWith: ["clarithromycin", "erythromycin", "itraconazole", "grapefruit", "diltiazem"],
    risk: "high",
    warning: "CYP3A4 inhibition drastically increases statin plasma levels, elevating risk of rhabdomyolysis.",
    suggestion: "Temporarily pause statin during macrolide antibiotic course or reduce dose.",
  },
  metformin: {
    interactWith: ["contrast_dye", "cimetidine", "alcohol"],
    risk: "high",
    warning: "Risk of lactic acidosis, especially in patients with acute renal impairment or IV iodinated contrast.",
    suggestion: "Withhold metformin 48 hours before and after radiocontrast procedures.",
  },
  amlodipine: {
    interactWith: ["simvastatin", "tacrolimus", "clarithromycin"],
    risk: "moderate",
    warning: "May increase simvastatin exposure (limit simvastatin to 20mg daily).",
    suggestion: "Adjust statin dosage or monitor blood pressure and peripheral edema.",
  },
  ibuprofen: {
    interactWith: ["aspirin", "losartan", "enalapril", "warfarin", "prednisolone"],
    risk: "high",
    warning: "Concurrent NSAID with ACEi/ARB causes renal vasoconstriction and blunts antihypertensive effect; with steroids/warfarin increases GI hemorrhage risk.",
    suggestion: "Substitute with paracetamol for pain control or add PPI gastroprotection.",
  },
  losartan: {
    interactWith: ["ibuprofen", "spironolactone", "potassium_supplements"],
    risk: "high",
    warning: "Risk of hyperkalemia and acute kidney injury.",
    suggestion: "Monitor serum potassium and creatinine within 7 days.",
  },
  enoxaparin: {
    interactWith: ["aspirin", "ibuprofen", "clopidogrel"],
    risk: "high",
    warning: "Major additive antiplatelet/anticoagulant bleeding risk.",
    suggestion: "Assess bleeding score and monitor platelets.",
  },
};

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  const parsed = aiPrescriptionCheckSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }

  const { medications, allergies, conditions } = parsed.data;
  const warnings: Array<{
    type: "interaction" | "allergy" | "condition";
    severity: "critical" | "warning" | "info";
    title: string;
    details: string;
    recommendation: string;
  }> = [];

  const medsLower = medications.map((m) => m.toLowerCase());
  const allergyLower = (allergies || "").toLowerCase();
  const conditionsLower = (conditions || "").toLowerCase();

  // 1. Check Allergies
  for (const med of medsLower) {
    if (allergyLower.includes("penicillin") && (med.includes("amoxicillin") || med.includes("ampicillin") || med.includes("augmentin"))) {
      warnings.push({
        type: "allergy",
        severity: "critical",
        title: `Allergy Alert: Penicillin vs ${med}`,
        details: `Patient has documented Penicillin allergy. Beta-lactam antibiotic detected.`,
        recommendation: "Substitute with macrolide (e.g. Azithromycin) or fluoroquinolone.",
      });
    }
    if (allergyLower.includes("aspirin") && med.includes("ibuprofen")) {
      warnings.push({
        type: "allergy",
        severity: "critical",
        title: `Cross-Reactivity: NSAID sensitivity`,
        details: `Patient allergic to Aspirin. High cross-reactivity with Ibuprofen/NSAIDs.`,
        recommendation: "Avoid all non-steroidal anti-inflammatories; use Paracetamol.",
      });
    }
  }

  // 2. Check Conditions
  for (const med of medsLower) {
    if (conditionsLower.includes("asthma") && (med.includes("ibuprofen") || med.includes("aspirin") || med.includes("metoprolol"))) {
      warnings.push({
        type: "condition",
        severity: "warning",
        title: `Condition Warning: Asthma Precaution`,
        details: `${med} may trigger bronchospasm in susceptible asthmatic patients.`,
        recommendation: "Use selective cardioselective agents or alternative analgesics.",
      });
    }
    if (conditionsLower.includes("diabetes") && (med.includes("prednisolone") || med.includes("dexamethasone"))) {
      warnings.push({
        type: "condition",
        severity: "warning",
        title: `Condition Warning: Steroid-Induced Hyperglycemia`,
        details: `Corticosteroids elevate blood glucose levels significantly.`,
        recommendation: "Increase capillary blood glucose monitoring frequency and titrate insulin/oral agents.",
      });
    }
  }

  // 3. Check Drug-Drug Interactions
  for (let i = 0; i < medsLower.length; i++) {
    for (let j = 0; j < medsLower.length; j++) {
      if (i === j) continue;
      const medA = medsLower[i];
      const medB = medsLower[j];

      for (const [key, rule] of Object.entries(INTERACTION_DATABASE)) {
        if (medA.includes(key)) {
          for (const target of rule.interactWith) {
            if (medB.includes(target)) {
              warnings.push({
                type: "interaction",
                severity: rule.risk === "high" ? "critical" : "warning",
                title: `Drug Interaction: ${medA} + ${medB}`,
                details: rule.warning,
                recommendation: rule.suggestion,
              });
            }
          }
        }
      }
    }
  }

  // Deduplicate warnings
  const uniqueWarnings = warnings.filter(
    (w, idx, self) => self.findIndex((s) => s.title === w.title) === idx,
  );

  const aiSummary = {
    analyzedAt: new Date().toISOString(),
    overallSafetyScore: uniqueWarnings.some((w) => w.severity === "critical")
      ? 45
      : uniqueWarnings.length > 0
        ? 80
        : 98,
    status: uniqueWarnings.some((w) => w.severity === "critical")
      ? "contraindicated"
      : uniqueWarnings.length > 0
        ? "caution_advised"
        : "safe_to_dispense",
    warnings: uniqueWarnings,
    clinicalAdvice:
      uniqueWarnings.length === 0
        ? "No adverse interactions or allergy conflicts detected. Safe to administer with standard dosage schedule."
        : "Clinical review required prior to dispensing due to flagged interactions.",
  };

  await logActivity({
    actorName: user.name,
    action: "ran AI prescription analysis",
    entity: "ai_prescription",
    detail: `Analyzed ${medications.length} items (${uniqueWarnings.length} flags)`,
  });

  return Response.json({ data: aiSummary });
}
