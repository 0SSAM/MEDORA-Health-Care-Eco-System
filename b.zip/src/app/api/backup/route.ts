import { db } from "@/db";
import {
  appointments,
  deliveries,
  insuranceClaims,
  invoices,
  medicalContracts,
  medications,
  patients,
  prescriptions,
  staff,
  users,
} from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const [
    allPatients,
    allStaff,
    allAppts,
    allMeds,
    allPrescriptions,
    allInvoices,
    allClaims,
    allContracts,
    allDeliveries,
  ] = await Promise.all([
    db.select().from(patients),
    db.select().from(staff),
    db.select().from(appointments),
    db.select().from(medications),
    db.select().from(prescriptions),
    db.select().from(invoices),
    db.select().from(insuranceClaims),
    db.select().from(medicalContracts),
    db.select().from(deliveries),
  ]);

  const backupPayload = {
    version: "2.5.0-medora-portable",
    exportedAt: new Date().toISOString(),
    exportedBy: user.email,
    data: {
      patients: allPatients,
      staff: allStaff,
      appointments: allAppts,
      medications: allMeds,
      prescriptions: allPrescriptions,
      invoices: allInvoices,
      insuranceClaims: allClaims,
      medicalContracts: allContracts,
      deliveries: allDeliveries,
    },
  };

  return new Response(JSON.stringify(backupPayload, null, 2), {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="medora-backup-${new Date().toISOString().slice(0, 10)}.json"`,
    },
  });
}
