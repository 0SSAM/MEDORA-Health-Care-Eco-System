"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { AlertTriangle, ArrowRight, Download, Loader2, LogIn, ShieldCheck } from "lucide-react";

import { apiRequest } from "@/lib/client";

const QUICK_ACCOUNTS = [
  { label: "Admin (admin / admin)", username: "admin", email: "admin", password: "admin" },
  { label: "Doctor", username: "doctor", email: "doctor@medora.health", password: "admin" },
  { label: "Pharmacy", username: "pharmacy", email: "pharmacy@medora.health", password: "admin" },
  { label: "Billing", username: "billing", email: "billing@medora.health", password: "admin" },
  { label: "Reception", username: "reception", email: "reception@medora.health", password: "admin" },
];

export default function LoginForm() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState("admin");
  const [password, setPassword] = useState("admin");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [pending, startTransition] = useTransition();

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await apiRequest("/api/auth/login", {
        method: "POST",
        json: { email: identifier, password },
      });
      startTransition(() => {
        router.replace("/dashboard");
        router.refresh();
      });
    } catch (cause) {
      setError((cause as Error).message);
      setSubmitting(false);
    }
  }

  const busy = submitting || pending;

  return (
    <form onSubmit={submit} className="mt-6 space-y-4">
      <div>
        <label className="label">Quick Role Switcher / حسابات تجريبية</label>
        <div className="flex flex-wrap gap-1.5">
          {QUICK_ACCOUNTS.map((account) => (
            <button
              key={account.label}
              type="button"
              onClick={() => {
                setIdentifier(account.username);
                setPassword(account.password);
              }}
              className={`btn btn-sm text-xs ${
                identifier === account.username || identifier === account.email
                  ? "bg-brand-50 text-brand-700 ring-1 ring-inset ring-brand-200 font-bold"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              {account.label}
            </button>
          ))}
        </div>
      </div>

      <label className="block">
        <span className="label">Username or Work Email / اسم المستخدم أو البريد</span>
        <input
          type="text"
          required
          autoComplete="username"
          value={identifier}
          onChange={(event) => setIdentifier(event.target.value)}
          className="input font-medium"
          placeholder="admin or admin@medora.health"
        />
      </label>

      <label className="block">
        <span className="label">Password / كلمة المرور</span>
        <input
          type="password"
          required
          autoComplete="current-password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          className="input font-medium"
          placeholder="admin"
        />
      </label>

      {error ? (
        <p className="flex items-start gap-2 rounded-xl bg-rose-50 px-3 py-2.5 text-sm text-rose-700 ring-1 ring-inset ring-rose-100">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          {error}
        </p>
      ) : null}

      <button type="submit" className="btn-primary w-full py-2.5" disabled={busy}>
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4 text-white" />}
        {busy ? "Opening Clinical Workspace…" : "Sign In / تسجيل الدخول"}
        {busy ? null : <ArrowRight className="h-4 w-4" />}
      </button>

      <div className="pt-2">
        <a
          href="/medora-offline-standalone.html"
          target="_blank"
          rel="noreferrer"
          className="btn-secondary w-full py-2 text-xs text-emerald-700 hover:bg-emerald-50 border-emerald-200 flex items-center justify-center gap-2"
        >
          <Download className="h-3.5 w-3.5 text-emerald-600" />
          <span>Launch Standalone Offline Edition (.html / portable)</span>
        </a>
      </div>
    </form>
  );
}
