import Link from "next/link";
import { redirect } from "next/navigation";
import { Download, HeartPulse, ShieldCheck, Sparkles, Users, Zap } from "lucide-react";

import { ensureSeeded } from "@/db/seed";
import { getCurrentUser } from "@/lib/auth";
import LoginForm from "./LoginForm";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  await ensureSeeded();
  const user = await getCurrentUser();
  if (user) redirect("/dashboard");

  return (
    <main className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <section className="relative hidden overflow-hidden bg-ink-900 p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="grid-lines absolute inset-0 opacity-50" />
        <div className="absolute -left-24 top-24 h-96 w-96 rounded-full bg-brand-500/25 blur-3xl" />
        <div className="relative">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600">
              <HeartPulse className="h-5 w-5" />
            </span>
            <div>
              <span className="text-lg font-bold tracking-tight block">MEDORA HEALTH</span>
              <span className="text-[10px] text-emerald-400 tracking-wider font-semibold block">ميدورا - النظام الصحي المتكامل</span>
            </div>
          </Link>
          <h1 className="mt-14 max-w-md text-3xl font-semibold leading-tight tracking-tight">
            The clinical control room for your whole healthcare team.
          </h1>
          <p className="mt-3 max-w-md text-sm text-white/60">
            Patients CRM, Prescription-AI, Pharmacy inventory, Invoices, Medical Contracts, and Home Delivery Logistics.
          </p>
          <ul className="mt-8 space-y-3">
            {[
              { icon: ShieldCheck, text: "Administrator Login (username: admin / password: admin)" },
              { icon: Zap, text: "Prescription-AI with Drug-Drug interaction & allergy warnings" },
              { icon: Users, text: "26 seeded patients, 12 clinicians, live claims board & contracts" },
              { icon: Sparkles, text: "100% Offline Standalone Windows edition included" },
            ].map((item) => (
              <li key={item.text} className="flex items-center gap-3 text-xs text-white/80">
                <span className="grid h-8 w-8 place-items-center rounded-xl bg-white/10 ring-1 ring-inset ring-white/15">
                  <item.icon className="h-4 w-4 text-brand-200" />
                </span>
                {item.text}
              </li>
            ))}
          </ul>
        </div>
        
        <div className="relative pt-6 border-t border-white/10 flex items-center justify-between text-xs text-white/50">
          <span>MEDORA Health Care Eco-System · Open-Source</span>
          <a
            href="/medora-offline-standalone.html"
            download="medora-offline-standalone.html"
            className="text-emerald-300 hover:underline flex items-center gap-1"
          >
            <Download className="h-3.5 w-3.5" /> Offline File (.html)
          </a>
        </div>
      </section>

      <section className="flex items-center justify-center bg-slate-50 px-6 py-10">
        <div className="w-full max-w-md">
          <div className="card card-pad animate-fade-up">
            <h2 className="text-2xl font-bold tracking-tight text-slate-900">Sign In to MEDORA</h2>
            <p className="mt-1 text-xs text-slate-500">
              Integrated Hospital, Pharmacy &amp; CRM Workspace
            </p>
            <LoginForm />
          </div>

          <div className="mt-4 rounded-2xl border border-dashed border-slate-300 bg-white/70 p-3.5 text-xs text-slate-600">
            <p className="font-semibold text-slate-800">
              Admin Account:
            </p>
            <div className="mt-1 font-mono text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-200 inline-block">
              username: <strong>admin</strong> | password: <strong>admin</strong>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
