import Link from "next/link";
import { redirect } from "next/navigation";
import {
  Activity,
  ArrowRight,
  BadgeCheck,
  Bot,
  CalendarClock,
  Download,
  FileCheck2,
  HeartPulse,
  Pill,
  ShieldCheck,
  TestTube2,
  Truck,
  Wallet,
} from "lucide-react";

import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

const MODULES = [
  {
    icon: HeartPulse,
    title: "Patient CRM (سجل المرضى)",
    body: "Unified medical records, chronic conditions, allergies, and care team assignment.",
  },
  {
    icon: Bot,
    title: "Prescription-AI (الذكاء الاصطناعي)",
    body: "Automated drug-drug interaction checks, allergy cross-reactivity warnings, and clinical advice.",
  },
  {
    icon: CalendarClock,
    title: "Scheduling (المواعيد)",
    body: "Clinic, procedure and telemedicine bookings with live status tracking.",
  },
  {
    icon: Pill,
    title: "Pharmacy & Inventory (الصيدلية)",
    body: "Stock thresholds, batch numbers, expiry watch, and automated dispensing queue.",
  },
  {
    icon: Wallet,
    title: "Billing & POS (الفواتير)",
    body: "Invoices, patient co-pay calculations, payment methods, and revenue analytics.",
  },
  {
    icon: ShieldCheck,
    title: "Insurance Claims (التأمين)",
    body: "Payer submissions, adjudication workflow, pre-authorization, and settlements.",
  },
  {
    icon: FileCheck2,
    title: "Medical Contracts (العقود الطبية)",
    body: "Corporate healthcare partnerships, HMO agreements, and concession terms.",
  },
  {
    icon: Truck,
    title: "Delivery Logistics (توصيل الأدوية)",
    body: "Home dispatch tracking, cold-chain temperature monitoring, and courier verification.",
  },
  {
    icon: Activity,
    title: "Care Team & HR (الكادر الطبي)",
    body: "Clinician roster, departments, shifts, workload load-balancing, and licensing.",
  },
];

export default async function LandingPage() {
  const user = await getCurrentUser();
  if (user) redirect("/dashboard");

  return (
    <main className="relative min-h-screen overflow-hidden bg-ink-900 text-white">
      <div className="grid-lines absolute inset-0 opacity-60" />
      <div className="absolute -left-32 top-[-10rem] h-[28rem] w-[28rem] rounded-full bg-brand-500/25 blur-3xl" />
      <div className="absolute -right-24 bottom-[-12rem] h-[30rem] w-[30rem] rounded-full bg-sky-500/20 blur-3xl" />

      <div className="relative mx-auto flex max-w-6xl flex-col px-6 py-8">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600 shadow-lg shadow-brand-500/30">
              <HeartPulse className="h-5 w-5" />
            </span>
            <div>
              <p className="text-lg font-bold tracking-tight">MEDORA</p>
              <p className="text-[10px] uppercase tracking-[0.2em] text-emerald-400 font-semibold">
                Healthcare Eco-System
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <a
              href="/medora-offline-standalone.html"
              download="medora-offline-standalone.html"
              className="btn bg-white/10 text-xs text-white ring-1 ring-inset ring-white/20 hover:bg-white/20 hidden sm:inline-flex"
            >
              <Download className="h-3.5 w-3.5 text-emerald-400" /> Standalone (.html)
            </a>
            <Link href="/login" className="btn bg-brand-600 px-4 py-2 text-sm text-white hover:bg-brand-500">
              Sign in / الدخول
            </Link>
          </div>
        </header>

        <section className="mt-14 max-w-3xl animate-fade-up">
          <span className="badge bg-white/10 text-brand-200 ring-1 ring-inset ring-white/15">
            <BadgeCheck className="h-3.5 w-3.5" /> 100% Free &amp; Open-Source Healthcare Operating System
          </span>
          <h1 className="mt-5 text-[clamp(2.2rem,5.5vw,3.8rem)] font-bold leading-[1.05] tracking-tight">
            One unified workspace for your entire{" "}
            <span className="bg-gradient-to-r from-brand-300 to-sky-300 bg-clip-text text-transparent">
              clinical ecosystem
            </span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-white/75">
            ميدورا هو نظام تشغيلي متكامل للرعاية الصحية يربط بين إدارة المرضى (CRM)، الصيدلية، الفواتير، التأمين، العقود الطبية، وتوصيل الأدوية، مع ذكاء اصطناعي لتحليل تفاعلات الأدوية.
          </p>
          <div className="mt-7 flex flex-wrap items-center gap-3">
            <Link href="/login" className="btn bg-brand-500 px-5 py-2.5 text-white hover:bg-brand-400 font-semibold text-sm">
              Launch Workspace (admin / admin) <ArrowRight className="h-4 w-4" />
            </Link>
            <a
              href="/medora-offline-standalone.html"
              download="medora-offline-standalone.html"
              className="btn bg-white/10 px-4 py-2.5 text-white hover:bg-white/20 ring-1 ring-inset ring-white/20 text-sm font-semibold flex items-center gap-2"
            >
              <Download className="h-4 w-4 text-emerald-400" /> Download Windows Portable
            </a>
          </div>
        </section>

        <section className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {MODULES.map((module) => (
            <article
              key={module.title}
              className="group rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-all hover:-translate-y-1 hover:border-brand-400/40 hover:bg-white/[0.07]"
            >
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-brand-400/30 to-sky-400/20 text-brand-200 ring-1 ring-inset ring-white/10">
                <module.icon className="h-5 w-5" />
              </span>
              <h3 className="mt-3.5 text-sm font-semibold">{module.title}</h3>
              <p className="mt-1 text-xs leading-relaxed text-white/60">{module.body}</p>
            </article>
          ))}
        </section>

        <footer className="mt-16 border-t border-white/10 pt-6 pb-4 flex flex-wrap items-center justify-between text-xs text-white/40 gap-3">
          <div>
            MEDORA Health Care Eco-System · Built based on <a href="https://github.com/0SSAM/MEDORA-Health-Care-Eco-System" target="_blank" rel="noreferrer" className="text-white/60 underline">0SSAM/MEDORA-Health-Care-Eco-System</a>
          </div>
          <div>
            Admin: <code>admin</code> / <code>admin</code>
          </div>
        </footer>
      </div>
    </main>
  );
}
