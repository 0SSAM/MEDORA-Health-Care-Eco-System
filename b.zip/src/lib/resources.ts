import "server-only";

import {
  appointments,
  deliveries,
  insuranceClaims,
  invoices,
  medicalContracts,
  medications,
  patients,
  prescriptions,
  staff,
  users,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import type { ResourceConfig } from "@/lib/crud";
import {
  appointmentSchema,
  claimSchema,
  contractSchema,
  deliverySchema,
  invoiceSchema,
  medicationSchema,
  patientSchema,
  prescriptionSchema,
  staffSchema,
  userSchema,
  userUpdateSchema,
} from "@/lib/validation";

type Row = Record<string, unknown>;

export const patientResource: ResourceConfig = {
  entity: "patient",
  table: patients,
  idColumn: patients.id,
  createSchema: patientSchema,
  updateSchema: patientSchema.partial(),
  searchColumns: [
    patients.firstName,
    patients.lastName,
    patients.mrn,
    patients.phone,
    patients.email,
    patients.city,
  ],
  statusColumn: patients.status,
  orderColumn: patients.createdAt,
  describe: (row) =>
    `${String(row.firstName ?? "")} ${String(row.lastName ?? "")}`.trim(),
  extra: (values, mode) => {
    const next = { ...values };
    if (mode === "create" && !next.mrn) {
      next.mrn = `MRN-${Math.floor(100000 + Math.random() * 899999)}`;
    }
    next.updatedAt = new Date();
    return next;
  },
};

export const staffResource: ResourceConfig = {
  entity: "staff member",
  table: staff,
  idColumn: staff.id,
  createSchema: staffSchema,
  updateSchema: staffSchema.partial(),
  searchColumns: [
    staff.fullName,
    staff.email,
    staff.department,
    staff.specialty,
    staff.title,
  ],
  statusColumn: staff.status,
  orderColumn: staff.fullName,
  describe: (row) => `${String(row.fullName ?? "")} · ${String(row.title ?? "")}`,
};

export const appointmentResource: ResourceConfig = {
  entity: "appointment",
  table: appointments,
  idColumn: appointments.id,
  createSchema: appointmentSchema,
  updateSchema: appointmentSchema.partial(),
  searchColumns: [appointments.reason, appointments.room, appointments.type],
  statusColumn: appointments.status,
  orderColumn: appointments.scheduledAt,
  describe: (row) => `${String(row.reason ?? "")} · ${String(row.room ?? "")}`,
};

export const medicationResource: ResourceConfig = {
  entity: "medication",
  table: medications,
  idColumn: medications.id,
  createSchema: medicationSchema,
  updateSchema: medicationSchema.partial(),
  searchColumns: [
    medications.name,
    medications.category,
    medications.manufacturer,
    medications.supplier,
    medications.strength,
  ],
  orderColumn: medications.name,
  describe: (row) =>
    `${String(row.name ?? "")} ${String(row.strength ?? "")} · stock ${String(row.stock ?? 0)}`,
};

export const prescriptionResource: ResourceConfig = {
  entity: "prescription",
  table: prescriptions,
  idColumn: prescriptions.id,
  createSchema: prescriptionSchema,
  updateSchema: prescriptionSchema.partial(),
  searchColumns: [prescriptions.dosage, prescriptions.frequency],
  statusColumn: prescriptions.status,
  orderColumn: prescriptions.issuedAt,
  describe: (row) => `${String(row.dosage ?? "")} · ${String(row.frequency ?? "")}`,
  extra: (values, mode) => {
    const next = { ...values };
    if (mode === "create") next.issuedAt = new Date();
    return next;
  },
};

export const invoiceResource: ResourceConfig = {
  entity: "invoice",
  table: invoices,
  idColumn: invoices.id,
  createSchema: invoiceSchema,
  updateSchema: invoiceSchema.partial(),
  searchColumns: [
    invoices.invoiceNumber,
    invoices.itemsSummary,
    invoices.paymentMethod,
  ],
  statusColumn: invoices.status,
  orderColumn: invoices.issuedAt,
  describe: (row) =>
    `${String(row.invoiceNumber ?? "")} · ${String(row.itemsSummary ?? "")}`,
  extra: (values, mode) => {
    const next = { ...values };
    if (mode === "create" && !next.invoiceNumber) {
      next.invoiceNumber = `INV-2026-${Math.floor(1000 + Math.random() * 8999)}`;
    }
    if (next.status === "paid") next.paidAt = new Date();
    return next;
  },
};

export const claimResource: ResourceConfig = {
  entity: "insurance claim",
  table: insuranceClaims,
  idColumn: insuranceClaims.id,
  createSchema: claimSchema,
  updateSchema: claimSchema.partial(),
  searchColumns: [insuranceClaims.claimNumber, insuranceClaims.provider],
  statusColumn: insuranceClaims.status,
  orderColumn: insuranceClaims.submittedAt,
  describe: (row) =>
    `${String(row.claimNumber ?? "")} · ${String(row.provider ?? "")}`,
  extra: (values, mode) => {
    const next = { ...values };
    if (mode === "create" && !next.claimNumber) {
      next.claimNumber = `CLM-2026-${Math.floor(1000 + Math.random() * 8999)}`;
    }
    next.decidedAt =
      next.status === "submitted" || next.status === "under_review"
        ? null
        : new Date();
    return next;
  },
};

export const contractResource: ResourceConfig = {
  entity: "medical contract",
  table: medicalContracts,
  idColumn: medicalContracts.id,
  createSchema: contractSchema,
  updateSchema: contractSchema.partial(),
  searchColumns: [
    medicalContracts.partnerOrganization,
    medicalContracts.contractNumber,
    medicalContracts.contactPerson,
    medicalContracts.contactEmail,
  ],
  statusColumn: medicalContracts.status,
  orderColumn: medicalContracts.createdAt,
  describe: (row) =>
    `${String(row.contractNumber ?? "")} · ${String(row.partnerOrganization ?? "")}`,
  extra: (values, mode) => {
    const next = { ...values };
    if (mode === "create" && !next.contractNumber) {
      next.contractNumber = `CTR-2026-${Math.floor(500 + Math.random() * 499)}`;
    }
    return next;
  },
};

export const deliveryResource: ResourceConfig = {
  entity: "medication delivery",
  table: deliveries,
  idColumn: deliveries.id,
  createSchema: deliverySchema,
  updateSchema: deliverySchema.partial(),
  searchColumns: [
    deliveries.trackingNumber,
    deliveries.recipientName,
    deliveries.courierName,
    deliveries.deliveryAddress,
  ],
  statusColumn: deliveries.status,
  orderColumn: deliveries.createdAt,
  describe: (row) =>
    `${String(row.trackingNumber ?? "")} · ${String(row.recipientName ?? "")}`,
  extra: (values, mode) => {
    const next = { ...values };
    if (mode === "create" && !next.trackingNumber) {
      next.trackingNumber = `MED-EXP-2026-${Math.floor(10000 + Math.random() * 89999)}`;
    }
    if (next.status === "delivered") next.deliveredAt = new Date();
    return next;
  },
};

export const userResource: ResourceConfig = {
  entity: "team member",
  table: users,
  idColumn: users.id,
  createSchema: userSchema,
  updateSchema: userUpdateSchema,
  searchColumns: [users.name, users.email, users.username, users.department],
  statusColumn: users.isActive,
  orderColumn: users.createdAt,
  describe: (row) => `${String(row.name ?? "")} · ${String(row.email ?? "")}`,
  extra: (values, mode) => {
    const { password, ...rest } = values as { password?: string } & Row;
    const next: Row = {
      ...(rest as Row),
      email: String((rest as Row).email ?? "").toLowerCase(),
    };
    if (password) next.passwordHash = hashPassword(password);
    void mode;
    return next;
  },
};
