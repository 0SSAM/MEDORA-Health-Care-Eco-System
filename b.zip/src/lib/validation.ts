import { z } from "zod";

export const PATIENT_STATUSES = ["active", "recovering", "critical", "inactive"] as const;
export const STAFF_STATUSES = ["on_duty", "available", "on_leave", "off_duty"] as const;
export const APPOINTMENT_STATUSES = ["scheduled", "confirmed", "completed", "cancelled", "no_show"] as const;
export const APPOINTMENT_TYPES = ["consultation", "follow_up", "telemedicine", "procedure", "annual_checkup", "lab_review"] as const;
export const PRESCRIPTION_STATUSES = ["pending", "active", "completed", "cancelled"] as const;
export const INVOICE_STATUSES = ["draft", "pending", "paid", "overdue", "void"] as const;
export const CLAIM_STATUSES = ["submitted", "under_review", "approved", "rejected", "paid"] as const;
export const CONTRACT_STATUSES = ["active", "pending_review", "expired", "terminated"] as const;
export const DELIVERY_STATUSES = ["pending", "dispatched", "in_transit", "delivered", "failed"] as const;
export const USER_ROLES = ["admin", "doctor", "nurse", "pharmacist", "billing", "front_desk"] as const;

const optionalText = z.coerce.string().optional();

export const patientSchema = z.object({
  firstName: z.string().min(2, "First name is required"),
  lastName: z.string().min(2, "Last name is required"),
  email: optionalText,
  phone: optionalText,
  gender: z.enum(["female", "male"]).default("female"),
  dateOfBirth: z.string().min(4, "Date of birth is required"),
  bloodType: z.coerce.string().default("O+"),
  city: z.coerce.string().default("Riyadh"),
  address: optionalText,
  insuranceProvider: z.coerce.string().default("Self-pay"),
  insuranceNumber: optionalText,
  allergies: optionalText,
  conditions: optionalText,
  status: z.enum(PATIENT_STATUSES).default("active"),
  riskLevel: z.enum(["low", "moderate", "high"]).default("low"),
  primaryStaffId: optionalText,
  notes: optionalText,
});

export const staffSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  email: optionalText,
  phone: optionalText,
  title: z.coerce.string().default("Clinician"),
  department: z.coerce.string().default("General Medicine"),
  specialty: z.coerce.string().default("General"),
  licenseNumber: optionalText,
  shift: z.coerce.string().default("Morning"),
  status: z.enum(STAFF_STATUSES).default("available"),
  rating: z.coerce.string().default("4.50"),
  patientsAssigned: z.coerce.number().int().min(0).default(0),
  hireDate: z.string().min(4),
});

export const appointmentSchema = z.object({
  patientId: z.string().min(1, "Select a patient"),
  staffId: optionalText,
  scheduledAt: z.coerce.date(),
  durationMinutes: z.coerce.number().int().min(5).max(480).default(30),
  type: z.enum(APPOINTMENT_TYPES).default("consultation"),
  status: z.enum(APPOINTMENT_STATUSES).default("scheduled"),
  reason: z.coerce.string().default("General consultation"),
  room: z.coerce.string().default("OPD-1"),
  notes: optionalText,
});

export const medicationSchema = z.object({
  name: z.string().min(2, "Medication name is required"),
  category: z.coerce.string().default("General"),
  form: z.enum(["tablet", "capsule", "syrup", "injection", "inhaler", "topical"]).default("tablet"),
  strength: z.coerce.string().default("500mg"),
  manufacturer: z.coerce.string().default("Medora Labs"),
  batchNumber: optionalText,
  supplier: z.coerce.string().default("Medora Supply Co."),
  stock: z.coerce.number().int().min(0).default(0),
  reorderLevel: z.coerce.number().int().min(0).default(40),
  unitPrice: z.coerce.string().default("0"),
  expiryDate: z.string().min(4),
});

export const prescriptionSchema = z.object({
  patientId: z.string().min(1, "Select a patient"),
  staffId: optionalText,
  medicationId: optionalText,
  dosage: z.coerce.string().default("1 tablet"),
  frequency: z.coerce.string().default("Once daily"),
  durationDays: z.coerce.number().int().min(1).max(365).default(7),
  refills: z.coerce.number().int().min(0).max(12).default(0),
  status: z.enum(PRESCRIPTION_STATUSES).default("pending"),
  notes: optionalText,
});

export const invoiceSchema = z.object({
  patientId: z.string().min(1, "Select a patient"),
  amount: z.coerce.string().default("0"),
  insuranceCovered: z.coerce.string().default("0"),
  status: z.enum(INVOICE_STATUSES).default("pending"),
  itemsSummary: z.coerce.string().default("Consultation"),
  paymentMethod: z.enum(["card", "cash", "insurance", "bank_transfer"]).default("card"),
  dueDate: z.string().min(4),
  invoiceNumber: optionalText,
});

export const claimSchema = z.object({
  patientId: z.string().min(1, "Select a patient"),
  provider: z.coerce.string().default("MedGulf"),
  amount: z.coerce.string().default("0"),
  approvedAmount: z.coerce.string().default("0"),
  status: z.enum(CLAIM_STATUSES).default("submitted"),
  notes: optionalText,
  claimNumber: optionalText,
});

export const contractSchema = z.object({
  partnerOrganization: z.string().min(2, "Partner name is required"),
  contractType: z.coerce.string().default("corporate"),
  contactPerson: optionalText,
  contactEmail: optionalText,
  contactPhone: optionalText,
  discountRate: z.coerce.string().default("15.00"),
  annualValue: z.coerce.string().default("50000.00"),
  status: z.enum(CONTRACT_STATUSES).default("active"),
  startDate: z.string().min(4),
  endDate: z.string().min(4),
  termsSummary: optionalText,
  contractNumber: optionalText,
});

export const deliverySchema = z.object({
  patientId: z.string().min(1, "Select a patient"),
  prescriptionId: optionalText,
  courierName: z.coerce.string().default("Medora Express Logistics"),
  recipientName: z.string().min(2, "Recipient name is required"),
  deliveryAddress: z.string().min(3, "Delivery address is required"),
  recipientPhone: optionalText,
  status: z.enum(DELIVERY_STATUSES).default("pending"),
  temperatureControl: z.coerce.string().default("ambient"),
  notes: optionalText,
  trackingNumber: optionalText,
});

export const userSchema = z.object({
  name: z.string().min(2, "Name is required"),
  username: z.string().min(2).default("admin"),
  email: z.string().min(3, "Email is required"),
  password: z.string().min(1, "Password is required"),
  role: z.enum(USER_ROLES).default("front_desk"),
  department: z.coerce.string().default("General"),
  phone: optionalText,
  isActive: z.coerce.boolean().default(true),
});

export const userUpdateSchema = userSchema
  .extend({ password: z.string().optional() })
  .partial();

export const loginSchema = z.object({
  email: z.string().min(1, "Username or email is required"),
  password: z.string().min(1, "Password is required"),
});

export const aiPrescriptionCheckSchema = z.object({
  patientId: z.string().optional(),
  medications: z.array(z.string()).min(1, "At least one medication is required"),
  allergies: z.string().optional(),
  conditions: z.string().optional(),
  patientAge: z.number().optional(),
});
