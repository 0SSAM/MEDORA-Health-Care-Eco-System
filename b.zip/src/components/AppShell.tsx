"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import {
  Activity,
  CalendarClock,
  ClipboardList,
  Download,
  FileCheck2,
  HeartPulse,
  LayoutDashboard,
  LogOut,
  Menu,
  Pill,
  Search,
  Settings,
  ShieldCheck,
  Stethoscope,
  TestTube2,
  Truck,
  Users,
  Wallet,
  X,
} from "lucide-react";

import { ROLE_LABELS } from "@/lib/roles";
import { cn, gradientFor, initials } from "@/lib/utils";
import { Avatar } from "@/components/ui";
import { apiRequest } from "@/lib/client";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, hint: "Clinical overview" },
  { href: "/patients", label: "Patients CRM", icon: Users, hint: "Records & triage" },
  { href: "/appointments", label: "Appointments", icon: CalendarClock, hint: "Scheduling & OPD" },
  { href: "/prescriptions", label: "Prescription & AI", icon: ClipboardList, hint: "Rx & interactions" },
  { href: "/pharmacy", label: "Pharmacy", icon: Pill, hint: "Catalogue & stock" },
  { href: "/billing", label: "Billing & POS", icon: Wallet, hint: "Invoices & co-pay" },
  { href: "/claims", label: "Insurance", icon: ShieldCheck, hint: "Payer claims" },
  { href: "/contracts", label: "Medical Contracts", icon: FileCheck2, hint: "Corporate & HMOs" },
  { href: "/deliveries", label: "Delivery Logistics", icon: Truck, hint: "Dispatch & tracking" },
  { href: "/staff", label: "Care Team (HR)", icon: Stethoscope, hint: "Roster & shifts" },
  { href: "/diagnostics", label: "System Tests", icon: TestTube2, hint: "Visual & API tests" },
  { href: "/settings", label: "Access & Backup", icon: Settings, hint: "Users & portable" },
];

export default function AppShell({
  user,
  children,
}: {
  user: { name: string; email: string; role: string; department: string };
  children: ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [query, setQuery] = useState("");

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  async function signOut() {
    setSigningOut(true);
    try {
      await apiRequest("/api/auth/logout", { method: "POST" });
    } finally {
      router.replace("/login");
      router.refresh();
    }
  }

  const activeNav = NAV.reduce((best, item) => {
    if (pathname === item.href || pathname.startsWith(`${item.href}/`)) {
      return item.href.length > (best?.href.length ?? 0) ? item : best;
    }
    return best;
  }, NAV[0]);

  const sidebar = (
    <div className="flex h-full flex-col gap-5 bg-ink-900 px-3.5 py-5">
      <div className="flex items-center justify-between px-2">
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600 shadow-lg shadow-brand-500/20">
            <HeartPulse className="h-5 w-5 text-white" />
          </span>
          <span>
            <span className="block text-base font-bold tracking-tight text-white">MEDORA</span>
            <span className="block text-[9.5px] uppercase tracking-[0.2em] text-emerald-400 font-semibold">
              Ecosystem · Offline Ready
            </span>
          </span>
        </Link>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto pr-1">
        {NAV.map((item) => {
          const active = activeNav?.href === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn("nav-link py-2 text-[13.5px]", active && "nav-link-active")}
            >
              <item.icon
                className={cn(
                  "h-[17px] w-[17px] shrink-0 transition-colors",
                  active ? "text-brand-300" : "text-slate-400 group-hover:text-white",
                )}
              />
              <span className="flex-1 truncate">{item.label}</span>
              {active ? <span className="h-1.5 w-1.5 rounded-full bg-brand-400" /> : null}
            </Link>
          );
        })}
      </nav>

      {/* Standalone offline launcher banner */}
      <a
        href="/medora-offline-standalone.html"
        target="_blank"
        rel="noreferrer"
        className="group flex items-center gap-2.5 rounded-xl border border-emerald-500/30 bg-emerald-950/40 p-2.5 text-xs text-emerald-200 transition-all hover:bg-emerald-900/60"
        title="Open standalone zero-dependency offline web app"
      >
        <Download className="h-4 w-4 shrink-0 text-emerald-400 group-hover:scale-110 transition-transform" />
        <div className="min-w-0 flex-1">
          <span className="block font-semibold text-emerald-300">Windows Portable App</span>
          <span className="block text-[10px] text-emerald-400/70 truncate">Standalone Offline .HTML</span>
        </div>
      </a>

      <div className="rounded-2xl bg-white/5 p-3 ring-1 ring-inset ring-white/10">
        <div className="flex items-center gap-3">
          <span
            className={cn(
              "grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br text-xs font-bold text-white",
              gradientFor(user.name),
            )}
          >
            {initials(user.name)}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-semibold text-white">{user.name}</p>
            <p className="truncate text-[10px] text-white/50">
              {ROLE_LABELS[user.role as keyof typeof ROLE_LABELS] ?? user.role}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={signOut}
          disabled={signingOut}
          className="btn mt-2.5 w-full bg-white/10 py-1.5 text-xs text-white hover:bg-white/20"
        >
          <LogOut className="h-3 w-3" />
          {signingOut ? "Signing out…" : "Sign out"}
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-slate-50">
      <aside className="sticky top-0 hidden h-screen w-[270px] shrink-0 lg:block">{sidebar}</aside>

      {mobileOpen ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button
            type="button"
            aria-label="Close navigation"
            className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <div className="animate-pop absolute left-0 top-0 h-full w-[280px] shadow-2xl">{sidebar}</div>
        </div>
      ) : null}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/85 backdrop-blur">
          <div className="flex items-center gap-3 px-4 py-3 sm:px-6">
            <button
              type="button"
              className="btn-ghost rounded-xl p-2 lg:hidden"
              onClick={() => setMobileOpen((open) => !open)}
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>

            <div className="hidden min-w-0 flex-col sm:flex">
              <div className="flex items-center gap-2">
                <p className="truncate text-sm font-semibold text-slate-900">
                  {activeNav?.label ?? "Dashboard"}
                </p>
                <span className="badge bg-emerald-50 text-emerald-700 text-[10px] ring-1 ring-emerald-200">
                  Live &amp; Offline Sync
                </span>
              </div>
              <p className="truncate text-xs text-slate-500">
                {user.department} · {activeNav?.hint ?? "Overview"}
              </p>
            </div>

            <form
              className="ml-auto flex w-full max-w-xs items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 focus-within:border-brand-400 focus-within:bg-white focus-within:ring-4 focus-within:ring-brand-500/10"
              onSubmit={(event) => {
                event.preventDefault();
                if (query.trim()) router.push(`/patients?q=${encodeURIComponent(query.trim())}`);
              }}
            >
              <Search className="h-4 w-4 shrink-0 text-slate-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search patients, MRN…"
                className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
              />
            </form>

            <a
              href="/medora-offline-standalone.html"
              download="medora-offline-standalone.html"
              className="btn-secondary btn-sm hidden md:inline-flex items-center gap-1.5 text-xs text-slate-700"
              title="Save portable offline single-file edition"
            >
              <Download className="h-3.5 w-3.5 text-brand-600" />
              <span>Download Portable</span>
            </a>

            <div className="hidden sm:block">
              <Avatar name={user.name} size="sm" />
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto w-full max-w-7xl">{children}</div>
        </main>
      </div>
    </div>
  );
}
