@echo off
title MEDORA Healthcare Eco-System - Portable Offline Edition
color 0A

echo =======================================================================
echo          MEDORA Health Care Eco-System - Portable Launcher
echo          100%% Free & Open-Source Integrated Healthcare Platform
echo =======================================================================
echo.
echo [1] Checking offline environment...
echo [2] Launching MEDORA Standalone Offline Control Room...
echo.
echo Username: admin
echo Password: admin
echo.

:: Launch the standalone offline file directly in default web browser
if exist "%~dp0public\medora-offline-standalone.html" (
    start "" "%~dp0public\medora-offline-standalone.html"
) else if exist "%~dp0medora-offline-standalone.html" (
    start "" "%~dp0medora-offline-standalone.html"
) else (
    echo Error: Could not locate medora-offline-standalone.html
    pause
    exit /b 1
)

echo.
echo MEDORA has started successfully in your default browser.
echo You can use the entire platform completely OFFLINE without any server.
echo.
timeout /t 5 >nul
exit
