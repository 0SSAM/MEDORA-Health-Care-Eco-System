@echo off
:: MEDORA Healthcare Portable Windows Runner
title MEDORA Portable OS
start "" "%~dp0public\medora-offline-standalone.html"
exit
