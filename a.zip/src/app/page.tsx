import Link from "next/link";
import { redirect } from "next/navigation";
import {
  Activity,
  ArrowRight,
  BadgeCheck,
  CalendarClock,
  HeartPulse,
  Pill,
  ShieldCheck,
  Wallet,
} from "lucide-react";

import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

const MODULES = [
  {
    icon: HeartPulse,
    title: "Patient CRM",
    body: "Unified medical records, risk flags, insurance coverage and care team assignment.",
  },
  {
    icon: CalendarClock,
    title: "Scheduling",
    body: "Clinic, telemedicine and procedure bookings with live status tracking.",
  },
  {
    icon: Pill,
    title: "Pharmacy & RX",
    body: "Stock levels, reorder thresholds, expiry watch and prescription dispensing.",
  },
  {
    icon: Wallet,
    title: "Billing & POS",
    body: "Invoices, co-pays, payment methods and revenue analytics in one ledger.",
  },
  {
    icon: ShieldCheck,
    title: "Insurance Claims",
    body: "Submit, track and settle payer claims with approval rate insight.",
  },
  {
    icon: Activity,
    title: "Workforce (HR)",
    body: "Clinician roster, departments, shifts and workload distribution.",
  },
];

export default async function LandingPage() {
  const user = await getCurrentUser();
  if (user) redirect("/dashboard");

  return (
    <main className="relative min-h-screen overflow-hidden bg-ink-900 text-white">
      <div className="grid-lines absolute inset-0 opacity-60" />
      <div className="absolute -left-32 top-[-10rem] h-[28rem] w-[28rem] rounded-full bg-brand-500/25 blur-3xl" />
      <div className="absolute -right-24 bottom-[-12rem] h-[30rem] w-[30rem] rounded-full bg-sky-500/20 blur-3xl" />

      <div className="relative mx-auto flex max-w-6xl flex-col px-6 py-8">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600 shadow-lg shadow-brand-500/30">
              <HeartPulse className="h-5 w-5" />
            </span>
            <div>
              <p className="text-lg font-semibold tracking-tight">MEDORA</p>
              <p className="text-[11px] uppercase tracking-[0.22em] text-white/50">
                Healthcare Ecosystem
              </p>
            </div>
          </div>
          <Link href="/login" className="btn bg-white/10 text-white ring-1 ring-inset ring-white/20 hover:bg-white/20">
            Sign in
          </Link>
        </header>

        <section className="mt-16 max-w-3xl animate-fade-up">
          <span className="badge bg-white/10 text-brand-200 ring-1 ring-inset ring-white/15">
            <BadgeCheck className="h-3.5 w-3.5" /> Open-source hospital operating system
          </span>
          <h1 className="mt-6 text-[clamp(2.4rem,6vw,4.2rem)] font-semibold leading-[1.03] tracking-tight">
            One workspace for your entire{" "}
            <span className="bg-gradient-to-r from-brand-300 to-sky-300 bg-clip-text text-transparent">
              care ecosystem
            </span>
          </h1>
          <p className="mt-5 max-w-2xl text-lg text-white/70">
            MEDORA connects patients, clinicians, pharmacy, billing and insurance
            into a single operational platform — so your team spends time on care,
            not on copy-paste.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link href="/login" className="btn bg-brand-500 px-5 py-3 text-white hover:bg-brand-400">
              Enter the demo workspace <ArrowRight className="h-4 w-4" />
            </Link>
            <span className="rounded-xl bg-white/5 px-4 py-3 text-sm text-white/60 ring-1 ring-inset ring-white/10">
              Demo login · <span className="font-semibold text-white/90">admin</span> / <span className="font-semibold text-white/90">admin</span>
            </span>
          </div>
        </section>

        <section className="mt-20 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {MODULES.map((module) => (
            <article
              key={module.title}
              className="group rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-all hover:-translate-y-1 hover:border-brand-400/40 hover:bg-white/[0.07]"
            >
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-brand-400/30 to-sky-400/20 text-brand-200 ring-1 ring-inset ring-white/10">
                <module.icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 text-base font-semibold">{module.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-white/60">{module.body}</p>
            </article>
          ))}
        </section>

        <footer className="mt-20 border-t border-white/10 pt-6 text-sm text-white/40">
          MEDORA Health Care Eco-System · built with Next.js, PostgreSQL and Drizzle ORM
        </footer>
      </div>
    </main>
  );
}
