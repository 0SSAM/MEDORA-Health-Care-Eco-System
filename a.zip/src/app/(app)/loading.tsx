export default function AppLoading() {
  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div className="space-y-2">
          <div className="skeleton h-7 w-56" />
          <div className="skeleton h-4 w-80" />
        </div>
        <div className="skeleton h-10 w-32 rounded-xl" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, index) => (
          <div key={index} className="card card-pad space-y-3">
            <div className="flex items-center justify-between">
              <div className="skeleton h-3 w-24" />
              <div className="skeleton h-9 w-9 rounded-xl" />
            </div>
            <div className="skeleton h-8 w-20" />
            <div className="skeleton h-3 w-28" />
          </div>
        ))}
      </div>

      <div className="card overflow-hidden">
        <div className="border-b border-slate-100 px-5 py-4">
          <div className="skeleton h-4 w-40" />
        </div>
        <div className="divide-y divide-slate-100">
          {Array.from({ length: 7 }).map((_, index) => (
            <div key={index} className="flex items-center gap-4 px-5 py-4">
              <div className="skeleton h-10 w-10 rounded-xl" />
              <div className="flex-1 space-y-2">
                <div className="skeleton h-3 w-1/4" />
                <div className="skeleton h-3 w-1/6" />
              </div>
              <div className="skeleton h-6 w-24 rounded-full" />
              <div className="skeleton hidden h-3 w-20 sm:block" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
