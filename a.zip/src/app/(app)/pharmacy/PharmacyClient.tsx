"use client";

import { useMemo, useState } from "react";
import {
  Boxes,
  PackagePlus,
  Pencil,
  Pill,
  Plus,
  Trash2,
  TrendingDown,
  TriangleAlert,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { cn, currency, daysUntil, formatDate, titleCase } from "@/lib/utils";
import type { MedicationListRow } from "@/lib/queries";
import { ConfirmDialog, EmptyState, Pill as Tag, useToast } from "@/components/ui";
import { FormModal, PageHeader, StatCard, Toolbar } from "@/components/resource";

type FormState = {
  name: string;
  category: string;
  form: string;
  strength: string;
  manufacturer: string;
  batchNumber: string;
  supplier: string;
  stock: string;
  reorderLevel: string;
  unitPrice: string;
  expiryDate: string;
};

const FORMS = ["tablet", "capsule", "syrup", "injection", "inhaler", "topical"];
const TABS = ["all", "in_stock", "low_stock", "out_of_stock", "expiring"];

function deriveStatus(med: MedicationListRow) {
  const days = daysUntil(med.expiryDate);
  if (days < 0) return "expired";
  if (med.stock === 0) return "out_of_stock";
  if (med.stock <= med.reorderLevel) return "low_stock";
  return "in_stock";
}

function defaultExpiry() {
  const date = new Date();
  date.setFullYear(date.getFullYear() + 2);
  return date.toISOString().slice(0, 10);
}

export default function PharmacyClient({
  initialMedications,
}: {
  initialMedications: MedicationListRow[];
}) {
  const toast = useToast();
  const [rows, setRows] = useState(initialMedications);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<MedicationListRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<MedicationListRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState<FormState>({
    name: "",
    category: "General",
    form: "tablet",
    strength: "500mg",
    manufacturer: "Medora Labs",
    batchNumber: "",
    supplier: "Medora Supply Co.",
    stock: "100",
    reorderLevel: "40",
    unitPrice: "10.00",
    expiryDate: defaultExpiry(),
  });

  const stats = useMemo(() => {
    const withStatus = rows.map((row) => ({ row, status: deriveStatus(row) }));
    return {
      items: rows.length,
      low: withStatus.filter((item) => item.status === "low_stock").length,
      out: withStatus.filter((item) => item.status === "out_of_stock" || item.status === "expired").length,
      value: rows.reduce((sum, row) => sum + row.stock * Number(row.unitPrice), 0),
    };
  }, [rows]);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows.filter((row) => {
      const status = deriveStatus(row);
      if (tab === "expiring" && daysUntil(row.expiryDate) > 120) return false;
      if (["in_stock", "low_stock", "out_of_stock"].includes(tab) && status !== tab) return false;
      if (!term) return true;
      return [row.name, row.category, row.manufacturer, row.supplier, row.strength]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [rows, query, tab]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: rows.length, expiring: 0 };
    for (const row of rows) {
      if (daysUntil(row.expiryDate) <= 120) map.expiring += 1;
      const status = deriveStatus(row);
      map[status] = (map[status] ?? 0) + 1;
    }
    return map;
  }, [rows]);

  function openCreate() {
    setEditing(null);
    setForm({
      name: "",
      category: "General",
      form: "tablet",
      strength: "500mg",
      manufacturer: "Medora Labs",
      batchNumber: "",
      supplier: "Medora Supply Co.",
      stock: "100",
      reorderLevel: "40",
      unitPrice: "10.00",
      expiryDate: defaultExpiry(),
    });
    setOpen(true);
  }

  function openEdit(row: MedicationListRow) {
    setEditing(row);
    setForm({
      name: row.name,
      category: row.category,
      form: row.form,
      strength: row.strength,
      manufacturer: row.manufacturer,
      batchNumber: row.batchNumber,
      supplier: row.supplier,
      stock: String(row.stock),
      reorderLevel: String(row.reorderLevel),
      unitPrice: Number(row.unitPrice).toFixed(2),
      expiryDate: row.expiryDate,
    });
    setOpen(true);
  }

  async function restock(row: MedicationListRow, quantity: number) {
    const previous = rows;
    setRows((current) =>
      current.map((item) => (item.id === row.id ? { ...item, stock: item.stock + quantity } : item)),
    );
    try {
      await apiRequest(`/api/medications/${row.id}`, {
        method: "PATCH",
        json: { stock: row.stock + quantity },
      });
      toast.push({ title: `${row.name} restocked (+${quantity})`, tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    }
  }

  async function submit() {
    setBusy(true);
    const payload = {
      ...form,
      stock: Number(form.stock),
      reorderLevel: Number(form.reorderLevel),
      unitPrice: Number(form.unitPrice || 0).toFixed(2),
    };
    try {
      if (editing) {
        const previous = rows;
        setRows((current) =>
          current.map((row) => (row.id === editing.id ? { ...row, ...payload } : row)),
        );
        setOpen(false);
        try {
          await apiRequest(`/api/medications/${editing.id}`, { method: "PATCH", json: payload });
          toast.push({ title: "Inventory item updated", tone: "success" });
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic: MedicationListRow = {
          id: `temp-${Date.now()}`,
          name: form.name,
          category: form.category,
          form: form.form,
          strength: form.strength,
          manufacturer: form.manufacturer,
          batchNumber: form.batchNumber,
          supplier: form.supplier,
          stock: payload.stock,
          reorderLevel: payload.reorderLevel,
          unitPrice: payload.unitPrice,
          expiryDate: form.expiryDate,
        };
        setRows((current) => [optimistic, ...current]);
        setOpen(false);
        try {
          const created = await apiRequest<MedicationListRow>("/api/medications", {
            method: "POST",
            json: payload,
          });
          setRows((current) => current.map((row) => (row.id === optimistic.id ? created : row)));
          toast.push({ title: `${created.name} added to catalogue`, tone: "success" });
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== pendingDelete.id));
    try {
      await apiRequest(`/api/medications/${pendingDelete.id}`, { method: "DELETE" });
      toast.push({ title: "Medication removed", tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Pharmacy inventory"
        subtitle="Stock levels, reorder thresholds, expiry watch and pricing."
      >
        <button type="button" className="btn-primary" onClick={openCreate}>
          <PackagePlus className="h-4 w-4" /> Add medication
        </button>
      </PageHeader>

      <section className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Catalogue items" value={stats.items} icon={<Pill className="h-4 w-4" />} />
        <StatCard
          label="Low stock"
          value={stats.low}
          icon={<TrendingDown className="h-4 w-4" />}
          tone="amber"
          footer="at or below reorder"
        />
        <StatCard
          label="Out / expired"
          value={stats.out}
          icon={<TriangleAlert className="h-4 w-4" />}
          tone="rose"
        />
        <StatCard
          label="Inventory value"
          value={currency(stats.value)}
          icon={<Boxes className="h-4 w-4" />}
          tone="violet"
        />
      </section>

      <Toolbar
        search={query}
        onSearch={setQuery}
        placeholder="Search medication, category or supplier…"
        tabs={TABS.map((value) => ({
          value,
          label: value === "all" ? "All items" : titleCase(value),
          count: counts[value] ?? 0,
        }))}
        activeTab={tab}
        onTab={setTab}
        resultCount={filtered.length}
      />

      <div className="card overflow-hidden">
        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="table-shell">
              <thead>
                <tr>
                  <th>Medication</th>
                  <th>Category</th>
                  <th>Stock</th>
                  <th>Status</th>
                  <th>Unit price</th>
                  <th>Expiry</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => {
                  const status = deriveStatus(row);
                  const ratio = Math.min(100, (row.stock / Math.max(row.reorderLevel * 3, 1)) * 100);
                  return (
                    <tr key={row.id} className={cn(row.id.startsWith("temp-") && "opacity-60")}>
                      <td>
                        <span className="block font-semibold text-slate-900">
                          {row.name} {row.strength}
                        </span>
                        <span className="block text-xs text-slate-400">
                          {titleCase(row.form)} · {row.manufacturer} · {row.batchNumber || "no batch"}
                        </span>
                      </td>
                      <td className="text-sm text-slate-600">{row.category}</td>
                      <td className="w-44">
                        <div className="flex items-center justify-between text-xs text-slate-500">
                          <span className="font-semibold text-slate-800">{row.stock}</span>
                          <span>reorder {row.reorderLevel}</span>
                        </div>
                        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-100">
                          <div
                            className={cn(
                              "h-full rounded-full",
                              status === "out_of_stock" || status === "expired"
                                ? "bg-rose-500"
                                : status === "low_stock"
                                  ? "bg-amber-500"
                                  : "bg-brand-500",
                            )}
                            style={{ width: `${Math.max(4, ratio)}%` }}
                          />
                        </div>
                      </td>
                      <td>
                        <Tag
                          tone={
                            status === "in_stock"
                              ? "green"
                              : status === "low_stock"
                                ? "amber"
                                : "red"
                          }
                        >
                          {titleCase(status)}
                        </Tag>
                      </td>
                      <td className="text-sm font-medium text-slate-800">
                        {currency(row.unitPrice)}
                      </td>
                      <td className="text-sm text-slate-600">{formatDate(row.expiryDate)}</td>
                      <td>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-brand-600 hover:bg-brand-50"
                            title="Restock +50"
                            onClick={() => restock(row, 50)}
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2"
                            onClick={() => openEdit(row)}
                            title="Edit"
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                            onClick={() => setPendingDelete(row)}
                            title="Delete"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<Pill className="h-6 w-6" />}
            title="No medication matches this view"
            description="Try another filter or add a new item to the catalogue."
            action={
              <button type="button" className="btn-primary" onClick={openCreate}>
                <PackagePlus className="h-4 w-4" /> Add medication
              </button>
            }
          />
        )}
      </div>

      <FormModal
        open={open}
        mode={editing ? "edit" : "create"}
        title={editing ? `Edit ${editing.name}` : "Add medication"}
        description="Inventory details, pricing and shelf life."
        onClose={() => setOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="label">Name *</span>
            <input
              required
              className="input"
              value={form.name}
              onChange={(event) => setForm({ ...form, name: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Strength</span>
            <input
              className="input"
              value={form.strength}
              onChange={(event) => setForm({ ...form, strength: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Category</span>
            <input
              className="input"
              value={form.category}
              onChange={(event) => setForm({ ...form, category: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Form</span>
            <select
              className="input"
              value={form.form}
              onChange={(event) => setForm({ ...form, form: event.target.value })}
            >
              {FORMS.map((option) => (
                <option key={option} value={option}>
                  {titleCase(option)}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Manufacturer</span>
            <input
              className="input"
              value={form.manufacturer}
              onChange={(event) => setForm({ ...form, manufacturer: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Supplier</span>
            <input
              className="input"
              value={form.supplier}
              onChange={(event) => setForm({ ...form, supplier: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Batch number</span>
            <input
              className="input"
              value={form.batchNumber}
              onChange={(event) => setForm({ ...form, batchNumber: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Expiry date</span>
            <input
              type="date"
              className="input"
              value={form.expiryDate}
              onChange={(event) => setForm({ ...form, expiryDate: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Stock on hand</span>
            <input
              type="number"
              min={0}
              className="input"
              value={form.stock}
              onChange={(event) => setForm({ ...form, stock: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Reorder level</span>
            <input
              type="number"
              min={0}
              className="input"
              value={form.reorderLevel}
              onChange={(event) => setForm({ ...form, reorderLevel: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Unit price (USD)</span>
            <input
              type="number"
              min={0}
              step="0.01"
              className="input"
              value={form.unitPrice}
              onChange={(event) => setForm({ ...form, unitPrice: event.target.value })}
            />
          </label>
        </div>
      </FormModal>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete medication"
        message={`Remove ${pendingDelete?.name} ${pendingDelete?.strength} from the pharmacy catalogue?`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
