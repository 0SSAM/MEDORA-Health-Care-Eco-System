import { Pill } from "lucide-react";

import { listMedications } from "@/lib/queries";
import PharmacyClient from "./PharmacyClient";

export const dynamic = "force-dynamic";

export default async function PharmacyPage() {
  const medications = await listMedications();

  if (!medications.length) {
    return (
      <div className="card mt-10">
        <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-emerald-50 text-emerald-600">
            <Pill className="h-6 w-6" />
          </span>
          <p className="text-lg font-semibold text-slate-900">Pharmacy catalogue is empty</p>
          <p className="max-w-sm text-sm text-slate-500">
            Add your first medication to start tracking stock, pricing and expiry.
          </p>
        </div>
      </div>
    );
  }

  return <PharmacyClient initialMedications={medications} />;
}
