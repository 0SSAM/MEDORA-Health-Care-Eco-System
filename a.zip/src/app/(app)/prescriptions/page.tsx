import { ClipboardList } from "lucide-react";

import {
  getMedicationOptions,
  getPatientOptions,
  getStaffOptions,
  listPrescriptions,
} from "@/lib/queries";
import PrescriptionsClient from "./PrescriptionsClient";

export const dynamic = "force-dynamic";

export default async function PrescriptionsPage() {
  const [prescriptions, patientOptions, staffOptions, medicationOptions] = await Promise.all([
    listPrescriptions(),
    getPatientOptions(),
    getStaffOptions(),
    getMedicationOptions(),
  ]);

  if (!prescriptions.length) {
    return (
      <div className="card mt-10">
        <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-violet-50 text-violet-600">
            <ClipboardList className="h-6 w-6" />
          </span>
          <p className="text-lg font-semibold text-slate-900">No prescriptions issued</p>
          <p className="max-w-sm text-sm text-slate-500">
            Write the first prescription and it will flow straight into the pharmacy queue.
          </p>
        </div>
      </div>
    );
  }

  return (
    <PrescriptionsClient
      initialPrescriptions={prescriptions}
      patientOptions={patientOptions}
      staffOptions={staffOptions}
      medicationOptions={medicationOptions}
    />
  );
}
