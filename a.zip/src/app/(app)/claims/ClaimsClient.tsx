"use client";

import { useMemo, useState } from "react";
import {
  BadgeCheck,
  CheckCircle2,
  Pencil,
  Plus,
  ShieldCheck,
  Trash2,
  XCircle,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { compactCurrency, currency, formatDate, titleCase } from "@/lib/utils";
import type { ClaimListRow, Option } from "@/lib/queries";
import { ConfirmDialog, EmptyState, StatusBadge, useToast } from "@/components/ui";
import { FormModal, PageHeader, StatCard, Toolbar } from "@/components/resource";

type FormState = {
  patientId: string;
  provider: string;
  amount: string;
  approvedAmount: string;
  status: string;
  notes: string;
};

const STATUSES = ["submitted", "under_review", "approved", "rejected", "paid"];
const PROVIDERS = ["MedGulf", "Bupa Arabia", "AXA Arabia", "Tawuniya", "Malath", "Self-pay"];

export default function ClaimsClient({
  initialClaims,
  patientOptions,
}: {
  initialClaims: ClaimListRow[];
  patientOptions: Option[];
}) {
  const toast = useToast();
  const [rows, setRows] = useState(initialClaims);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ClaimListRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<ClaimListRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState<FormState>({
    patientId: patientOptions[0]?.id ?? "",
    provider: "MedGulf",
    amount: "500.00",
    approvedAmount: "0.00",
    status: "submitted",
    notes: "Documents complete, awaiting adjudication.",
  });

  const stats = useMemo(() => {
    const total = rows.reduce((sum, row) => sum + Number(row.amount), 0);
    const approved = rows
      .filter((row) => row.status === "approved" || row.status === "paid")
      .reduce((sum, row) => sum + Number(row.approvedAmount || row.amount), 0);
    const rejected = rows.filter((row) => row.status === "rejected");
    const settled = rows
      .filter((row) => row.status === "paid")
      .reduce((sum, row) => sum + Number(row.approvedAmount || row.amount), 0);
    return {
      total,
      approved,
      settled,
      rejected: rejected.length,
      rate: rows.length
        ? Math.round(
            (rows.filter((row) => row.status === "approved" || row.status === "paid").length /
              rows.length) *
              100,
          )
        : 0,
    };
  }, [rows]);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (tab !== "all" && row.status !== tab) return false;
      if (!term) return true;
      return [row.claimNumber, row.patientName, row.provider, row.notes]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [rows, query, tab]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: rows.length };
    for (const row of rows) map[row.status] = (map[row.status] ?? 0) + 1;
    return map;
  }, [rows]);

  function openCreate() {
    setEditing(null);
    setForm({
      patientId: patientOptions[0]?.id ?? "",
      provider: "MedGulf",
      amount: "500.00",
      approvedAmount: "0.00",
      status: "submitted",
      notes: "Documents complete, awaiting adjudication.",
    });
    setOpen(true);
  }

  function openEdit(row: ClaimListRow) {
    setEditing(row);
    setForm({
      patientId: row.patientId,
      provider: row.provider,
      amount: Number(row.amount).toFixed(2),
      approvedAmount: Number(row.approvedAmount).toFixed(2),
      status: row.status,
      notes: row.notes,
    });
    setOpen(true);
  }

  function buildOptimistic(id: string): ClaimListRow {
    return {
      id,
      claimNumber: editing?.claimNumber ?? "CLM pending…",
      patientId: form.patientId,
      patientName: patientOptions.find((option) => option.id === form.patientId)?.label ?? "Patient",
      provider: form.provider,
      amount: form.amount,
      approvedAmount: form.approvedAmount,
      status: form.status,
      submittedAt: editing?.submittedAt ?? new Date(),
      decidedAt:
        form.status === "submitted" || form.status === "under_review"
          ? null
          : editing?.decidedAt ?? new Date(),
      notes: form.notes,
    };
  }

  async function setStatus(row: ClaimListRow, status: string) {
    const previous = rows;
    const approved =
      status === "rejected"
        ? "0"
        : Number(row.approvedAmount) > 0
          ? row.approvedAmount
          : row.amount;
    setRows((current) =>
      current.map((item) =>
        item.id === row.id
          ? {
              ...item,
              status,
              approvedAmount: approved,
              decidedAt: status === "submitted" ? null : new Date(),
            }
          : item,
      ),
    );
    try {
      await apiRequest(`/api/claims/${row.id}`, {
        method: "PATCH",
        json: { status, approvedAmount: approved },
      });
      toast.push({ title: `Claim ${titleCase(status)}`, tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    }
  }

  async function submit() {
    setBusy(true);
    const payload = { ...form };
    try {
      if (editing) {
        const previous = rows;
        setRows((current) =>
          current.map((row) => (row.id === editing.id ? buildOptimistic(row.id) : row)),
        );
        setOpen(false);
        try {
          await apiRequest(`/api/claims/${editing.id}`, { method: "PATCH", json: payload });
          toast.push({ title: "Claim updated", tone: "success" });
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic = buildOptimistic(`temp-${Date.now()}`);
        setRows((current) => [optimistic, ...current]);
        setOpen(false);
        try {
          const created = await apiRequest<ClaimListRow>("/api/claims", {
            method: "POST",
            json: payload,
          });
          setRows((current) => current.map((row) => (row.id === optimistic.id ? created : row)));
          toast.push({ title: `${created.claimNumber} submitted`, tone: "success" });
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== pendingDelete.id));
    try {
      await apiRequest(`/api/claims/${pendingDelete.id}`, { method: "DELETE" });
      toast.push({ title: "Claim deleted", tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Insurance claims"
        subtitle="Payer submissions, adjudication status and settlements."
      >
        <button type="button" className="btn-primary" onClick={openCreate}>
          <Plus className="h-4 w-4" /> Submit claim
        </button>
      </PageHeader>

      <section className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Claimed value"
          value={compactCurrency(stats.total)}
          icon={<ShieldCheck className="h-4 w-4" />}
        />
        <StatCard
          label="Approved value"
          value={compactCurrency(stats.approved)}
          footer={`${stats.rate}% approval rate`}
          icon={<BadgeCheck className="h-4 w-4" />}
          tone="sky"
        />
        <StatCard
          label="Settled"
          value={compactCurrency(stats.settled)}
          icon={<CheckCircle2 className="h-4 w-4" />}
          tone="violet"
        />
        <StatCard
          label="Rejected"
          value={stats.rejected}
          icon={<XCircle className="h-4 w-4" />}
          tone="rose"
        />
      </section>

      <Toolbar
        search={query}
        onSearch={setQuery}
        placeholder="Search claim number, patient or payer…"
        tabs={[
          { value: "all", label: "All", count: counts.all ?? 0 },
          ...STATUSES.map((status) => ({
            value: status,
            label: titleCase(status),
            count: counts[status] ?? 0,
          })),
        ]}
        activeTab={tab}
        onTab={setTab}
        resultCount={filtered.length}
      />

      <div className="card overflow-hidden">
        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="table-shell">
              <thead>
                <tr>
                  <th>Claim</th>
                  <th>Patient</th>
                  <th>Payer</th>
                  <th>Claimed</th>
                  <th>Approved</th>
                  <th>Submitted</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.id} className={row.id.startsWith("temp-") ? "opacity-60" : undefined}>
                    <td>
                      <span className="block font-semibold text-slate-900">{row.claimNumber}</span>
                      <span className="block max-w-[16rem] truncate text-xs text-slate-400">
                        {row.notes || "No notes"}
                      </span>
                    </td>
                    <td className="text-sm text-slate-700">{row.patientName}</td>
                    <td className="text-sm text-slate-600">{row.provider}</td>
                    <td className="whitespace-nowrap font-semibold text-slate-900">
                      {currency(row.amount)}
                    </td>
                    <td className="whitespace-nowrap text-sm text-slate-600">
                      {Number(row.approvedAmount) > 0 ? currency(row.approvedAmount) : "—"}
                    </td>
                    <td className="text-sm text-slate-600">{formatDate(row.submittedAt)}</td>
                    <td>
                      <StatusBadge status={row.status} />
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        {row.status === "submitted" || row.status === "under_review" ? (
                          <>
                            <button
                              type="button"
                              className="btn-ghost rounded-lg p-2 text-emerald-600 hover:bg-emerald-50"
                              title="Approve"
                              onClick={() => setStatus(row, "approved")}
                            >
                              <CheckCircle2 className="h-4 w-4" />
                            </button>
                            <button
                              type="button"
                              className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                              title="Reject"
                              onClick={() => setStatus(row, "rejected")}
                            >
                              <XCircle className="h-4 w-4" />
                            </button>
                          </>
                        ) : null}
                        {row.status === "approved" ? (
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-violet-600 hover:bg-violet-50"
                            title="Mark settled"
                            onClick={() => setStatus(row, "paid")}
                          >
                            <BadgeCheck className="h-4 w-4" />
                          </button>
                        ) : null}
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2"
                          onClick={() => openEdit(row)}
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                          onClick={() => setPendingDelete(row)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<ShieldCheck className="h-6 w-6" />}
            title="No claims in this view"
            description="Submit a claim to a payer to start tracking reimbursement."
            action={
              <button type="button" className="btn-primary" onClick={openCreate}>
                <Plus className="h-4 w-4" /> Submit claim
              </button>
            }
          />
        )}
      </div>

      <FormModal
        open={open}
        mode={editing ? "edit" : "create"}
        title={editing ? `Edit ${editing.claimNumber}` : "Submit insurance claim"}
        description="Adjudication details are recalculated when the status changes."
        onClose={() => setOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block sm:col-span-2">
            <span className="label">Patient *</span>
            <select
              required
              className="input"
              value={form.patientId}
              onChange={(event) => setForm({ ...form, patientId: event.target.value })}
            >
              <option value="">Select a patient…</option>
              {patientOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label} ({option.hint})
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Payer</span>
            <select
              className="input"
              value={form.provider}
              onChange={(event) => setForm({ ...form, provider: event.target.value })}
            >
              {PROVIDERS.map((provider) => (
                <option key={provider} value={provider}>
                  {provider}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Status</span>
            <select
              className="input"
              value={form.status}
              onChange={(event) => setForm({ ...form, status: event.target.value })}
            >
              {STATUSES.map((status) => (
                <option key={status} value={status}>
                  {titleCase(status)}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Claimed amount *</span>
            <input
              required
              type="number"
              min={0}
              step="0.01"
              className="input"
              value={form.amount}
              onChange={(event) => setForm({ ...form, amount: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Approved amount</span>
            <input
              type="number"
              min={0}
              step="0.01"
              className="input"
              value={form.approvedAmount}
              onChange={(event) => setForm({ ...form, approvedAmount: event.target.value })}
            />
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Notes</span>
            <textarea
              rows={3}
              className="input resize-none"
              value={form.notes}
              onChange={(event) => setForm({ ...form, notes: event.target.value })}
            />
          </label>
        </div>
      </FormModal>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete claim"
        message={`Delete ${pendingDelete?.claimNumber} from ${pendingDelete?.provider}?`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
