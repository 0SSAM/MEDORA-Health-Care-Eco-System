import { ShieldCheck } from "lucide-react";

import { getPatientOptions, listClaims } from "@/lib/queries";
import ClaimsClient from "./ClaimsClient";

export const dynamic = "force-dynamic";

export default async function ClaimsPage() {
  const [claims, patientOptions] = await Promise.all([listClaims(), getPatientOptions()]);

  if (!claims.length) {
    return (
      <div className="card mt-10">
        <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-sky-50 text-sky-600">
            <ShieldCheck className="h-6 w-6" />
          </span>
          <p className="text-lg font-semibold text-slate-900">No claims submitted</p>
          <p className="max-w-sm text-sm text-slate-500">
            Submit a claim to a payer to start tracking reimbursement.
          </p>
        </div>
      </div>
    );
  }

  return <ClaimsClient initialClaims={claims} patientOptions={patientOptions} />;
}
