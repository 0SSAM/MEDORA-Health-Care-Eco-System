import { Wallet } from "lucide-react";

import { getPatientOptions, listInvoices } from "@/lib/queries";
import BillingClient from "./BillingClient";

export const dynamic = "force-dynamic";

export default async function BillingPage() {
  const [invoices, patientOptions] = await Promise.all([
    listInvoices(),
    getPatientOptions(),
  ]);

  if (!invoices.length) {
    return (
      <div className="card mt-10">
        <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-violet-50 text-violet-600">
            <Wallet className="h-6 w-6" />
          </span>
          <p className="text-lg font-semibold text-slate-900">No invoices raised</p>
          <p className="max-w-sm text-sm text-slate-500">
            Create an invoice or POS charge to start tracking revenue.
          </p>
        </div>
      </div>
    );
  }

  return <BillingClient initialInvoices={invoices} patientOptions={patientOptions} />;
}
