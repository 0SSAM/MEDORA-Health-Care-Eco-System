"use client";

import { useMemo, useState } from "react";
import {
  Banknote,
  CheckCircle2,
  FileText,
  Pencil,
  Plus,
  ReceiptText,
  Trash2,
  Wallet,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { compactCurrency, currency, formatDate, titleCase, toInputDate } from "@/lib/utils";
import type { InvoiceListRow, Option } from "@/lib/queries";
import { ConfirmDialog, EmptyState, StatusBadge, useToast } from "@/components/ui";
import { FormModal, PageHeader, StatCard, Toolbar } from "@/components/resource";

type FormState = {
  patientId: string;
  amount: string;
  insuranceCovered: string;
  status: string;
  itemsSummary: string;
  paymentMethod: string;
  dueDate: string;
};

const STATUSES = ["draft", "pending", "paid", "overdue", "void"];
const METHODS = ["card", "cash", "insurance", "bank_transfer"];

export default function BillingClient({
  initialInvoices,
  patientOptions,
}: {
  initialInvoices: InvoiceListRow[];
  patientOptions: Option[];
}) {
  const toast = useToast();
  const [rows, setRows] = useState(initialInvoices);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<InvoiceListRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<InvoiceListRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState<FormState>({
    patientId: patientOptions[0]?.id ?? "",
    amount: "250.00",
    insuranceCovered: "0.00",
    status: "pending",
    itemsSummary: "Consultation + ECG",
    paymentMethod: "card",
    dueDate: toInputDate(new Date()),
  });

  const stats = useMemo(() => {
    const billed = rows.reduce((sum, row) => sum + Number(row.amount), 0);
    const collected = rows
      .filter((row) => row.status === "paid")
      .reduce((sum, row) => sum + Number(row.amount), 0);
    const insurance = rows.reduce((sum, row) => sum + Number(row.insuranceCovered), 0);
    const overdue = rows.filter((row) => row.status === "overdue");
    return {
      billed,
      collected,
      insurance,
      outstanding: billed - collected - insurance,
      overdue: overdue.length,
      overdueValue: overdue.reduce((sum, row) => sum + Number(row.amount), 0),
    };
  }, [rows]);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (tab !== "all" && row.status !== tab) return false;
      if (!term) return true;
      return [row.invoiceNumber, row.patientName, row.itemsSummary, row.paymentMethod]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [rows, query, tab]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: rows.length };
    for (const row of rows) map[row.status] = (map[row.status] ?? 0) + 1;
    return map;
  }, [rows]);

  function openCreate() {
    setEditing(null);
    setForm({
      patientId: patientOptions[0]?.id ?? "",
      amount: "250.00",
      insuranceCovered: "0.00",
      status: "pending",
      itemsSummary: "Consultation + ECG",
      paymentMethod: "card",
      dueDate: toInputDate(new Date()),
    });
    setOpen(true);
  }

  function openEdit(row: InvoiceListRow) {
    setEditing(row);
    setForm({
      patientId: row.patientId,
      amount: Number(row.amount).toFixed(2),
      insuranceCovered: Number(row.insuranceCovered).toFixed(2),
      status: row.status,
      itemsSummary: row.itemsSummary,
      paymentMethod: row.paymentMethod,
      dueDate: toInputDate(row.dueDate),
    });
    setOpen(true);
  }

  function buildOptimistic(id: string): InvoiceListRow {
    return {
      id,
      invoiceNumber: editing?.invoiceNumber ?? "INV pending…",
      patientId: form.patientId,
      patientName: patientOptions.find((option) => option.id === form.patientId)?.label ?? "Patient",
      amount: form.amount,
      insuranceCovered: form.insuranceCovered,
      status: form.status,
      itemsSummary: form.itemsSummary,
      paymentMethod: form.paymentMethod,
      issuedAt: editing?.issuedAt ?? new Date(),
      dueDate: form.dueDate,
      paidAt: form.status === "paid" ? editing?.paidAt ?? new Date() : null,
    };
  }

  async function markPaid(row: InvoiceListRow) {
    const previous = rows;
    setRows((current) =>
      current.map((item) =>
        item.id === row.id ? { ...item, status: "paid", paidAt: new Date() } : item,
      ),
    );
    try {
      await apiRequest(`/api/invoices/${row.id}`, { method: "PATCH", json: { status: "paid" } });
      toast.push({ title: `${row.invoiceNumber} settled`, tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    }
  }

  async function submit() {
    setBusy(true);
    const payload = { ...form };
    try {
      if (editing) {
        const previous = rows;
        setRows((current) =>
          current.map((row) => (row.id === editing.id ? buildOptimistic(row.id) : row)),
        );
        setOpen(false);
        try {
          await apiRequest(`/api/invoices/${editing.id}`, { method: "PATCH", json: payload });
          toast.push({ title: "Invoice updated", tone: "success" });
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic = buildOptimistic(`temp-${Date.now()}`);
        setRows((current) => [optimistic, ...current]);
        setOpen(false);
        try {
          const created = await apiRequest<InvoiceListRow>("/api/invoices", {
            method: "POST",
            json: payload,
          });
          setRows((current) => current.map((row) => (row.id === optimistic.id ? created : row)));
          toast.push({ title: `${created.invoiceNumber} created`, tone: "success" });
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== pendingDelete.id));
    try {
      await apiRequest(`/api/invoices/${pendingDelete.id}`, { method: "DELETE" });
      toast.push({ title: "Invoice deleted", tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Billing & POS"
        subtitle="Invoices, payer coverage and patient responsibility in one ledger."
      >
        <button type="button" className="btn-primary" onClick={openCreate}>
          <Plus className="h-4 w-4" /> New invoice
        </button>
      </PageHeader>

      <section className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Gross billed"
          value={compactCurrency(stats.billed)}
          icon={<ReceiptText className="h-4 w-4" />}
        />
        <StatCard
          label="Collected"
          value={compactCurrency(stats.collected)}
          icon={<Banknote className="h-4 w-4" />}
          tone="violet"
        />
        <StatCard
          label="Insurance share"
          value={compactCurrency(stats.insurance)}
          icon={<ShieldIcon />}
          tone="sky"
        />
        <StatCard
          label="Outstanding"
          value={compactCurrency(stats.outstanding)}
          footer={`${stats.overdue} overdue`}
          icon={<Wallet className="h-4 w-4" />}
          tone="amber"
        />
      </section>

      <Toolbar
        search={query}
        onSearch={setQuery}
        placeholder="Search invoice number, patient or service…"
        tabs={[
          { value: "all", label: "All", count: counts.all ?? 0 },
          ...STATUSES.map((status) => ({
            value: status,
            label: titleCase(status),
            count: counts[status] ?? 0,
          })),
        ]}
        activeTab={tab}
        onTab={setTab}
        resultCount={filtered.length}
      />

      <div className="card overflow-hidden">
        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="table-shell">
              <thead>
                <tr>
                  <th>Invoice</th>
                  <th>Patient</th>
                  <th>Amount</th>
                  <th>Coverage</th>
                  <th>Method</th>
                  <th>Due</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => {
                  const due = Number(row.amount) - Number(row.insuranceCovered);
                  return (
                    <tr key={row.id} className={row.id.startsWith("temp-") ? "opacity-60" : undefined}>
                      <td>
                        <span className="block font-semibold text-slate-900">{row.invoiceNumber}</span>
                        <span className="block text-xs text-slate-400">{row.itemsSummary}</span>
                      </td>
                      <td className="text-sm text-slate-700">{row.patientName}</td>
                      <td className="whitespace-nowrap font-semibold text-slate-900">
                        {currency(row.amount)}
                        <span className="block text-xs font-normal text-slate-400">
                          patient {currency(due)}
                        </span>
                      </td>
                      <td className="text-sm text-slate-600">
                        {Number(row.insuranceCovered) > 0
                          ? currency(row.insuranceCovered)
                          : "Self-pay"}
                      </td>
                      <td className="text-sm text-slate-600">{titleCase(row.paymentMethod)}</td>
                      <td className="text-sm text-slate-600">{formatDate(row.dueDate)}</td>
                      <td>
                        <StatusBadge status={row.status} />
                      </td>
                      <td>
                        <div className="flex items-center justify-end gap-1">
                          {row.status !== "paid" && row.status !== "void" ? (
                            <button
                              type="button"
                              className="btn-ghost rounded-lg p-2 text-emerald-600 hover:bg-emerald-50"
                              title="Mark paid"
                              onClick={() => markPaid(row)}
                            >
                              <CheckCircle2 className="h-4 w-4" />
                            </button>
                          ) : null}
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2"
                            onClick={() => openEdit(row)}
                            title="Edit"
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                            onClick={() => setPendingDelete(row)}
                            title="Delete"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<FileText className="h-6 w-6" />}
            title="No invoices in this view"
            description="Raise an invoice for a consultation, lab panel or pharmacy sale."
            action={
              <button type="button" className="btn-primary" onClick={openCreate}>
                <Plus className="h-4 w-4" /> New invoice
              </button>
            }
          />
        )}
      </div>

      <FormModal
        open={open}
        mode={editing ? "edit" : "create"}
        title={editing ? `Edit ${editing.invoiceNumber}` : "Create invoice"}
        description="Charge for services, apply payer coverage and set payment terms."
        onClose={() => setOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block sm:col-span-2">
            <span className="label">Patient *</span>
            <select
              required
              className="input"
              value={form.patientId}
              onChange={(event) => setForm({ ...form, patientId: event.target.value })}
            >
              <option value="">Select a patient…</option>
              {patientOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label} ({option.hint})
                </option>
              ))}
            </select>
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Services</span>
            <input
              className="input"
              value={form.itemsSummary}
              onChange={(event) => setForm({ ...form, itemsSummary: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Total amount *</span>
            <input
              required
              type="number"
              min={0}
              step="0.01"
              className="input"
              value={form.amount}
              onChange={(event) => setForm({ ...form, amount: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Insurance covered</span>
            <input
              type="number"
              min={0}
              step="0.01"
              className="input"
              value={form.insuranceCovered}
              onChange={(event) => setForm({ ...form, insuranceCovered: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Status</span>
            <select
              className="input"
              value={form.status}
              onChange={(event) => setForm({ ...form, status: event.target.value })}
            >
              {STATUSES.map((status) => (
                <option key={status} value={status}>
                  {titleCase(status)}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Payment method</span>
            <select
              className="input"
              value={form.paymentMethod}
              onChange={(event) => setForm({ ...form, paymentMethod: event.target.value })}
            >
              {METHODS.map((method) => (
                <option key={method} value={method}>
                  {titleCase(method)}
                </option>
              ))}
            </select>
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Due date</span>
            <input
              type="date"
              className="input"
              value={form.dueDate}
              onChange={(event) => setForm({ ...form, dueDate: event.target.value })}
            />
          </label>
        </div>
      </FormModal>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete invoice"
        message={`Delete ${pendingDelete?.invoiceNumber} for ${pendingDelete?.patientName}?`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}

function ShieldIcon() {
  return <Banknote className="h-4 w-4" />;
}
