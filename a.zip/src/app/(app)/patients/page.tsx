import { Users } from "lucide-react";

import { getStaffOptions, listPatients } from "@/lib/queries";
import PatientsClient from "./PatientsClient";

export const dynamic = "force-dynamic";

export default async function PatientsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const [params, patients, staffOptions] = await Promise.all([
    searchParams,
    listPatients(),
    getStaffOptions(),
  ]);

  if (!patients.length) {
    return (
      <div className="card mt-10">
        <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-50 text-brand-600">
            <Users className="h-6 w-6" />
          </span>
          <p className="text-lg font-semibold text-slate-900">No patients yet</p>
          <p className="max-w-sm text-sm text-slate-500">
            The database is empty. Create your first patient record to start building the
            medical registry.
          </p>
        </div>
      </div>
    );
  }

  return (
    <PatientsClient
      initialPatients={patients}
      staffOptions={staffOptions}
      initialQuery={params.q ?? ""}
    />
  );
}
