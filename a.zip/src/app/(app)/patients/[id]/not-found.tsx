import Link from "next/link";

export default function PatientNotFound() {
  return (
    <div className="card mt-10">
      <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-rose-50 text-rose-500">
          ?
        </span>
        <p className="text-lg font-semibold text-slate-900">Patient not found</p>
        <p className="max-w-sm text-sm text-slate-500">
          This record may have been deleted or the link is out of date.
        </p>
        <Link href="/patients" className="btn-primary mt-2">
          Back to registry
        </Link>
      </div>
    </div>
  );
}
