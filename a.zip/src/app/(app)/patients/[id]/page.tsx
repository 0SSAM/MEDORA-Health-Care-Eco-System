import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  CalendarClock,
  ClipboardList,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Wallet,
} from "lucide-react";

import { getPatientDetail } from "@/lib/queries";
import {
  ageFrom,
  currency,
  formatDate,
  formatDateTime,
  titleCase,
} from "@/lib/utils";
import { StatusBadge } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function PatientDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const patient = await getPatientDetail(id);
  if (!patient) notFound();

  const outstanding = patient.invoices
    .filter((invoice) => invoice.status === "pending" || invoice.status === "overdue")
    .reduce((sum, invoice) => sum + Number(invoice.amount), 0);
  const billed = patient.invoices.reduce((sum, invoice) => sum + Number(invoice.amount), 0);

  return (
    <div className="space-y-6">
      <Link href="/patients" className="btn-ghost btn-sm -ml-2">
        <ArrowLeft className="h-4 w-4" /> Back to registry
      </Link>

      <div className="card overflow-hidden">
        <div className="relative bg-ink-900 px-6 py-8 text-white">
          <div className="grid-lines absolute inset-0 opacity-40" />
          <div className="absolute -right-10 -top-16 h-56 w-56 rounded-full bg-brand-500/25 blur-3xl" />
          <div className="relative flex flex-wrap items-center justify-between gap-5">
            <div className="flex items-center gap-4">
              <span className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600 text-xl font-bold shadow-lg">
                {patient.firstName[0]}
                {patient.lastName[0]}
              </span>
              <div>
                <h1 className="text-2xl font-semibold tracking-tight">
                  {patient.firstName} {patient.lastName}
                </h1>
                <p className="mt-1 text-sm text-white/60">
                  {patient.mrn} · {ageFrom(patient.dateOfBirth)} yrs · {titleCase(patient.gender)} ·{" "}
                  {patient.bloodType}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <StatusBadge status={patient.status} />
                  <span className="badge bg-white/10 text-white/80 ring-1 ring-inset ring-white/15">
                    {patient.riskLevel} risk
                  </span>
                  <span className="badge bg-white/10 text-white/80 ring-1 ring-inset ring-white/15">
                    {patient.insuranceProvider}
                  </span>
                </div>
              </div>
            </div>
            <div className="grid gap-2 text-sm text-white/70">
              <span className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-brand-300" /> {patient.phone || "No phone"}
              </span>
              <span className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-brand-300" /> {patient.email || "No email"}
              </span>
              <span className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-brand-300" /> {patient.address || patient.city}
              </span>
            </div>
          </div>
        </div>

        <div className="grid gap-4 px-6 py-5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: "Care lead", value: patient.primaryStaffName ?? "Unassigned", hint: patient.primaryStaffTitle ?? "" },
            { label: "Chronic conditions", value: patient.conditions, hint: "Problem list" },
            { label: "Allergies", value: patient.allergies, hint: "Alert" },
            { label: "Lifetime billed", value: currency(billed), hint: `${currency(outstanding)} outstanding` },
          ].map((item) => (
            <div key={item.label} className="rounded-2xl bg-slate-50 p-4 ring-1 ring-inset ring-slate-100">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                {item.label}
              </p>
              <p className="mt-1.5 text-sm font-semibold text-slate-900">{item.value}</p>
              <p className="mt-0.5 text-xs text-slate-400">{item.hint}</p>
            </div>
          ))}
        </div>
      </div>

      {patient.notes ? (
        <div className="card card-pad">
          <h2 className="section-title">Care notes</h2>
          <p className="mt-2 text-sm leading-relaxed text-slate-600">{patient.notes}</p>
        </div>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-2">
        <section className="card overflow-hidden">
          <header className="flex items-center gap-2 border-b border-slate-100 px-5 py-4">
            <CalendarClock className="h-4 w-4 text-slate-400" />
            <h2 className="section-title">Visit history</h2>
          </header>
          {patient.appointments.length ? (
            <ul className="divide-y divide-slate-100">
              {patient.appointments.map((visit) => (
                <li key={visit.appointment.id} className="flex items-center gap-3 px-5 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">
                      {visit.appointment.reason}
                    </p>
                    <p className="text-xs text-slate-500">
                      {formatDateTime(visit.appointment.scheduledAt)} · {visit.staffName ?? "Unassigned"} ·{" "}
                      {visit.appointment.room}
                    </p>
                  </div>
                  <StatusBadge status={visit.appointment.status} />
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-5 py-10 text-center text-sm text-slate-500">
              No appointments recorded for this patient yet.
            </p>
          )}
        </section>

        <section className="card overflow-hidden">
          <header className="flex items-center gap-2 border-b border-slate-100 px-5 py-4">
            <ClipboardList className="h-4 w-4 text-slate-400" />
            <h2 className="section-title">Prescriptions</h2>
          </header>
          {patient.prescriptions.length ? (
            <ul className="divide-y divide-slate-100">
              {patient.prescriptions.map((item) => (
                <li key={item.prescription.id} className="flex items-center gap-3 px-5 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">
                      {item.medicationName ?? "Compound"} · {item.prescription.dosage}
                    </p>
                    <p className="text-xs text-slate-500">
                      {item.prescription.frequency} · {item.prescription.durationDays} days ·{" "}
                      {formatDate(item.prescription.issuedAt)}
                    </p>
                  </div>
                  <StatusBadge status={item.prescription.status} />
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-5 py-10 text-center text-sm text-slate-500">
              No prescriptions issued yet.
            </p>
          )}
        </section>

        <section className="card overflow-hidden">
          <header className="flex items-center gap-2 border-b border-slate-100 px-5 py-4">
            <Wallet className="h-4 w-4 text-slate-400" />
            <h2 className="section-title">Invoices</h2>
          </header>
          {patient.invoices.length ? (
            <ul className="divide-y divide-slate-100">
              {patient.invoices.map((invoice) => (
                <li key={invoice.id} className="flex items-center gap-3 px-5 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">
                      {invoice.invoiceNumber} · {currency(invoice.amount)}
                    </p>
                    <p className="text-xs text-slate-500">
                      {invoice.itemsSummary} · {formatDate(invoice.issuedAt)}
                    </p>
                  </div>
                  <StatusBadge status={invoice.status} />
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-5 py-10 text-center text-sm text-slate-500">No invoices on file.</p>
          )}
        </section>

        <section className="card overflow-hidden">
          <header className="flex items-center gap-2 border-b border-slate-100 px-5 py-4">
            <ShieldCheck className="h-4 w-4 text-slate-400" />
            <h2 className="section-title">Insurance claims</h2>
          </header>
          {patient.claims.length ? (
            <ul className="divide-y divide-slate-100">
              {patient.claims.map((claim) => (
                <li key={claim.id} className="flex items-center gap-3 px-5 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">
                      {claim.claimNumber} · {currency(claim.amount)}
                    </p>
                    <p className="text-xs text-slate-500">
                      {claim.provider} · submitted {formatDate(claim.submittedAt)}
                    </p>
                  </div>
                  <StatusBadge status={claim.status} />
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-5 py-10 text-center text-sm text-slate-500">
              No claims submitted for this patient.
            </p>
          )}
        </section>
      </div>
    </div>
  );
}
