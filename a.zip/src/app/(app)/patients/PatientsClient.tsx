"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import {
  Eye,
  HeartPulse,
  Pencil,
  Plus,
  Trash2,
  UserPlus,
  Users,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { ageFrom, cn, formatDate, titleCase } from "@/lib/utils";
import type { Option, PatientListRow } from "@/lib/queries";
import {
  Avatar,
  ConfirmDialog,
  EmptyState,
  StatusBadge,
  TableSkeleton,
  useToast,
} from "@/components/ui";
import { FormModal, PageHeader, Toolbar } from "@/components/resource";

type FormState = {
  firstName: string;
  lastName: string;
  gender: string;
  dateOfBirth: string;
  phone: string;
  email: string;
  bloodType: string;
  city: string;
  address: string;
  insuranceProvider: string;
  insuranceNumber: string;
  status: string;
  riskLevel: string;
  primaryStaffId: string;
  allergies: string;
  conditions: string;
  notes: string;
};

const EMPTY: FormState = {
  firstName: "",
  lastName: "",
  gender: "female",
  dateOfBirth: "1990-01-01",
  phone: "",
  email: "",
  bloodType: "O+",
  city: "Riyadh",
  address: "",
  insuranceProvider: "Self-pay",
  insuranceNumber: "",
  status: "active",
  riskLevel: "low",
  primaryStaffId: "",
  allergies: "None recorded",
  conditions: "None recorded",
  notes: "",
};

const STATUS_TABS = ["all", "active", "recovering", "critical", "inactive"];
const BLOOD_TYPES = ["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"];
const INSURERS = ["Self-pay", "MedGulf", "Bupa Arabia", "AXA Arabia", "Tawuniya", "Malath"];

export default function PatientsClient({
  initialPatients,
  staffOptions,
  initialQuery,
}: {
  initialPatients: PatientListRow[];
  staffOptions: Option[];
  initialQuery: string;
}) {
  const toast = useToast();
  const [rows, setRows] = useState(initialPatients);
  const [query, setQuery] = useState(initialQuery);
  const [tab, setTab] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<PatientListRow | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY);
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<PatientListRow | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (tab !== "all" && row.status !== tab) return false;
      if (!term) return true;
      return [
        row.firstName,
        row.lastName,
        row.mrn,
        row.phone,
        row.email,
        row.city,
        row.insuranceProvider,
        row.conditions,
      ]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [rows, query, tab]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: rows.length };
    for (const row of rows) map[row.status] = (map[row.status] ?? 0) + 1;
    return map;
  }, [rows]);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY);
    setModalOpen(true);
  }

  function openEdit(row: PatientListRow) {
    setEditing(row);
    setForm({
      firstName: row.firstName,
      lastName: row.lastName,
      gender: row.gender,
      dateOfBirth: row.dateOfBirth,
      phone: row.phone,
      email: row.email,
      bloodType: row.bloodType,
      city: row.city,
      address: row.address,
      insuranceProvider: row.insuranceProvider,
      insuranceNumber: row.insuranceNumber,
      status: row.status,
      riskLevel: row.riskLevel,
      primaryStaffId: row.primaryStaffId ?? "",
      allergies: row.allergies,
      conditions: row.conditions,
      notes: row.notes,
    });
    setModalOpen(true);
  }

  async function submit() {
    setBusy(true);
    const payload = {
      ...form,
      dateOfBirth: form.dateOfBirth || "1990-01-01",
    };
    try {
      if (editing) {
        const previous = rows;
        const optimistic: PatientListRow = {
          ...editing,
          ...payload,
        } as PatientListRow;
        setRows((current) =>
          current.map((row) => (row.id === editing.id ? optimistic : row)),
        );
        setModalOpen(false);
        try {
          const saved = await apiRequest<PatientListRow>(`/api/patients/${editing.id}`, {
            method: "PATCH",
            json: payload,
          });
          setRows((current) =>
            current.map((row) => (row.id === editing.id ? { ...row, ...saved } : row)),
          );
          toast.push({ title: "Patient record updated", tone: "success" });
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic: PatientListRow = {
          id: `temp-${Date.now()}`,
          mrn: "MRN pending…",
          primaryStaffName:
            staffOptions.find((option) => option.id === form.primaryStaffId)?.label ?? null,
          createdAt: new Date(),
          ...payload,
        } as PatientListRow;
        setRows((current) => [optimistic, ...current]);
        setModalOpen(false);
        try {
          const created = await apiRequest<PatientListRow>("/api/patients", {
            method: "POST",
            json: payload,
          });
          setRows((current) =>
            current.map((row) => (row.id === optimistic.id ? { ...created } : row)),
          );
          toast.push({ title: `${created.firstName} ${created.lastName} registered`, tone: "success" });
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    const target = pendingDelete;
    setRows((current) => current.filter((row) => row.id !== target.id));
    try {
      await apiRequest(`/api/patients/${target.id}`, { method: "DELETE" });
      toast.push({ title: "Patient removed from registry", tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  async function refresh() {
    setRefreshing(true);
    try {
      const data = await apiRequest<PatientListRow[]>("/api/patients");
      setRows(data);
    } catch (error) {
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setRefreshing(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="Patients"
        subtitle="Master registry of everyone under care — demographics, coverage and risk."
      >
        <button type="button" className="btn-secondary" onClick={refresh} disabled={refreshing}>
          {refreshing ? "Syncing…" : "Sync"}
        </button>
        <button type="button" className="btn-primary" onClick={openCreate}>
          <UserPlus className="h-4 w-4" /> New patient
        </button>
      </PageHeader>

      <Toolbar
        search={query}
        onSearch={setQuery}
        placeholder="Search by name, MRN, phone or city…"
        tabs={STATUS_TABS.map((value) => ({
          value,
          label: value === "all" ? "All patients" : titleCase(value),
          count: counts[value] ?? 0,
        }))}
        activeTab={tab}
        onTab={setTab}
        resultCount={filtered.length}
      />

      <div className="card overflow-hidden">
        {refreshing && !rows.length ? (
          <TableSkeleton />
        ) : filtered.length ? (
          <div className="overflow-x-auto">
            <table className="table-shell">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Age / Sex</th>
                  <th>Contact</th>
                  <th>Coverage</th>
                  <th>Care lead</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.id} className={cn(row.id.startsWith("temp-") && "opacity-60")}>
                    <td>
                      <Avatar
                        name={`${row.firstName} ${row.lastName}`}
                        subtitle={`${row.mrn} · ${row.bloodType}`}
                      />
                    </td>
                    <td className="whitespace-nowrap">
                      <span className="font-medium text-slate-800">{ageFrom(row.dateOfBirth)}</span>
                      <span className="text-slate-400"> · {titleCase(row.gender)}</span>
                      <span className="block text-xs text-slate-400">
                        DOB {formatDate(row.dateOfBirth)}
                      </span>
                    </td>
                    <td>
                      <span className="block text-sm text-slate-700">{row.phone || "—"}</span>
                      <span className="block text-xs text-slate-400">{row.city}</span>
                    </td>
                    <td>
                      <span className="block text-sm text-slate-700">{row.insuranceProvider}</span>
                      <span className="block text-xs text-slate-400">
                        {row.insuranceNumber || "No policy"}
                      </span>
                    </td>
                    <td className="text-sm text-slate-600">{row.primaryStaffName ?? "Unassigned"}</td>
                    <td>
                      <div className="flex flex-col items-start gap-1.5">
                        <StatusBadge status={row.status} />
                        <span className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
                          {row.riskLevel} risk
                        </span>
                      </div>
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <Link
                          href={`/patients/${row.id}`}
                          className="btn-ghost rounded-lg p-2"
                          title="Open record"
                        >
                          <Eye className="h-4 w-4" />
                        </Link>
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2"
                          onClick={() => openEdit(row)}
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                          onClick={() => setPendingDelete(row)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<Users className="h-6 w-6" />}
            title={query ? "No patients match your search" : "No patients in this view"}
            description={
              query
                ? `Nothing found for “${query}”. Try a different name, MRN or city.`
                : "Register a patient to populate this view."
            }
            action={
              <button type="button" className="btn-primary" onClick={openCreate}>
                <Plus className="h-4 w-4" /> Register patient
              </button>
            }
          />
        )}
      </div>

      <FormModal
        open={modalOpen}
        mode={editing ? "edit" : "create"}
        size="lg"
        title={editing ? `Edit ${editing.firstName} ${editing.lastName}` : "Register new patient"}
        description={
          editing ? "Update demographics, coverage and clinical flags." : "Create a medical record in the registry."
        }
        onClose={() => setModalOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="label">First name *</span>
            <input
              required
              className="input"
              value={form.firstName}
              onChange={(event) => setForm({ ...form, firstName: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Last name *</span>
            <input
              required
              className="input"
              value={form.lastName}
              onChange={(event) => setForm({ ...form, lastName: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Date of birth</span>
            <input
              type="date"
              className="input"
              value={form.dateOfBirth}
              onChange={(event) => setForm({ ...form, dateOfBirth: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Gender</span>
            <select
              className="input"
              value={form.gender}
              onChange={(event) => setForm({ ...form, gender: event.target.value })}
            >
              <option value="female">Female</option>
              <option value="male">Male</option>
            </select>
          </label>
          <label className="block">
            <span className="label">Phone</span>
            <input
              className="input"
              value={form.phone}
              onChange={(event) => setForm({ ...form, phone: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Email</span>
            <input
              type="email"
              className="input"
              value={form.email}
              onChange={(event) => setForm({ ...form, email: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Blood type</span>
            <select
              className="input"
              value={form.bloodType}
              onChange={(event) => setForm({ ...form, bloodType: event.target.value })}
            >
              {BLOOD_TYPES.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">City</span>
            <input
              className="input"
              value={form.city}
              onChange={(event) => setForm({ ...form, city: event.target.value })}
            />
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Address</span>
            <input
              className="input"
              value={form.address}
              onChange={(event) => setForm({ ...form, address: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Insurance provider</span>
            <select
              className="input"
              value={form.insuranceProvider}
              onChange={(event) => setForm({ ...form, insuranceProvider: event.target.value })}
            >
              {INSURERS.map((insurer) => (
                <option key={insurer} value={insurer}>
                  {insurer}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Policy number</span>
            <input
              className="input"
              value={form.insuranceNumber}
              onChange={(event) => setForm({ ...form, insuranceNumber: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Status</span>
            <select
              className="input"
              value={form.status}
              onChange={(event) => setForm({ ...form, status: event.target.value })}
            >
              {["active", "recovering", "critical", "inactive"].map((status) => (
                <option key={status} value={status}>
                  {titleCase(status)}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Risk level</span>
            <select
              className="input"
              value={form.riskLevel}
              onChange={(event) => setForm({ ...form, riskLevel: event.target.value })}
            >
              {["low", "moderate", "high"].map((level) => (
                <option key={level} value={level}>
                  {titleCase(level)}
                </option>
              ))}
            </select>
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Primary clinician</span>
            <select
              className="input"
              value={form.primaryStaffId}
              onChange={(event) => setForm({ ...form, primaryStaffId: event.target.value })}
            >
              <option value="">Unassigned</option>
              {staffOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label} — {option.hint}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Allergies</span>
            <input
              className="input"
              value={form.allergies}
              onChange={(event) => setForm({ ...form, allergies: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Chronic conditions</span>
            <input
              className="input"
              value={form.conditions}
              onChange={(event) => setForm({ ...form, conditions: event.target.value })}
            />
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Care notes</span>
            <textarea
              rows={3}
              className="input resize-none"
              value={form.notes}
              onChange={(event) => setForm({ ...form, notes: event.target.value })}
            />
          </label>
        </div>
      </FormModal>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete patient record"
        message={`This permanently removes ${pendingDelete?.firstName} ${pendingDelete?.lastName} (${pendingDelete?.mrn}) along with their history links. This action cannot be undone.`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />

      <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-slate-400">
        <HeartPulse className="h-3.5 w-3.5" /> {rows.length} records synced with PostgreSQL
      </p>
    </div>
  );
}
