"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import {
  Database,
  KeyRound,
  Pencil,
  Plus,
  ShieldCheck,
  Trash2,
  UserCog,
  Users,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { ROLE_LABELS, ROLE_OPTIONS } from "@/lib/roles";
import { cn, formatDateTime } from "@/lib/utils";
import type { TeamRow } from "@/lib/queries";
import { Avatar, ConfirmDialog, EmptyState, Pill, StatusBadge, useToast } from "@/components/ui";
import { FormModal, PageHeader, StatCard, Toolbar } from "@/components/resource";

type FormState = {
  name: string;
  email: string;
  role: string;
  department: string;
  phone: string;
  password: string;
  isActive: boolean;
};

export default function SettingsClient({
  currentUserId,
  currentUserRole,
  currentUserEmail,
  initialTeam,
}: {
  currentUserId: string;
  currentUserRole: string;
  currentUserEmail: string;
  initialTeam: TeamRow[];
}) {
  const router = useRouter();
  const toast = useToast();
  const [rows, setRows] = useState(initialTeam);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<TeamRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<TeamRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [reseeding, setReseeding] = useState(false);
  const [form, setForm] = useState<FormState>({
    name: "",
    email: "",
    role: "front_desk",
    department: "Front Office",
    phone: "",
    password: "",
    isActive: true,
  });

  const stats = useMemo(
    () => ({
      total: rows.length,
      admins: rows.filter((row) => row.role === "admin").length,
      active: rows.filter((row) => row.isActive).length,
    }),
    [rows],
  );

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return rows;
    return rows.filter((row) =>
      [row.name, row.email, row.department, row.role].join(" ").toLowerCase().includes(term),
    );
  }, [rows, query]);

  function openCreate() {
    setEditing(null);
    setForm({
      name: "",
      email: "",
      role: "front_desk",
      department: "Front Office",
      phone: "",
      password: "medora123",
      isActive: true,
    });
    setOpen(true);
  }

  function openEdit(row: TeamRow) {
    setEditing(row);
    setForm({
      name: row.name,
      email: row.email,
      role: row.role,
      department: row.department,
      phone: row.phone,
      password: "",
      isActive: row.isActive,
    });
    setOpen(true);
  }

  async function submit() {
    setBusy(true);
    const payload: Record<string, unknown> = {
      name: form.name,
      email: form.email,
      role: form.role,
      department: form.department,
      phone: form.phone,
      isActive: form.isActive,
    };
    if (form.password) payload.password = form.password;

    try {
      if (editing) {
        const previous = rows;
        setRows((current) =>
          current.map((row) =>
            row.id === editing.id ? { ...row, ...form, password: undefined } : row,
          ),
        );
        setOpen(false);
        try {
          await apiRequest<TeamRow>(`/api/team/${editing.id}`, {
            method: "PATCH",
            json: payload,
          });
          toast.push({ title: "Account updated", tone: "success" });
          router.refresh();
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic: TeamRow = {
          id: `temp-${Date.now()}`,
          name: form.name,
          email: form.email.toLowerCase(),
          role: form.role,
          department: form.department,
          phone: form.phone,
          isActive: form.isActive,
          lastLoginAt: null,
          createdAt: new Date(),
        };
        setRows((current) => [...current, optimistic]);
        setOpen(false);
        try {
          const created = await apiRequest<TeamRow>("/api/team", {
            method: "POST",
            json: payload,
          });
          setRows((current) => current.map((row) => (row.id === optimistic.id ? created : row)));
          toast.push({ title: `${created.name} can now sign in`, tone: "success" });
          router.refresh();
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function toggleActive(row: TeamRow) {
    const previous = rows;
    setRows((current) =>
      current.map((item) => (item.id === row.id ? { ...item, isActive: !item.isActive } : item)),
    );
    try {
      await apiRequest(`/api/team/${row.id}`, {
        method: "PATCH",
        json: { isActive: !row.isActive },
      });
      toast.push({
        title: row.isActive ? "Account suspended" : "Account reactivated",
        tone: "success",
      });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== pendingDelete.id));
    try {
      await apiRequest(`/api/team/${pendingDelete.id}`, { method: "DELETE" });
      toast.push({ title: "Account removed", tone: "success" });
      router.refresh();
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  async function reseed() {
    setReseeding(true);
    try {
      await apiRequest("/api/seed?reset=1", { method: "POST" });
      toast.push({ title: "Demo dataset regenerated — reloading…", tone: "success" });
      router.refresh();
    } catch (error) {
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setReseeding(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="Access & workspace"
        subtitle="Manage who can sign in, their roles and the underlying demo dataset."
      >
        <button type="button" className="btn-primary" onClick={openCreate}>
          <Plus className="h-4 w-4" /> Invite member
        </button>
      </PageHeader>

      <section className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard label="Accounts" value={stats.total} icon={<Users className="h-4 w-4" />} />
        <StatCard label="Active" value={stats.active} icon={<ShieldCheck className="h-4 w-4" />} tone="sky" />
        <StatCard label="Administrators" value={stats.admins} icon={<UserCog className="h-4 w-4" />} tone="violet" />
      </section>

      <div className="grid gap-4 xl:grid-cols-[1.6fr_1fr]">
        <div>
          <Toolbar search={query} onSearch={setQuery} placeholder="Search accounts…" />
          <div className="card overflow-hidden">
            {filtered.length ? (
              <div className="overflow-x-auto">
                <table className="table-shell min-w-[640px]">
                  <thead>
                    <tr>
                      <th>Member</th>
                      <th>Role</th>
                      <th>Last sign-in</th>
                      <th>Status</th>
                      <th className="text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((row) => (
                      <tr key={row.id} className={cn(row.id.startsWith("temp-") && "opacity-60")}>
                        <td>
                          <Avatar name={row.name} subtitle={row.email} />
                        </td>
                        <td>
                          <Pill tone={row.role === "admin" ? "violet" : "blue"}>
                            {ROLE_LABELS[row.role] ?? row.role}
                          </Pill>
                          <span className="mt-1 block text-xs text-slate-400">
                            {row.department}
                          </span>
                        </td>
                        <td className="text-sm text-slate-600">
                          {row.lastLoginAt ? formatDateTime(row.lastLoginAt) : "Never"}
                        </td>
                        <td>
                          <StatusBadge status={row.isActive ? "active" : "inactive"} />
                        </td>
                        <td>
                          <div className="flex items-center justify-end gap-1">
                            {row.id === currentUserId ? (
                              <span className="badge bg-slate-100 text-slate-500">You</span>
                            ) : (
                              <button
                                type="button"
                                className="btn-ghost btn-sm"
                                onClick={() => toggleActive(row)}
                              >
                                {row.isActive ? "Suspend" : "Activate"}
                              </button>
                            )}
                            <button
                              type="button"
                              className="btn-ghost rounded-lg p-2"
                              onClick={() => openEdit(row)}
                              title="Edit"
                            >
                              <Pencil className="h-4 w-4" />
                            </button>
                            <button
                              type="button"
                              className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50 disabled:opacity-40"
                              disabled={row.id === currentUserId}
                              onClick={() => setPendingDelete(row)}
                              title="Delete"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <EmptyState
                icon={<Users className="h-6 w-6" />}
                title="No accounts found"
                description="Invite a colleague to give them access to MEDORA."
                action={
                  <button type="button" className="btn-primary" onClick={openCreate}>
                    <Plus className="h-4 w-4" /> Invite member
                  </button>
                }
              />
            )}
          </div>
        </div>

        <div className="space-y-4">
          <div className="card card-pad">
            <div className="flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-slate-400" />
              <h2 className="section-title">Your session</h2>
            </div>
            <dl className="mt-4 space-y-3 text-sm">
              <div className="flex justify-between gap-3">
                <dt className="text-slate-500">Signed in as</dt>
                <dd className="text-right font-medium text-slate-800">{currentUserEmail}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-slate-500">Role</dt>
                <dd className="text-right font-medium text-slate-800">
                  {ROLE_LABELS[currentUserRole] ?? currentUserRole}
                </dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-slate-500">Auth</dt>
                <dd className="text-right font-medium text-slate-800">Signed HTTP-only cookie</dd>
              </div>
            </dl>
          </div>

          <div className="card card-pad">
            <div className="flex items-center gap-2">
              <Database className="h-4 w-4 text-slate-400" />
              <h2 className="section-title">Demo dataset</h2>
            </div>
            <p className="muted mt-2">
              Regenerate the seeded patients, clinicians, pharmacy stock, invoices and claims.
              Existing changes will be replaced.
            </p>
            <button
              type="button"
              className="btn-secondary mt-4 w-full justify-center"
              onClick={reseed}
              disabled={reseeding || currentUserRole !== "admin"}
            >
              {reseeding ? "Regenerating…" : "Reset demo data"}
            </button>
            {currentUserRole !== "admin" ? (
              <p className="mt-2 text-xs text-amber-600">
                Only administrators can reset the dataset.
              </p>
            ) : null}
          </div>

          <div className="card card-pad">
            <h2 className="section-title">Role capabilities</h2>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              {ROLE_OPTIONS.map((role) => (
                <li key={role.value} className="flex items-start gap-2">
                  <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-brand-500" />
                  <span>
                    <span className="font-medium text-slate-800">{role.label}</span> — full read
                    access{role.value === "admin" ? " plus workspace administration" : ""}.
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <FormModal
        open={open}
        mode={editing ? "edit" : "create"}
        title={editing ? `Edit ${editing.name}` : "Invite team member"}
        description="Accounts use an email plus password to sign in."
        onClose={() => setOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="label">Full name *</span>
            <input
              required
              className="input"
              value={form.name}
              onChange={(event) => setForm({ ...form, name: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Email *</span>
            <input
              required
              type="email"
              className="input"
              value={form.email}
              onChange={(event) => setForm({ ...form, email: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Role</span>
            <select
              className="input"
              value={form.role}
              onChange={(event) => setForm({ ...form, role: event.target.value })}
            >
              {ROLE_OPTIONS.map((role) => (
                <option key={role.value} value={role.value}>
                  {role.label}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Department</span>
            <input
              className="input"
              value={form.department}
              onChange={(event) => setForm({ ...form, department: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Phone</span>
            <input
              className="input"
              value={form.phone}
              onChange={(event) => setForm({ ...form, phone: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">
              {editing ? "New password (leave blank to keep)" : "Password *"}
            </span>
            <input
              type="password"
              required={!editing}
              className="input"
              value={form.password}
              onChange={(event) => setForm({ ...form, password: event.target.value })}
            />
          </label>
          <label className="flex items-center gap-2 sm:col-span-2">
            <input
              type="checkbox"
              className="h-4 w-4 rounded border-slate-300 text-brand-600"
              checked={form.isActive}
              onChange={(event) => setForm({ ...form, isActive: event.target.checked })}
            />
            <span className="text-sm text-slate-600">
              Account active — can sign in immediately
            </span>
          </label>
        </div>
      </FormModal>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Remove account"
        message={`Revoke access for ${pendingDelete?.name} (${pendingDelete?.email})?`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
