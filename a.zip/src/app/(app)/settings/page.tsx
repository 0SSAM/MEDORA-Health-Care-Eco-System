import { listTeam } from "@/lib/queries";
import { requireUser } from "@/lib/auth";
import SettingsClient from "./SettingsClient";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const [user, team] = await Promise.all([requireUser(), listTeam()]);

  return (
    <SettingsClient
      currentUserId={user.id}
      currentUserRole={user.role}
      currentUserEmail={user.email}
      initialTeam={team}
    />
  );
}
