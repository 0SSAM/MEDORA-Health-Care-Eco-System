import { CalendarClock } from "lucide-react";

import { getPatientOptions, getStaffOptions, listAppointments } from "@/lib/queries";
import AppointmentsClient from "./AppointmentsClient";

export const dynamic = "force-dynamic";

export default async function AppointmentsPage() {
  const [appointments, patientOptions, staffOptions] = await Promise.all([
    listAppointments(),
    getPatientOptions(),
    getStaffOptions(),
  ]);

  if (!appointments.length) {
    return (
      <div className="card mt-10">
        <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-sky-50 text-sky-600">
            <CalendarClock className="h-6 w-6" />
          </span>
          <p className="text-lg font-semibold text-slate-900">The calendar is empty</p>
          <p className="max-w-sm text-sm text-slate-500">
            Book the first appointment to start building the clinic schedule.
          </p>
        </div>
      </div>
    );
  }

  return (
    <AppointmentsClient
      initialAppointments={appointments}
      patientOptions={patientOptions}
      staffOptions={staffOptions}
    />
  );
}
