"use client";

import { useMemo, useState } from "react";
import {
  CalendarClock,
  CalendarPlus,
  CheckCircle2,
  Pencil,
  PlayCircle,
  Trash2,
  XCircle,
} from "lucide-react";

import { apiRequest } from "@/lib/client";
import { cn, formatDateTime, titleCase, toInputDateTime } from "@/lib/utils";
import type { AppointmentListRow, Option } from "@/lib/queries";
import { ConfirmDialog, EmptyState, StatusBadge, useToast } from "@/components/ui";
import { FormModal, PageHeader, Toolbar } from "@/components/resource";

type FormState = {
  patientId: string;
  staffId: string;
  scheduledAt: string;
  durationMinutes: string;
  type: string;
  status: string;
  reason: string;
  room: string;
  notes: string;
};

function defaultSlot() {
  const date = new Date();
  date.setDate(date.getDate() + 1);
  date.setHours(10, 0, 0, 0);
  return toInputDateTime(date);
}

const TYPES = ["consultation", "follow_up", "telemedicine", "procedure", "annual_checkup", "lab_review"];
const STATUSES = ["scheduled", "confirmed", "completed", "cancelled", "no_show"];
const ROOMS = ["OPD-1", "OPD-2", "OPD-4", "Cardio-A", "Tele-Room", "ER-Bay-3", "Ped-2"];

export default function AppointmentsClient({
  initialAppointments,
  patientOptions,
  staffOptions,
}: {
  initialAppointments: AppointmentListRow[];
  patientOptions: Option[];
  staffOptions: Option[];
}) {
  const toast = useToast();
  const [rows, setRows] = useState(initialAppointments);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("upcoming");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<AppointmentListRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<AppointmentListRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState<FormState>({
    patientId: patientOptions[0]?.id ?? "",
    staffId: staffOptions[0]?.id ?? "",
    scheduledAt: defaultSlot(),
    durationMinutes: "30",
    type: "consultation",
    status: "scheduled",
    reason: "General consultation",
    room: "OPD-1",
    notes: "",
  });

  const now = Date.now();

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows
      .filter((row) => {
        const time = new Date(row.scheduledAt).getTime();
        if (tab === "upcoming" && time < now) return false;
        if (tab === "today") {
          const start = new Date();
          start.setHours(0, 0, 0, 0);
          if (time < start.getTime() || time >= start.getTime() + 86400000) return false;
        }
        if (tab === "past" && time >= now) return false;
        if (STATUSES.includes(tab) && row.status !== tab) return false;
        if (!term) return true;
        return [row.patientName, row.reason, row.room, row.type, row.staffName]
          .join(" ")
          .toLowerCase()
          .includes(term);
      })
      .sort((a, b) => {
        const left = new Date(a.scheduledAt).getTime();
        const right = new Date(b.scheduledAt).getTime();
        return tab === "past" ? right - left : left - right;
      });
  }, [rows, query, tab, now]);

  const counts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const row of rows) {
      map[row.status] = (map[row.status] ?? 0) + 1;
      const time = new Date(row.scheduledAt).getTime();
      if (time >= now) map.upcoming = (map.upcoming ?? 0) + 1;
    }
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    map.today = rows.filter((row) => {
      const time = new Date(row.scheduledAt).getTime();
      return time >= start.getTime() && time < start.getTime() + 86400000;
    }).length;
    map.past = rows.length - (map.upcoming ?? 0);
    map.all = rows.length;
    return map;
  }, [rows, now]);

  function openCreate() {
    setEditing(null);
    setForm({
      patientId: patientOptions[0]?.id ?? "",
      staffId: staffOptions[0]?.id ?? "",
      scheduledAt: defaultSlot(),
      durationMinutes: "30",
      type: "consultation",
      status: "scheduled",
      reason: "General consultation",
      room: "OPD-1",
      notes: "",
    });
    setOpen(true);
  }

  function openEdit(row: AppointmentListRow) {
    setEditing(row);
    setForm({
      patientId: row.patientId,
      staffId: row.staffId ?? "",
      scheduledAt: toInputDateTime(row.scheduledAt),
      durationMinutes: String(row.durationMinutes),
      type: row.type,
      status: row.status,
      reason: row.reason,
      room: row.room,
      notes: row.notes,
    });
    setOpen(true);
  }

  async function patchStatus(row: AppointmentListRow, status: string) {
    const previous = rows;
    setRows((current) =>
      current.map((item) => (item.id === row.id ? { ...item, status } : item)),
    );
    try {
      await apiRequest(`/api/appointments/${row.id}`, { method: "PATCH", json: { status } });
      toast.push({ title: `Visit marked ${titleCase(status)}`, tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    }
  }

  async function submit() {
    setBusy(true);
    const payload = {
      ...form,
      durationMinutes: Number(form.durationMinutes),
      scheduledAt: new Date(form.scheduledAt).toISOString(),
    };
    try {
      if (editing) {
        const previous = rows;
        setRows((current) =>
          current.map((row) =>
            row.id === editing.id
              ? {
                  ...row,
                  ...payload,
                  patientName:
                    patientOptions.find((option) => option.id === payload.patientId)?.label ??
                    row.patientName,
                  staffName:
                    staffOptions.find((option) => option.id === payload.staffId)?.label ?? null,
                  staffId: payload.staffId || null,
                  scheduledAt: new Date(payload.scheduledAt),
                  durationMinutes: payload.durationMinutes,
                }
              : row,
          ),
        );
        setOpen(false);
        try {
          await apiRequest(`/api/appointments/${editing.id}`, { method: "PATCH", json: payload });
          toast.push({ title: "Appointment updated", tone: "success" });
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic: AppointmentListRow = {
          id: `temp-${Date.now()}`,
          patientId: form.patientId,
          patientName:
            patientOptions.find((option) => option.id === form.patientId)?.label ?? "Patient",
          patientMrn: patientOptions.find((option) => option.id === form.patientId)?.hint ?? null,
          staffId: form.staffId || null,
          staffName: staffOptions.find((option) => option.id === form.staffId)?.label ?? null,
          scheduledAt: new Date(payload.scheduledAt),
          durationMinutes: payload.durationMinutes,
          type: form.type,
          status: form.status,
          reason: form.reason,
          room: form.room,
          notes: form.notes,
        };
        setRows((current) => [optimistic, ...current]);
        setOpen(false);
        try {
          const created = await apiRequest<AppointmentListRow>("/api/appointments", {
            method: "POST",
            json: payload,
          });
          setRows((current) =>
            current.map((row) => (row.id === optimistic.id ? created : row)),
          );
          toast.push({ title: "Appointment booked", tone: "success" });
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== pendingDelete.id));
    try {
      await apiRequest(`/api/appointments/${pendingDelete.id}`, { method: "DELETE" });
      toast.push({ title: "Appointment cancelled and removed", tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  const tabs = [
    { value: "today", label: "Today", count: counts.today ?? 0 },
    { value: "upcoming", label: "Upcoming", count: counts.upcoming ?? 0 },
    { value: "past", label: "Past", count: counts.past ?? 0 },
    { value: "all", label: "All", count: counts.all ?? 0 },
    ...STATUSES.map((status) => ({ value: status, label: titleCase(status), count: counts[status] ?? 0 })),
  ];

  return (
    <div>
      <PageHeader
        title="Appointments"
        subtitle="Clinic, telemedicine and procedure bookings with live status control."
      >
        <button type="button" className="btn-primary" onClick={openCreate}>
          <CalendarPlus className="h-4 w-4" /> Book appointment
        </button>
      </PageHeader>

      <Toolbar
        search={query}
        onSearch={setQuery}
        placeholder="Search reason, room, clinician or patient…"
        tabs={tabs}
        activeTab={tab}
        onTab={setTab}
        resultCount={filtered.length}
      />

      <div className="card overflow-hidden">
        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="table-shell">
              <thead>
                <tr>
                  <th>When</th>
                  <th>Patient</th>
                  <th>Clinician</th>
                  <th>Type</th>
                  <th>Room</th>
                  <th>Status</th>
                  <th className="text-right">Quick actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.id} className={cn(row.id.startsWith("temp-") && "opacity-60")}>
                    <td className="whitespace-nowrap">
                      <span className="block font-medium text-slate-800">
                        {formatDateTime(row.scheduledAt)}
                      </span>
                      <span className="text-xs text-slate-400">{row.durationMinutes} min</span>
                    </td>
                    <td>
                      <span className="block font-medium text-slate-800">{row.patientName}</span>
                      <span className="block text-xs text-slate-400">{row.patientMrn ?? "—"}</span>
                    </td>
                    <td className="text-sm text-slate-600">{row.staffName ?? "Unassigned"}</td>
                    <td className="text-sm text-slate-600">{titleCase(row.type)}</td>
                    <td className="text-sm text-slate-600">{row.room}</td>
                    <td>
                      <StatusBadge status={row.status} />
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        {row.status === "scheduled" || row.status === "confirmed" ? (
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-emerald-600 hover:bg-emerald-50"
                            title="Mark completed"
                            onClick={() => patchStatus(row, "completed")}
                          >
                            <CheckCircle2 className="h-4 w-4" />
                          </button>
                        ) : null}
                        {row.status === "scheduled" ? (
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-sky-600 hover:bg-sky-50"
                            title="Confirm"
                            onClick={() => patchStatus(row, "confirmed")}
                          >
                            <PlayCircle className="h-4 w-4" />
                          </button>
                        ) : null}
                        {row.status !== "cancelled" ? (
                          <button
                            type="button"
                            className="btn-ghost rounded-lg p-2 text-amber-600 hover:bg-amber-50"
                            title="Cancel visit"
                            onClick={() => patchStatus(row, "cancelled")}
                          >
                            <XCircle className="h-4 w-4" />
                          </button>
                        ) : null}
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2"
                          onClick={() => openEdit(row)}
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                          onClick={() => setPendingDelete(row)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<CalendarClock className="h-6 w-6" />}
            title="No appointments in this view"
            description="Adjust the filters or book a new visit for a patient."
            action={
              <button type="button" className="btn-primary" onClick={openCreate}>
                <CalendarPlus className="h-4 w-4" /> Book appointment
              </button>
            }
          />
        )}
      </div>

      <FormModal
        open={open}
        mode={editing ? "edit" : "create"}
        title={editing ? "Reschedule appointment" : "Book appointment"}
        description="Assign a clinician, room and time slot."
        onClose={() => setOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block sm:col-span-2">
            <span className="label">Patient *</span>
            <select
              required
              className="input"
              value={form.patientId}
              onChange={(event) => setForm({ ...form, patientId: event.target.value })}
            >
              <option value="">Select a patient…</option>
              {patientOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label} ({option.hint})
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Clinician</span>
            <select
              className="input"
              value={form.staffId}
              onChange={(event) => setForm({ ...form, staffId: event.target.value })}
            >
              <option value="">Unassigned</option>
              {staffOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label} — {option.hint}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Date &amp; time *</span>
            <input
              required
              type="datetime-local"
              className="input"
              value={form.scheduledAt}
              onChange={(event) => setForm({ ...form, scheduledAt: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Visit type</span>
            <select
              className="input"
              value={form.type}
              onChange={(event) => setForm({ ...form, type: event.target.value })}
            >
              {TYPES.map((type) => (
                <option key={type} value={type}>
                  {titleCase(type)}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Duration (minutes)</span>
            <input
              type="number"
              min={5}
              step={5}
              className="input"
              value={form.durationMinutes}
              onChange={(event) => setForm({ ...form, durationMinutes: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Room</span>
            <select
              className="input"
              value={form.room}
              onChange={(event) => setForm({ ...form, room: event.target.value })}
            >
              {ROOMS.map((room) => (
                <option key={room} value={room}>
                  {room}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Status</span>
            <select
              className="input"
              value={form.status}
              onChange={(event) => setForm({ ...form, status: event.target.value })}
            >
              {STATUSES.map((status) => (
                <option key={status} value={status}>
                  {titleCase(status)}
                </option>
              ))}
            </select>
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Reason for visit</span>
            <input
              className="input"
              value={form.reason}
              onChange={(event) => setForm({ ...form, reason: event.target.value })}
            />
          </label>
          <label className="block sm:col-span-2">
            <span className="label">Clinical notes</span>
            <textarea
              rows={3}
              className="input resize-none"
              value={form.notes}
              onChange={(event) => setForm({ ...form, notes: event.target.value })}
            />
          </label>
        </div>
      </FormModal>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete appointment"
        message={`Remove the ${pendingDelete?.reason} slot for ${pendingDelete?.patientName}?`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
