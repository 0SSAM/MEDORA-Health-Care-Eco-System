import Link from "next/link";
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  CalendarClock,
  ClipboardList,
  Pill,
  ShieldCheck,
  Stethoscope,
  Users,
  Wallet,
} from "lucide-react";

import { getDashboardData } from "@/lib/queries";
import { requireUser } from "@/lib/auth";
import {
  compactCurrency,
  currency,
  formatTime,
  relativeTime,
  titleCase,
} from "@/lib/utils";
import { BarList, DonutChart, TrendChart } from "@/components/charts";
import { PageHeader, StatCard } from "@/components/resource";
import { Pill as Tag, StatusBadge } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await requireUser();
  const data = await getDashboardData();
  const { metrics } = data;

  const claimData = data.claimSummary.map((row) => ({
    label: titleCase(row.status),
    value: row.total,
  }));
  const claimTotal = data.claimSummary.reduce((sum, row) => sum + row.total, 0);
  const approvedClaims = data.claimSummary
    .filter((row) => row.status === "approved" || row.status === "paid")
    .reduce((sum, row) => sum + row.total, 0);
  const approvalRate = claimTotal ? Math.round((approvedClaims / claimTotal) * 100) : 0;

  const trend = data.revenueTrend.map((row) => ({ day: row.day, total: row.total }));
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="space-y-6">
      <PageHeader
        title={`${greeting}, ${user.name.split(" ").slice(-1)[0]}`}
        subtitle={`Here is the pulse of your care network · ${new Date().toLocaleDateString("en-US", {
          weekday: "long",
          month: "long",
          day: "numeric",
        })}`}
      >
        <Link href="/appointments" className="btn-secondary">
          <CalendarClock className="h-4 w-4" /> Schedule
        </Link>
        <Link href="/patients" className="btn-primary">
          <Users className="h-4 w-4" /> Register patient
        </Link>
      </PageHeader>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Patients on file"
          value={metrics.totalPatients}
          delta={`+${metrics.newPatients} this month`}
          footer={`${metrics.criticalPatients} critical`}
          icon={<Users className="h-4 w-4" />}
        />
        <StatCard
          label="Appointments today"
          value={metrics.todayAppointments}
          delta={`${metrics.upcomingAppointments} upcoming`}
          footer="next 7 days"
          icon={<CalendarClock className="h-4 w-4" />}
          tone="sky"
        />
        <StatCard
          label="Collected revenue"
          value={compactCurrency(metrics.collected)}
          delta={`${compactCurrency(metrics.monthCollected)} MTD`}
          footer="all time · paid"
          icon={<Wallet className="h-4 w-4" />}
          tone="violet"
        />
        <StatCard
          label="Pending prescriptions"
          value={metrics.pendingPrescriptions}
          delta={`${metrics.activePrescriptions} active`}
          footer="pharmacy queue"
          icon={<ClipboardList className="h-4 w-4" />}
          tone="amber"
        />
      </section>

      <section className="grid gap-4 xl:grid-cols-3">
        <div className="card card-pad xl:col-span-2">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="section-title">Revenue · last 14 days</h2>
              <p className="muted mt-1">Gross billed value across clinic and POS channels</p>
            </div>
            <Link href="/billing" className="btn-secondary btn-sm">
              Billing ledger <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </div>
          <div className="mt-4">
            <TrendChart data={trend} />
          </div>
          <div className="mt-4 grid gap-3 border-t border-slate-100 pt-4 sm:grid-cols-3">
            <div>
              <p className="muted text-xs uppercase tracking-wide">Outstanding</p>
              <p className="mt-1 text-lg font-semibold text-slate-900">
                {currency(metrics.outstanding)}
              </p>
            </div>
            <div>
              <p className="muted text-xs uppercase tracking-wide">Overdue invoices</p>
              <p className="mt-1 text-lg font-semibold text-rose-600">{metrics.overdueInvoices}</p>
            </div>
            <div>
              <p className="muted text-xs uppercase tracking-wide">Staff on duty</p>
              <p className="mt-1 text-lg font-semibold text-slate-900">{metrics.staffOnDuty}</p>
            </div>
          </div>
        </div>

        <div className="card card-pad">
          <h2 className="section-title">Claims pipeline</h2>
          <p className="muted mt-1">{approvalRate}% approval rate across payers</p>
          <div className="mt-5">
            <DonutChart
              data={claimData.length ? claimData : [{ label: "No claims", value: 1 }]}
              centerLabel="claims tracked"
              centerValue={String(claimTotal)}
            />
          </div>
          <Link
            href="/claims"
            className="btn-secondary mt-5 w-full justify-center text-sm"
          >
            <ShieldCheck className="h-4 w-4" /> Open claims board
          </Link>
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-3">
        <div className="card overflow-hidden xl:col-span-2">
          <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
            <div>
              <h2 className="section-title">Today&apos;s schedule</h2>
              <p className="muted mt-0.5">
                {data.schedule.length} appointments across all departments
              </p>
            </div>
            <Link href="/appointments" className="btn-ghost btn-sm">
              View all
            </Link>
          </div>
          {data.schedule.length ? (
            <ul className="divide-y divide-slate-100">
              {data.schedule.map((visit) => (
                <li key={visit.id} className="flex items-center gap-4 px-5 py-3.5 transition-colors hover:bg-brand-50/40">
                  <span className="w-16 shrink-0 text-sm font-semibold text-slate-900">
                    {formatTime(visit.scheduledAt)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium text-slate-900">
                      {visit.patientName ?? "Unknown patient"}
                    </span>
                    <span className="block truncate text-xs text-slate-500">
                      {titleCase(visit.type)} · {visit.reason} · {visit.room}
                    </span>
                  </span>
                  <span className="hidden shrink-0 text-xs text-slate-500 sm:block">
                    {visit.staffName ?? "Unassigned"}
                  </span>
                  <StatusBadge status={visit.status} />
                </li>
              ))}
            </ul>
          ) : (
            <div className="px-5 py-12 text-center">
              <CalendarClock className="mx-auto h-8 w-8 text-slate-300" />
              <p className="mt-3 text-sm font-semibold text-slate-700">No visits booked today</p>
              <p className="mt-1 text-sm text-slate-500">The clinic calendar is clear.</p>
            </div>
          )}
        </div>

        <div className="card card-pad">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-500" />
            <h2 className="section-title">Pharmacy alerts</h2>
          </div>
          <p className="muted mt-1">Low stock or expiring within 120 days</p>
          <ul className="mt-4 space-y-3">
            {data.lowStock.length ? (
              data.lowStock.map((med) => {
                const critical = med.stock <= med.reorderLevel;
                return (
                  <li key={med.id} className="rounded-xl border border-slate-100 bg-slate-50/60 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-sm font-semibold text-slate-800">
                        {med.name} {med.strength}
                      </p>
                      <Tag tone={critical ? "red" : "amber"}>
                        {critical ? `${med.stock} left` : "expiring"}
                      </Tag>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">
                      {med.category} · reorder at {med.reorderLevel}
                    </p>
                  </li>
                );
              })
            ) : (
              <li className="rounded-xl bg-emerald-50 p-4 text-sm text-emerald-700 ring-1 ring-inset ring-emerald-100">
                Every item is above its reorder level. Nice work.
              </li>
            )}
          </ul>
          <Link href="/pharmacy" className="btn-secondary mt-4 w-full justify-center text-sm">
            <Pill className="h-4 w-4" /> Manage inventory
          </Link>
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-3">
        <div className="card card-pad xl:col-span-2">
          <div className="flex items-center justify-between gap-3">
            <h2 className="section-title">Live activity</h2>
            <Activity className="h-4 w-4 text-slate-400" />
          </div>
          <ol className="mt-4 space-y-4">
            {data.recentActivity.map((entry) => (
              <li key={entry.id} className="flex gap-3">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand-500 ring-4 ring-brand-100" />
                <div className="min-w-0">
                  <p className="text-sm text-slate-700">
                    <span className="font-semibold text-slate-900">{entry.actorName}</span>{" "}
                    {entry.action}{" "}
                    <span className="text-slate-400">({titleCase(entry.entity)})</span>
                  </p>
                  {entry.detail ? (
                    <p className="truncate text-xs text-slate-500">{entry.detail}</p>
                  ) : null}
                </div>
                <span className="ml-auto shrink-0 text-xs text-slate-400">
                  {relativeTime(entry.createdAt)}
                </span>
              </li>
            ))}
          </ol>
        </div>

        <div className="card card-pad">
          <div className="flex items-center gap-2">
            <Stethoscope className="h-4 w-4 text-slate-400" />
            <h2 className="section-title">Department workload</h2>
          </div>
          <p className="muted mt-1">Clinicians grouped by department</p>
          <div className="mt-4">
            <BarList
              data={data.departmentLoad.map((row) => ({
                label: row.department,
                value: row.total,
              }))}
            />
          </div>
        </div>
      </section>
    </div>
  );
}
