import type { ReactNode } from "react";

import { ensureSeeded } from "@/db/seed";
import { requireUser } from "@/lib/auth";
import AppShell from "@/components/AppShell";
import { ToastProvider } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const user = await requireUser();

  return (
    <ToastProvider>
      <AppShell
        user={{ name: user.name, email: user.email, role: user.role, department: user.department }}
      >
        {children}
      </AppShell>
    </ToastProvider>
  );
}
