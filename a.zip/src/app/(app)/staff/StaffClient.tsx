"use client";

import { useMemo, useState } from "react";
import { BriefcaseBusiness, Pencil, Plus, Star, Trash2, UserRoundPlus } from "lucide-react";

import { apiRequest } from "@/lib/client";
import { cn, formatDate, titleCase, toInputDate } from "@/lib/utils";
import type { StaffListRow } from "@/lib/queries";
import { Avatar, ConfirmDialog, EmptyState, StatusBadge, useToast } from "@/components/ui";
import { FormModal, PageHeader, StatCard, Toolbar } from "@/components/resource";

type FormState = {
  fullName: string;
  email: string;
  phone: string;
  title: string;
  department: string;
  specialty: string;
  licenseNumber: string;
  shift: string;
  status: string;
  rating: string;
  patientsAssigned: string;
  hireDate: string;
};

const STATUSES = ["on_duty", "available", "on_leave", "off_duty"];
const SHIFTS = ["Morning", "Evening", "Night", "Rotational"];
const TABS = ["all", "on_duty", "available", "on_leave", "off_duty"];

export default function StaffClient({ initialStaff }: { initialStaff: StaffListRow[] }) {
  const toast = useToast();
  const [rows, setRows] = useState(initialStaff);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<StaffListRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<StaffListRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState<FormState>({
    fullName: "",
    email: "",
    phone: "",
    title: "Clinician",
    department: "General Medicine",
    specialty: "General",
    licenseNumber: "",
    shift: "Morning",
    status: "available",
    rating: "4.50",
    patientsAssigned: "0",
    hireDate: toInputDate(new Date()),
  });

  const stats = useMemo(() => {
    const onDuty = rows.filter((row) => row.status === "on_duty").length;
    const load = rows.reduce((sum, row) => sum + row.patientsAssigned, 0);
    const rating =
      rows.length > 0
        ? rows.reduce((sum, row) => sum + Number(row.rating), 0) / rows.length
        : 0;
    const departments = new Set(rows.map((row) => row.department)).size;
    return { onDuty, load, rating, departments };
  }, [rows]);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (tab !== "all" && row.status !== tab) return false;
      if (!term) return true;
      return [row.fullName, row.title, row.department, row.specialty, row.licenseNumber]
        .join(" ")
        .toLowerCase()
        .includes(term);
    });
  }, [rows, query, tab]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: rows.length };
    for (const row of rows) map[row.status] = (map[row.status] ?? 0) + 1;
    return map;
  }, [rows]);

  function openCreate() {
    setEditing(null);
    setForm({
      fullName: "",
      email: "",
      phone: "",
      title: "Clinician",
      department: "General Medicine",
      specialty: "General",
      licenseNumber: "",
      shift: "Morning",
      status: "available",
      rating: "4.50",
      patientsAssigned: "0",
      hireDate: toInputDate(new Date()),
    });
    setOpen(true);
  }

  function openEdit(row: StaffListRow) {
    setEditing(row);
    setForm({
      fullName: row.fullName,
      email: row.email,
      phone: row.phone,
      title: row.title,
      department: row.department,
      specialty: row.specialty,
      licenseNumber: row.licenseNumber,
      shift: row.shift,
      status: row.status,
      rating: Number(row.rating).toFixed(2),
      patientsAssigned: String(row.patientsAssigned),
      hireDate: toInputDate(row.hireDate),
    });
    setOpen(true);
  }

  function buildOptimistic(id: string): StaffListRow {
    return {
      id,
      fullName: form.fullName,
      email: form.email,
      phone: form.phone,
      title: form.title,
      department: form.department,
      specialty: form.specialty,
      licenseNumber: form.licenseNumber,
      shift: form.shift,
      status: form.status,
      rating: form.rating,
      patientsAssigned: Number(form.patientsAssigned),
      hireDate: form.hireDate,
    };
  }

  async function submit() {
    setBusy(true);
    const payload = {
      ...form,
      patientsAssigned: Number(form.patientsAssigned),
      rating: Number(form.rating || 0).toFixed(2),
    };
    try {
      if (editing) {
        const previous = rows;
        setRows((current) =>
          current.map((row) => (row.id === editing.id ? buildOptimistic(row.id) : row)),
        );
        setOpen(false);
        try {
          await apiRequest(`/api/staff/${editing.id}`, { method: "PATCH", json: payload });
          toast.push({ title: "Team member updated", tone: "success" });
        } catch (error) {
          setRows(previous);
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      } else {
        const optimistic = buildOptimistic(`temp-${Date.now()}`);
        setRows((current) => [...current, optimistic]);
        setOpen(false);
        try {
          const created = await apiRequest<StaffListRow>("/api/staff", {
            method: "POST",
            json: payload,
          });
          setRows((current) => current.map((row) => (row.id === optimistic.id ? created : row)));
          toast.push({ title: `${created.fullName} joined the roster`, tone: "success" });
        } catch (error) {
          setRows((current) => current.filter((row) => row.id !== optimistic.id));
          toast.push({ title: (error as Error).message, tone: "error" });
        }
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== pendingDelete.id));
    try {
      await apiRequest(`/api/staff/${pendingDelete.id}`, { method: "DELETE" });
      toast.push({ title: "Team member removed", tone: "success" });
    } catch (error) {
      setRows(previous);
      toast.push({ title: (error as Error).message, tone: "error" });
    } finally {
      setDeleting(false);
      setPendingDelete(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Care team"
        subtitle="Clinician roster, departments, shifts and workload distribution."
      >
        <button type="button" className="btn-primary" onClick={openCreate}>
          <UserRoundPlus className="h-4 w-4" /> Add team member
        </button>
      </PageHeader>

      <section className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="On roster" value={rows.length} icon={<BriefcaseBusiness className="h-4 w-4" />} />
        <StatCard label="On duty now" value={stats.onDuty} icon={<Star className="h-4 w-4" />} tone="sky" />
        <StatCard label="Departments" value={stats.departments} icon={<BriefcaseBusiness className="h-4 w-4" />} tone="violet" />
        <StatCard
          label="Patients assigned"
          value={stats.load}
          footer={`avg rating ${stats.rating.toFixed(2)}`}
          icon={<Star className="h-4 w-4" />}
          tone="amber"
        />
      </section>

      <Toolbar
        search={query}
        onSearch={setQuery}
        placeholder="Search name, specialty, department or licence…"
        tabs={TABS.map((value) => ({
          value,
          label: value === "all" ? "Everyone" : titleCase(value),
          count: counts[value] ?? 0,
        }))}
        activeTab={tab}
        onTab={setTab}
        resultCount={filtered.length}
      />

      <div className="card overflow-hidden">
        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="table-shell">
              <thead>
                <tr>
                  <th>Member</th>
                  <th>Department</th>
                  <th>Shift</th>
                  <th>Load</th>
                  <th>Rating</th>
                  <th>Since</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.id} className={cn(row.id.startsWith("temp-") && "opacity-60")}>
                    <td>
                      <Avatar name={row.fullName} subtitle={`${row.title} · ${row.specialty}`} />
                    </td>
                    <td className="text-sm text-slate-600">{row.department}</td>
                    <td className="text-sm text-slate-600">{row.shift}</td>
                    <td className="text-sm font-semibold text-slate-800">
                      {row.patientsAssigned}
                      <span className="block text-xs font-normal text-slate-400">patients</span>
                    </td>
                    <td className="text-sm text-slate-700">
                      <span className="flex items-center gap-1">
                        <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                        {Number(row.rating).toFixed(1)}
                      </span>
                    </td>
                    <td className="text-sm text-slate-600">{formatDate(row.hireDate)}</td>
                    <td>
                      <StatusBadge status={row.status} />
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2"
                          onClick={() => openEdit(row)}
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          className="btn-ghost rounded-lg p-2 text-rose-500 hover:bg-rose-50"
                          onClick={() => setPendingDelete(row)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={<BriefcaseBusiness className="h-6 w-6" />}
            title="No team members in this view"
            description="Add clinicians, nurses and pharmacists to build the roster."
            action={
              <button type="button" className="btn-primary" onClick={openCreate}>
                <Plus className="h-4 w-4" /> Add team member
              </button>
            }
          />
        )}
      </div>

      <FormModal
        open={open}
        mode={editing ? "edit" : "create"}
        title={editing ? `Edit ${editing.fullName}` : "Add team member"}
        description="Role, department, shift and workload details."
        onClose={() => setOpen(false)}
        onSubmit={submit}
        busy={busy}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="label">Full name *</span>
            <input
              required
              className="input"
              value={form.fullName}
              onChange={(event) => setForm({ ...form, fullName: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Job title</span>
            <input
              className="input"
              value={form.title}
              onChange={(event) => setForm({ ...form, title: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Email</span>
            <input
              type="email"
              className="input"
              value={form.email}
              onChange={(event) => setForm({ ...form, email: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Phone</span>
            <input
              className="input"
              value={form.phone}
              onChange={(event) => setForm({ ...form, phone: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Department</span>
            <input
              className="input"
              value={form.department}
              onChange={(event) => setForm({ ...form, department: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Specialty</span>
            <input
              className="input"
              value={form.specialty}
              onChange={(event) => setForm({ ...form, specialty: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Licence number</span>
            <input
              className="input"
              value={form.licenseNumber}
              onChange={(event) => setForm({ ...form, licenseNumber: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Shift</span>
            <select
              className="input"
              value={form.shift}
              onChange={(event) => setForm({ ...form, shift: event.target.value })}
            >
              {SHIFTS.map((shift) => (
                <option key={shift} value={shift}>
                  {shift}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Status</span>
            <select
              className="input"
              value={form.status}
              onChange={(event) => setForm({ ...form, status: event.target.value })}
            >
              {STATUSES.map((status) => (
                <option key={status} value={status}>
                  {titleCase(status)}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Hire date</span>
            <input
              type="date"
              className="input"
              value={form.hireDate}
              onChange={(event) => setForm({ ...form, hireDate: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Patients assigned</span>
            <input
              type="number"
              min={0}
              className="input"
              value={form.patientsAssigned}
              onChange={(event) => setForm({ ...form, patientsAssigned: event.target.value })}
            />
          </label>
          <label className="block">
            <span className="label">Rating</span>
            <input
              type="number"
              min={0}
              max={5}
              step="0.1"
              className="input"
              value={form.rating}
              onChange={(event) => setForm({ ...form, rating: event.target.value })}
            />
          </label>
        </div>
      </FormModal>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Remove team member"
        message={`Remove ${pendingDelete?.fullName} from the care team roster?`}
        busy={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
