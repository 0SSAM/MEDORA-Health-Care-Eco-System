import { Stethoscope } from "lucide-react";

import { listStaff } from "@/lib/queries";
import StaffClient from "./StaffClient";

export const dynamic = "force-dynamic";

export default async function StaffPage() {
  const staff = await listStaff();

  if (!staff.length) {
    return (
      <div className="card mt-10">
        <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-sky-50 text-sky-600">
            <Stethoscope className="h-6 w-6" />
          </span>
          <p className="text-lg font-semibold text-slate-900">No clinicians on roster</p>
          <p className="max-w-sm text-sm text-slate-500">
            Add your first team member to start assigning care responsibility.
          </p>
        </div>
      </div>
    );
  }

  return <StaffClient initialStaff={staff} />;
}
