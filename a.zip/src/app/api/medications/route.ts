import { createCollectionRoute } from "@/lib/crud";
import { medicationResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createCollectionRoute(medicationResource);

export const GET = handlers.GET;
export const POST = handlers.POST;
