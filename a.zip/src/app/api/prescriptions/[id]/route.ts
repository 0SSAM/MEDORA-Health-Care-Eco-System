import { createItemRoute } from "@/lib/crud";
import { prescriptionResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createItemRoute(prescriptionResource);

export const GET = handlers.GET;
export const PATCH = handlers.PATCH;
export const DELETE = handlers.DELETE;
