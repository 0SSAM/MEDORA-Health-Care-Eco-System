import { createCollectionRoute } from "@/lib/crud";
import { prescriptionResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createCollectionRoute(prescriptionResource);

export const GET = handlers.GET;
export const POST = handlers.POST;
