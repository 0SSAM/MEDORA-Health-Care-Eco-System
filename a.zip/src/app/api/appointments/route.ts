import { createCollectionRoute } from "@/lib/crud";
import { appointmentResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createCollectionRoute(appointmentResource);

export const GET = handlers.GET;
export const POST = handlers.POST;
