import { createItemRoute } from "@/lib/crud";
import { invoiceResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createItemRoute(invoiceResource);

export const GET = handlers.GET;
export const PATCH = handlers.PATCH;
export const DELETE = handlers.DELETE;
