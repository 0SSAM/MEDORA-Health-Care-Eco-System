import { createCollectionRoute } from "@/lib/crud";
import { staffResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createCollectionRoute(staffResource);

export const GET = handlers.GET;
export const POST = handlers.POST;
