import { sql } from "drizzle-orm";

import { db } from "@/db";
import {
  activityLog,
  appointments,
  insuranceClaims,
  invoices,
  medications,
  patients,
  prescriptions,
  staff,
  users,
} from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { seedDatabase } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { searchParams } = new URL(request.url);
  if (searchParams.get("reset") !== "1") {
    return Response.json({ error: "Pass ?reset=1 to reseed" }, { status: 400 });
  }

  await db.execute(
    sql`truncate table ${activityLog}, ${appointments}, ${prescriptions}, ${insuranceClaims}, ${invoices}, ${medications}, ${patients}, ${staff}, ${users}`,
  );
  const summary = await seedDatabase();
  return Response.json({ data: summary });
}
