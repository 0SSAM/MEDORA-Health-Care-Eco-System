import { createCollectionRoute } from "@/lib/crud";
import { patientResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createCollectionRoute(patientResource);

export const GET = handlers.GET;
export const POST = handlers.POST;
