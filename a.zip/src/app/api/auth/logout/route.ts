import { endSession, getCurrentUser, logActivity } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST() {
  const user = await getCurrentUser();
  if (user) {
    await logActivity({
      actorName: user.name,
      action: "signed out",
      entity: "session",
      detail: user.email,
    });
  }
  await endSession();
  return Response.json({ ok: true });
}
