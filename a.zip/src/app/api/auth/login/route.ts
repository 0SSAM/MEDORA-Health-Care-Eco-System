import { NextResponse } from "next/server";

import { authenticate, logActivity, startSession } from "@/lib/auth";
import { ensureSeeded } from "@/db/seed";
import { loginSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  await ensureSeeded();
  const body = await request.json().catch(() => null);
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Email and password are required" }, { status: 400 });
  }

  const user = await authenticate(parsed.data.email, parsed.data.password);
  if (!user) {
    return NextResponse.json(
      { error: "Those credentials don't match our records." },
      { status: 401 },
    );
  }

  await startSession(user.id);
  await logActivity({
    actorName: user.name,
    action: "signed in",
    entity: "session",
    detail: user.email,
  });

  return NextResponse.json({ data: user });
}
