import { createItemRoute } from "@/lib/crud";
import { claimResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createItemRoute(claimResource);

export const GET = handlers.GET;
export const PATCH = handlers.PATCH;
export const DELETE = handlers.DELETE;
