import { count, eq } from "drizzle-orm";

import { db } from "@/db";
import { users } from "@/db/schema";
import { createItemRoute, jsonError } from "@/lib/crud";
import { getCurrentUser } from "@/lib/auth";
import { userResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createItemRoute(userResource);

export const GET = handlers.GET;

export async function PATCH(
  request: Parameters<typeof handlers.PATCH>[0],
  context: Parameters<typeof handlers.PATCH>[1],
) {
  return handlers.PATCH(request, context);
}

export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const user = await getCurrentUser();
  if (!user) return jsonError("Unauthorized", 401);
  const { id } = await context.params;
  if (id === user.id) return jsonError("You cannot remove your own account", 400);

  const [target] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!target) return jsonError("Not found", 404);
  if (target.role === "admin") {
    const [adminCount] = await db
      .select({ total: count() })
      .from(users)
      .where(eq(users.role, "admin"));
    if ((adminCount?.total ?? 0) <= 1) {
      return jsonError("At least one administrator must remain", 400);
    }
  }

  return handlers.DELETE(_request as never, context);
}
