import { createCollectionRoute } from "@/lib/crud";
import { userResource } from "@/lib/resources";

export const dynamic = "force-dynamic";

const handlers = createCollectionRoute(userResource);

export const GET = handlers.GET;
export const POST = handlers.POST;
