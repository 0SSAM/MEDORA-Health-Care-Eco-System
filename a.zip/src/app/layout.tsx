import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "MEDORA · Healthcare Ecosystem",
  description:
    "MEDORA is an integrated healthcare operating platform — CRM, HR, pharmacy, billing and insurance in one clinical workspace.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        {children}
      </body>
    </html>
  );
}
