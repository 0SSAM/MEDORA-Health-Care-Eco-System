"use client";

import { Loader2, Search, X } from "lucide-react";
import type { ReactNode } from "react";

import { cn } from "@/lib/utils";

export function PageHeader({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900 sm:text-[1.7rem]">
          {title}
        </h1>
        {subtitle ? <p className="mt-1 text-sm text-slate-500">{subtitle}</p> : null}
      </div>
      {children ? <div className="flex flex-wrap items-center gap-2">{children}</div> : null}
    </div>
  );
}

export function Toolbar({
  search,
  onSearch,
  placeholder = "Search…",
  tabs,
  activeTab,
  onTab,
  right,
  resultCount,
}: {
  search: string;
  onSearch: (value: string) => void;
  placeholder?: string;
  tabs?: Array<{ value: string; label: string; count?: number }>;
  activeTab?: string;
  onTab?: (value: string) => void;
  right?: ReactNode;
  resultCount?: number;
}) {
  return (
    <div className="mb-4 space-y-3">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex flex-1 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm focus-within:border-brand-400 focus-within:ring-4 focus-within:ring-brand-500/10">
          <Search className="h-4 w-4 shrink-0 text-slate-400" />
          <input
            value={search}
            onChange={(event) => onSearch(event.target.value)}
            placeholder={placeholder}
            className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
          />
          {search ? (
            <button type="button" onClick={() => onSearch("")} className="text-slate-400 hover:text-slate-600">
              <X className="h-4 w-4" />
            </button>
          ) : null}
        </div>
        {right}
      </div>

      {tabs?.length ? (
        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
          {tabs.map((tab) => {
            const active = activeTab === tab.value;
            return (
              <button
                key={tab.value}
                type="button"
                onClick={() => onTab?.(tab.value)}
                className={cn(
                  "btn btn-sm whitespace-nowrap rounded-lg border",
                  active
                    ? "border-brand-200 bg-brand-50 text-brand-700"
                    : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50",
                )}
              >
                {tab.label}
                {typeof tab.count === "number" ? (
                  <span
                    className={cn(
                      "ml-1 rounded-md px-1.5 py-0.5 text-[10px] font-bold",
                      active ? "bg-brand-600 text-white" : "bg-slate-100 text-slate-500",
                    )}
                  >
                    {tab.count}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>
      ) : null}

      {typeof resultCount === "number" ? (
        <p className="text-xs text-slate-400">
          Showing {resultCount} {resultCount === 1 ? "record" : "records"}
        </p>
      ) : null}
    </div>
  );
}

export function FormModal({
  open,
  mode,
  title,
  description,
  onClose,
  onSubmit,
  busy,
  children,
  submitLabel,
  size = "md",
}: {
  open: boolean;
  mode: "create" | "edit";
  title: string;
  description?: string;
  onClose: () => void;
  onSubmit: () => void;
  busy: boolean;
  children: ReactNode;
  submitLabel?: string;
  size?: "md" | "lg";
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/45 backdrop-blur-sm sm:items-center sm:p-6">
      <button
        type="button"
        aria-label="Close"
        className="absolute inset-0 h-full w-full cursor-default"
        onClick={onClose}
      />
      <form
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit();
        }}
        className={cn(
          "animate-pop relative z-10 flex max-h-[94vh] w-full flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl sm:rounded-3xl",
          size === "lg" ? "sm:max-w-3xl" : "sm:max-w-xl",
        )}
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">{title}</h2>
            {description ? <p className="mt-0.5 text-sm text-slate-500">{description}</p> : null}
          </div>
          <button type="button" onClick={onClose} className="btn-ghost -mr-2 rounded-lg p-1.5">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-5">{children}</div>
        <div className="flex items-center justify-end gap-2 border-t border-slate-100 bg-slate-50/70 px-6 py-4">
          <button type="button" className="btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn-primary" disabled={busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {mode === "create" ? (submitLabel ?? "Create") : "Save changes"}
          </button>
        </div>
      </form>
    </div>
  );
}

export function StatCard({
  label,
  value,
  delta,
  icon,
  tone = "brand",
  footer,
}: {
  label: string;
  value: string | number;
  delta?: string;
  icon: ReactNode;
  tone?: "brand" | "sky" | "amber" | "rose" | "violet";
  footer?: string;
}) {
  const tones: Record<string, string> = {
    brand: "from-brand-500/15 to-brand-500/5 text-brand-700",
    sky: "from-sky-500/15 to-sky-500/5 text-sky-700",
    amber: "from-amber-500/15 to-amber-500/5 text-amber-700",
    rose: "from-rose-500/15 to-rose-500/5 text-rose-700",
    violet: "from-violet-500/15 to-violet-500/5 text-violet-700",
  };
  return (
    <div className="card card-pad animate-fade-up">
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</p>
        <span
          className={cn(
            "grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br ring-1 ring-inset ring-white/60",
            tones[tone],
          )}
        >
          {icon}
        </span>
      </div>
      <p className="mt-3 text-3xl font-semibold tracking-tight text-slate-900">{value}</p>
      <div className="mt-1 flex items-center gap-2">
        {delta ? (
          <span className="text-xs font-semibold text-brand-600">{delta}</span>
        ) : null}
        {footer ? <span className="text-xs text-slate-400">{footer}</span> : null}
      </div>
    </div>
  );
}
