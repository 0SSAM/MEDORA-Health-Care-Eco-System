import { compactCurrency } from "@/lib/utils";

export function TrendChart({
  data,
  height = 180,
}: {
  data: Array<{ day: string; total: number }>;
  height?: number;
}) {
  if (!data.length) {
    return (
      <div className="grid h-44 place-items-center text-sm text-slate-400">
        No billing activity recorded yet
      </div>
    );
  }

  const width = 640;
  const padding = { top: 12, right: 8, bottom: 22, left: 8 };
  const max = Math.max(...data.map((d) => d.total), 1);
  const stepX = (width - padding.left - padding.right) / Math.max(data.length - 1, 1);
  const scaleY = (value: number) =>
    height - padding.bottom - (value / max) * (height - padding.top - padding.bottom);

  const points = data.map((point, index) => ({
    x: padding.left + index * stepX,
    y: scaleY(point.total),
    ...point,
  }));

  const line = points
    .map((point, index) => `${index === 0 ? "M" : "L"}${point.x.toFixed(1)},${point.y.toFixed(1)}`)
    .join(" ");
  const area = `${line} L${points[points.length - 1].x.toFixed(1)},${height - padding.bottom} L${points[0].x.toFixed(1)},${height - padding.bottom} Z`;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="h-44 w-full" role="img" aria-label="Revenue trend">
      <defs>
        <linearGradient id="revenue-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#10b981" stopOpacity="0.28" />
          <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0.25, 0.5, 0.75, 1].map((ratio) => (
        <line
          key={ratio}
          x1={padding.left}
          x2={width - padding.right}
          y1={scaleY(max * ratio)}
          y2={scaleY(max * ratio)}
          stroke="#e2e8f0"
          strokeDasharray="4 6"
          strokeWidth="1"
        />
      ))}
      <path d={area} fill="url(#revenue-fill)" />
      <path d={line} fill="none" stroke="#059666" strokeWidth="2.5" strokeLinecap="round" />
      {points.map((point) => (
        <g key={point.day}>
          <circle cx={point.x} cy={point.y} r="3.5" fill="#fff" stroke="#059666" strokeWidth="2" />
          <title>{`${point.day}: ${compactCurrency(point.total)}`}</title>
        </g>
      ))}
    </svg>
  );
}

const DONUT_COLORS = ["#10b981", "#0ea5e9", "#f59e0b", "#ef4444", "#8b5cf6", "#64748b"];

export function DonutChart({
  data,
  centerLabel,
  centerValue,
}: {
  data: Array<{ label: string; value: number }>;
  centerLabel?: string;
  centerValue?: string;
}) {
  const total = data.reduce((sum, item) => sum + item.value, 0);
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  let offset = 0;

  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center sm:gap-6">
      <svg viewBox="0 0 140 140" className="h-36 w-36 shrink-0 -rotate-90" role="img" aria-label="Distribution">
        <circle cx="70" cy="70" r={radius} fill="none" stroke="#f1f5f9" strokeWidth="16" />
        {total > 0 &&
          data.map((item, index) => {
            const fraction = item.value / total;
            const dash = fraction * circumference;
            const element = (
              <circle
                key={item.label}
                cx="70"
                cy="70"
                r={radius}
                fill="none"
                stroke={DONUT_COLORS[index % DONUT_COLORS.length]}
                strokeWidth="16"
                strokeDasharray={`${dash} ${circumference - dash}`}
                strokeDashoffset={-offset}
                strokeLinecap="butt"
              />
            );
            offset += dash;
            return element;
          })}
      </svg>
      <div className="w-full space-y-2">
        {centerValue ? (
          <div className="mb-3">
            <p className="text-2xl font-semibold tracking-tight text-slate-900">{centerValue}</p>
            <p className="text-xs uppercase tracking-wide text-slate-400">{centerLabel}</p>
          </div>
        ) : null}
        <ul className="space-y-1.5">
          {data.map((item, index) => (
            <li key={item.label} className="flex items-center justify-between gap-3 text-sm">
              <span className="flex items-center gap-2 text-slate-600">
                <span
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ background: DONUT_COLORS[index % DONUT_COLORS.length] }}
                />
                {item.label}
              </span>
              <span className="font-semibold text-slate-900">
                {item.value}
                <span className="ml-1 text-xs font-normal text-slate-400">
                  {total ? `${Math.round((item.value / total) * 100)}%` : "0%"}
                </span>
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function BarList({
  data,
}: {
  data: Array<{ label: string; value: number }>;
}) {
  const max = Math.max(...data.map((item) => item.value), 1);
  return (
    <ul className="space-y-3">
      {data.map((item) => (
        <li key={item.label} className="space-y-1.5">
          <div className="flex items-center justify-between text-sm">
            <span className="truncate font-medium text-slate-700">{item.label}</span>
            <span className="text-xs font-semibold text-slate-500">{item.value}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-slate-100">
            <div
              className="h-full rounded-full bg-gradient-to-r from-brand-400 to-brand-600 transition-all duration-500"
              style={{ width: `${Math.max(6, (item.value / max) * 100)}%` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}
