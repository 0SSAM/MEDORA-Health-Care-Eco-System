export type ApiResult<T> = { data: T };

export async function apiRequest<T>(
  url: string,
  init?: RequestInit & { json?: unknown },
): Promise<T> {
  const { json, headers, ...rest } = init ?? {};
  const response = await fetch(url, {
    ...rest,
    headers: {
      ...(json !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(headers ?? {}),
    },
    body: json !== undefined ? JSON.stringify(json) : rest.body,
  });

  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const message =
      (payload && typeof payload === "object" && "error" in payload
        ? String((payload as { error: unknown }).error)
        : null) ?? `Request failed (${response.status})`;
    throw new Error(message);
  }
  return (payload as ApiResult<T>).data;
}

export function sortByName<T extends { name?: string; fullName?: string; label?: string }>(rows: T[]) {
  return [...rows].sort((a, b) => {
    const left = a.name ?? a.fullName ?? a.label ?? "";
    const right = b.name ?? b.fullName ?? b.label ?? "";
    return left.localeCompare(right);
  });
}
