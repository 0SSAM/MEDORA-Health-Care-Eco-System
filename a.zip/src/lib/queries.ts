import "server-only";

import { and, count, desc, eq, gte, ilike, lt, or, sql } from "drizzle-orm";
import type { SQL } from "drizzle-orm";

import { db } from "@/db";
import {
  activityLog,
  appointments,
  insuranceClaims,
  invoices,
  medications,
  patients,
  prescriptions,
  staff,
  users,
} from "@/db/schema";

export type Option = { id: string; label: string; hint?: string };

export async function getStaffOptions(): Promise<Option[]> {
  const rows = await db
    .select({ id: staff.id, fullName: staff.fullName, title: staff.title })
    .from(staff)
    .orderBy(staff.fullName);
  return rows.map((row) => ({ id: row.id, label: row.fullName, hint: row.title }));
}

export async function getPatientOptions(): Promise<Option[]> {
  const rows = await db
    .select({
      id: patients.id,
      firstName: patients.firstName,
      lastName: patients.lastName,
      mrn: patients.mrn,
    })
    .from(patients)
    .orderBy(patients.firstName);
  return rows.map((row) => ({
    id: row.id,
    label: `${row.firstName} ${row.lastName}`,
    hint: row.mrn,
  }));
}

export async function getMedicationOptions(): Promise<Option[]> {
  const rows = await db
    .select({ id: medications.id, name: medications.name, strength: medications.strength })
    .from(medications)
    .orderBy(medications.name);
  return rows.map((row) => ({ id: row.id, label: row.name, hint: row.strength }));
}

const patientName = sql<string>`concat(${patients.firstName}, ' ', ${patients.lastName})`;

export type PatientListRow = {
  id: string;
  mrn: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  gender: string;
  dateOfBirth: string;
  bloodType: string;
  city: string;
  address: string;
  insuranceProvider: string;
  insuranceNumber: string;
  allergies: string;
  conditions: string;
  status: string;
  riskLevel: string;
  notes: string;
  primaryStaffId: string | null;
  primaryStaffName: string | null;
  createdAt: Date;
};

export async function listPatients(): Promise<PatientListRow[]> {
  const rows = await db
    .select({
      id: patients.id,
      mrn: patients.mrn,
      firstName: patients.firstName,
      lastName: patients.lastName,
      email: patients.email,
      phone: patients.phone,
      gender: patients.gender,
      dateOfBirth: patients.dateOfBirth,
      bloodType: patients.bloodType,
      city: patients.city,
      address: patients.address,
      insuranceProvider: patients.insuranceProvider,
      insuranceNumber: patients.insuranceNumber,
      allergies: patients.allergies,
      conditions: patients.conditions,
      status: patients.status,
      riskLevel: patients.riskLevel,
      notes: patients.notes,
      primaryStaffId: patients.primaryStaffId,
      primaryStaffName: staff.fullName,
      createdAt: patients.createdAt,
    })
    .from(patients)
    .leftJoin(staff, eq(staff.id, patients.primaryStaffId))
    .orderBy(desc(patients.createdAt))
    .limit(400);
  return rows;
}

export async function getPatientDetail(id: string) {
  const [patient] = await db
    .select({
      patient: patients,
      primaryStaffName: staff.fullName,
      primaryStaffTitle: staff.title,
    })
    .from(patients)
    .leftJoin(staff, eq(staff.id, patients.primaryStaffId))
    .where(eq(patients.id, id))
    .limit(1);
  if (!patient) return null;

  const [visitList, scriptList, billList, claimList] = await Promise.all([
    db
      .select({
        appointment: appointments,
        staffName: staff.fullName,
      })
      .from(appointments)
      .leftJoin(staff, eq(staff.id, appointments.staffId))
      .where(eq(appointments.patientId, id))
      .orderBy(desc(appointments.scheduledAt))
      .limit(20),
    db
      .select({ prescription: prescriptions, medicationName: medications.name })
      .from(prescriptions)
      .leftJoin(medications, eq(medications.id, prescriptions.medicationId))
      .where(eq(prescriptions.patientId, id))
      .orderBy(desc(prescriptions.issuedAt))
      .limit(20),
    db
      .select()
      .from(invoices)
      .where(eq(invoices.patientId, id))
      .orderBy(desc(invoices.issuedAt))
      .limit(20),
    db
      .select()
      .from(insuranceClaims)
      .where(eq(insuranceClaims.patientId, id))
      .orderBy(desc(insuranceClaims.submittedAt))
      .limit(20),
  ]);

  return {
    ...patient.patient,
    primaryStaffName: patient.primaryStaffName,
    primaryStaffTitle: patient.primaryStaffTitle,
    appointments: visitList,
    prescriptions: scriptList,
    invoices: billList,
    claims: claimList,
  };
}

export type AppointmentListRow = {
  id: string;
  patientId: string;
  patientName: string;
  patientMrn: string | null;
  staffId: string | null;
  staffName: string | null;
  scheduledAt: Date;
  durationMinutes: number;
  type: string;
  status: string;
  reason: string;
  room: string;
  notes: string;
};

export async function listAppointments(): Promise<AppointmentListRow[]> {
  return db
    .select({
      id: appointments.id,
      patientId: appointments.patientId,
      patientName,
      patientMrn: patients.mrn,
      staffId: appointments.staffId,
      staffName: staff.fullName,
      scheduledAt: appointments.scheduledAt,
      durationMinutes: appointments.durationMinutes,
      type: appointments.type,
      status: appointments.status,
      reason: appointments.reason,
      room: appointments.room,
      notes: appointments.notes,
    })
    .from(appointments)
    .leftJoin(patients, eq(patients.id, appointments.patientId))
    .leftJoin(staff, eq(staff.id, appointments.staffId))
    .orderBy(desc(appointments.scheduledAt))
    .limit(400);
}

export type StaffListRow = {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  title: string;
  department: string;
  specialty: string;
  licenseNumber: string;
  shift: string;
  status: string;
  rating: string;
  patientsAssigned: number;
  hireDate: string;
};

export async function listStaff(): Promise<StaffListRow[]> {
  return db.select().from(staff).orderBy(staff.fullName).limit(300);
}

export type MedicationListRow = {
  id: string;
  name: string;
  category: string;
  form: string;
  strength: string;
  manufacturer: string;
  batchNumber: string;
  supplier: string;
  stock: number;
  reorderLevel: number;
  unitPrice: string;
  expiryDate: string;
};

export async function listMedications(): Promise<MedicationListRow[]> {
  return db.select().from(medications).orderBy(medications.name).limit(300);
}

export type PrescriptionListRow = {
  id: string;
  patientId: string;
  patientName: string;
  staffId: string | null;
  staffName: string | null;
  medicationId: string | null;
  medicationName: string | null;
  medicationStrength: string | null;
  dosage: string;
  frequency: string;
  durationDays: number;
  refills: number;
  status: string;
  issuedAt: Date;
  notes: string;
};

export async function listPrescriptions(): Promise<PrescriptionListRow[]> {
  return db
    .select({
      id: prescriptions.id,
      patientId: prescriptions.patientId,
      patientName,
      staffId: prescriptions.staffId,
      staffName: staff.fullName,
      medicationId: prescriptions.medicationId,
      medicationName: medications.name,
      medicationStrength: medications.strength,
      dosage: prescriptions.dosage,
      frequency: prescriptions.frequency,
      durationDays: prescriptions.durationDays,
      refills: prescriptions.refills,
      status: prescriptions.status,
      issuedAt: prescriptions.issuedAt,
      notes: prescriptions.notes,
    })
    .from(prescriptions)
    .leftJoin(patients, eq(patients.id, prescriptions.patientId))
    .leftJoin(staff, eq(staff.id, prescriptions.staffId))
    .leftJoin(medications, eq(medications.id, prescriptions.medicationId))
    .orderBy(desc(prescriptions.issuedAt))
    .limit(400);
}

export type InvoiceListRow = {
  id: string;
  invoiceNumber: string;
  patientId: string;
  patientName: string;
  amount: string;
  insuranceCovered: string;
  status: string;
  itemsSummary: string;
  paymentMethod: string;
  issuedAt: Date;
  dueDate: string;
  paidAt: Date | null;
};

export async function listInvoices(): Promise<InvoiceListRow[]> {
  return db
    .select({
      id: invoices.id,
      invoiceNumber: invoices.invoiceNumber,
      patientId: invoices.patientId,
      patientName,
      amount: invoices.amount,
      insuranceCovered: invoices.insuranceCovered,
      status: invoices.status,
      itemsSummary: invoices.itemsSummary,
      paymentMethod: invoices.paymentMethod,
      issuedAt: invoices.issuedAt,
      dueDate: invoices.dueDate,
      paidAt: invoices.paidAt,
    })
    .from(invoices)
    .leftJoin(patients, eq(patients.id, invoices.patientId))
    .orderBy(desc(invoices.issuedAt))
    .limit(400);
}

export type ClaimListRow = {
  id: string;
  claimNumber: string;
  patientId: string;
  patientName: string;
  provider: string;
  amount: string;
  approvedAmount: string;
  status: string;
  submittedAt: Date;
  decidedAt: Date | null;
  notes: string;
};

export async function listClaims(): Promise<ClaimListRow[]> {
  return db
    .select({
      id: insuranceClaims.id,
      claimNumber: insuranceClaims.claimNumber,
      patientId: insuranceClaims.patientId,
      patientName,
      provider: insuranceClaims.provider,
      amount: insuranceClaims.amount,
      approvedAmount: insuranceClaims.approvedAmount,
      status: insuranceClaims.status,
      submittedAt: insuranceClaims.submittedAt,
      decidedAt: insuranceClaims.decidedAt,
      notes: insuranceClaims.notes,
    })
    .from(insuranceClaims)
    .leftJoin(patients, eq(patients.id, insuranceClaims.patientId))
    .orderBy(desc(insuranceClaims.submittedAt))
    .limit(400);
}

export type TeamRow = {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  phone: string;
  isActive: boolean;
  lastLoginAt: Date | null;
  createdAt: Date;
};

export async function listTeam(): Promise<TeamRow[]> {
  return db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      role: users.role,
      department: users.department,
      phone: users.phone,
      isActive: users.isActive,
      lastLoginAt: users.lastLoginAt,
      createdAt: users.createdAt,
    })
    .from(users)
    .orderBy(users.name)
    .limit(200);
}

export async function listActivity(limit = 12) {
  return db
    .select()
    .from(activityLog)
    .orderBy(desc(activityLog.createdAt))
    .limit(limit);
}

function startOfToday() {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return date;
}

function addDays(date: Date, days: number) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

export async function getDashboardData() {
  const today = startOfToday();
  const tomorrow = addDays(today, 1);
  const weekAhead = addDays(today, 7);
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
  const revenueFrom = addDays(today, -13);

  const [
    patientCounts,
    todayAppointments,
    upcoming,
    staffOnDuty,
    prescriptionCounts,
    revenue,
    outstanding,
    claimSummary,
    lowStock,
    schedule,
    recentActivity,
    revenueTrend,
    departmentLoad,
  ] = await Promise.all([
    db
      .select({
        total: count(),
        critical: sql<number>`sum(case when ${patients.status} = 'critical' then 1 else 0 end)::int`,
        newThisMonth: sql<number>`sum(case when ${patients.createdAt} >= ${monthStart.toISOString()} then 1 else 0 end)::int`,
      })
      .from(patients),
    db
      .select({ total: count() })
      .from(appointments)
      .where(
        and(gte(appointments.scheduledAt, today), lt(appointments.scheduledAt, tomorrow)),
      ),
    db
      .select({ total: count() })
      .from(appointments)
      .where(
        and(
          gte(appointments.scheduledAt, tomorrow),
          lt(appointments.scheduledAt, weekAhead),
        ),
      ),
    db
      .select({ total: count() })
      .from(staff)
      .where(eq(staff.status, "on_duty")),
    db
      .select({
        pending: sql<number>`sum(case when ${prescriptions.status} = 'pending' then 1 else 0 end)::int`,
        active: sql<number>`sum(case when ${prescriptions.status} = 'active' then 1 else 0 end)::int`,
      })
      .from(prescriptions),
    db
      .select({
        collected: sql<number>`coalesce(sum(case when ${invoices.status} = 'paid' then ${invoices.amount} else 0 end), 0)::float`,
        monthCollected: sql<number>`coalesce(sum(case when ${invoices.status} = 'paid' and ${invoices.issuedAt} >= ${monthStart.toISOString()} then ${invoices.amount} else 0 end), 0)::float`,
      })
      .from(invoices),
    db
      .select({
        open: sql<number>`coalesce(sum(case when ${invoices.status} in ('pending','overdue') then ${invoices.amount} else 0 end), 0)::float`,
        overdueCount: sql<number>`sum(case when ${invoices.status} = 'overdue' then 1 else 0 end)::int`,
      })
      .from(invoices),
    db
      .select({
        status: insuranceClaims.status,
        total: count(),
        amount: sql<number>`coalesce(sum(${insuranceClaims.amount}), 0)::float`,
      })
      .from(insuranceClaims)
      .groupBy(insuranceClaims.status),
    db
      .select()
      .from(medications)
      .where(or(sql`${medications.stock} <= ${medications.reorderLevel}`, lt(medications.expiryDate, sql`now() + interval '120 days'`)))
      .orderBy(medications.stock)
      .limit(6),
    db
      .select({
        id: appointments.id,
        scheduledAt: appointments.scheduledAt,
        status: appointments.status,
        type: appointments.type,
        reason: appointments.reason,
        room: appointments.room,
        patientName,
        staffName: staff.fullName,
      })
      .from(appointments)
      .leftJoin(patients, eq(patients.id, appointments.patientId))
      .leftJoin(staff, eq(staff.id, appointments.staffId))
      .where(and(gte(appointments.scheduledAt, today), lt(appointments.scheduledAt, tomorrow)))
      .orderBy(appointments.scheduledAt)
      .limit(8),
    listActivity(8),
    db
      .select({
        day: sql<string>`to_char(date_trunc('day', ${invoices.issuedAt}), 'YYYY-MM-DD')`,
        total: sql<number>`coalesce(sum(${invoices.amount}), 0)::float`,
      })
      .from(invoices)
      .where(gte(invoices.issuedAt, revenueFrom))
      .groupBy(sql`date_trunc('day', ${invoices.issuedAt})`)
      .orderBy(sql`date_trunc('day', ${invoices.issuedAt})`),
    db
      .select({ department: staff.department, total: count() })
      .from(staff)
      .groupBy(staff.department)
      .orderBy(desc(count()))
      .limit(6),
  ]);

  const appointmentStatusRows = await db
    .select({ status: appointments.status, total: count() })
    .from(appointments)
    .groupBy(appointments.status);

  return {
    metrics: {
      totalPatients: patientCounts[0]?.total ?? 0,
      criticalPatients: patientCounts[0]?.critical ?? 0,
      newPatients: patientCounts[0]?.newThisMonth ?? 0,
      todayAppointments: todayAppointments[0]?.total ?? 0,
      upcomingAppointments: upcoming[0]?.total ?? 0,
      staffOnDuty: staffOnDuty[0]?.total ?? 0,
      pendingPrescriptions: prescriptionCounts[0]?.pending ?? 0,
      activePrescriptions: prescriptionCounts[0]?.active ?? 0,
      collected: revenue[0]?.collected ?? 0,
      monthCollected: revenue[0]?.monthCollected ?? 0,
      outstanding: outstanding[0]?.open ?? 0,
      overdueInvoices: outstanding[0]?.overdueCount ?? 0,
    },
    claimSummary,
    appointmentStatusRows,
    lowStock,
    schedule,
    recentActivity,
    revenueTrend,
    departmentLoad,
  };
}

export async function searchPatients(term: string) {
  const like = `%${term}%`;
  return db
    .select({
      id: patients.id,
      mrn: patients.mrn,
      firstName: patients.firstName,
      lastName: patients.lastName,
      city: patients.city,
      status: patients.status,
    })
    .from(patients)
    .where(
      or(
        ilike(patients.firstName, like),
        ilike(patients.lastName, like),
        ilike(patients.mrn, like),
      ),
    )
    .limit(8);
}
