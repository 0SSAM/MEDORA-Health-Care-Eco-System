export const ROLE_LABELS: Record<string, string> = {
  admin: "Administrator",
  doctor: "Physician",
  nurse: "Nurse",
  pharmacist: "Pharmacist",
  billing: "Billing",
  front_desk: "Front Desk",
};

export const ROLE_OPTIONS = Object.entries(ROLE_LABELS).map(([value, label]) => ({
  value,
  label,
}));
