import "server-only";

import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { eq, or } from "drizzle-orm";

import { db } from "@/db";
import { users, activityLog, type User } from "@/db/schema";

const COOKIE_NAME = "medora_session";
const MAX_AGE_SECONDS = 60 * 60 * 24 * 7;
const SECRET =
  process.env.AUTH_SECRET ?? "medora-development-secret-key-change-me";

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, key] = stored.split(":");
  if (!salt || !key) return false;
  const derived = scryptSync(password, salt, 64);
  const expected = Buffer.from(key, "hex");
  if (expected.length !== derived.length) return false;
  return timingSafeEqual(derived, expected);
}

type SessionPayload = { sub: string; exp: number };

function sign(value: string): string {
  return createHmac("sha256", SECRET).update(value).digest("base64url");
}

export function createToken(userId: string): string {
  const payload: SessionPayload = {
    sub: userId,
    exp: Date.now() + MAX_AGE_SECONDS * 1000,
  };
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${sign(body)}`;
}

export function readToken(token: string | undefined): string | null {
  if (!token) return null;
  const [body, signature] = token.split(".");
  if (!body || !signature) return null;
  if (sign(body) !== signature) return null;
  try {
    const payload = JSON.parse(
      Buffer.from(body, "base64url").toString("utf8"),
    ) as SessionPayload;
    if (!payload?.sub || payload.exp < Date.now()) return null;
    return payload.sub;
  } catch {
    return null;
  }
}

export async function startSession(userId: string) {
  const store = await cookies();
  store.set(COOKIE_NAME, createToken(userId), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE_SECONDS,
  });
}

export async function endSession() {
  const store = await cookies();
  store.delete(COOKIE_NAME);
}

export type SessionUser = Omit<User, "passwordHash">;

export async function getCurrentUser(): Promise<SessionUser | null> {
  try {
    const store = await cookies();
    const userId = readToken(store.get(COOKIE_NAME)?.value);
    if (!userId) return null;
    const [found] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    if (!found || !found.isActive) return null;
    const { passwordHash: _ignored, ...safe } = found;
    return safe;
  } catch {
    return null;
  }
}

export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

export async function authenticate(
  emailOrUsername: string,
  password: string,
): Promise<SessionUser | null> {
  const normalized = emailOrUsername.trim().toLowerCase();
  const rows = await db
    .select()
    .from(users)
    .where(
      or(
        eq(users.email, normalized),
        eq(users.username, normalized),
      ),
    )
    .limit(1);
  const found = rows[0];
  if (!found) return null;
  if (!verifyPassword(password, found.passwordHash)) return null;
  await db
    .update(users)
    .set({ lastLoginAt: new Date() })
    .where(eq(users.id, found.id));
  const { passwordHash: _ignored, ...safe } = found;
  return safe;
}

export async function logActivity(input: {
  actorName: string;
  action: string;
  entity: string;
  entityId?: string;
  detail?: string;
}) {
  await db.insert(activityLog).values({
    actorName: input.actorName,
    action: input.action,
    entity: input.entity,
    entityId: input.entityId ?? "",
    detail: input.detail ?? "",
  });
}

export { ROLE_LABELS } from "@/lib/roles";
