import "server-only";

import { and, asc, desc, eq, ilike, or, type SQL } from "drizzle-orm";
import type { PgColumn, PgTable } from "drizzle-orm/pg-core";
import type { NextRequest } from "next/server";
import type { z } from "zod";

import { db } from "@/db";
import { getCurrentUser, logActivity } from "@/lib/auth";

type Row = Record<string, unknown>;

export type ResourceConfig = {
  entity: string;
  table: PgTable;
  idColumn: PgColumn;
  createSchema: z.ZodTypeAny;
  updateSchema: z.ZodTypeAny;
  searchColumns?: PgColumn[];
  statusColumn?: PgColumn;
  orderColumn?: PgColumn;
  describe?: (row: Row) => string;
  extra?: (values: Row, mode: "create" | "update") => Row;
};

export function jsonError(message: string, status = 400) {
  return Response.json({ error: message }, { status });
}

function normalizeIds(values: Row): Row {
  const next: Row = {};
  for (const [key, value] of Object.entries(values)) {
    if (typeof value === "string" && value.trim() === "" && key.endsWith("Id")) {
      next[key] = null;
    } else {
      next[key] = value;
    }
  }
  return next;
}

function zodMessage(error: z.ZodError) {
  return error.issues[0]?.message ?? "Invalid request payload";
}

export function createCollectionRoute(config: ResourceConfig) {
  async function GET(request: NextRequest) {
    const user = await getCurrentUser();
    if (!user) return jsonError("Unauthorized", 401);

    const { searchParams } = new URL(request.url);
    const query = searchParams.get("q")?.trim();
    const status = searchParams.get("status")?.trim();
    const limit = Math.min(Number(searchParams.get("limit") ?? 300) || 300, 1000);

    const filters: SQL[] = [];
    if (query && config.searchColumns?.length) {
      const matches = config.searchColumns.map((column) =>
        ilike(column, `%${query}%`),
      );
      const combined = or(...matches);
      if (combined) filters.push(combined);
    }
    if (status && status !== "all" && config.statusColumn) {
      filters.push(eq(config.statusColumn, status));
    }

    const rows = await db
      .select()
      .from(config.table)
      .where(filters.length ? and(...filters) : undefined)
      .orderBy(desc(config.orderColumn ?? config.idColumn))
      .limit(limit);

    return Response.json({ data: rows });
  }

  async function POST(request: NextRequest) {
    const user = await getCurrentUser();
    if (!user) return jsonError("Unauthorized", 401);

    const body = await request.json().catch(() => null);
    const parsed = config.createSchema.safeParse(body);
    if (!parsed.success) return jsonError(zodMessage(parsed.error));

    let values = normalizeIds(parsed.data as Row);
    if (config.extra) values = config.extra(values, "create");

    const inserted = await db
      .insert(config.table)
      .values(values as never)
      .returning();
    const row = (inserted as Row[])[0];

    await logActivity({
      actorName: user.name,
      action: `created ${config.entity}`,
      entity: config.entity,
      entityId: String(row?.id ?? ""),
      detail: config.describe?.(row) ?? "",
    });

    return Response.json({ data: row }, { status: 201 });
  }

  return { GET, POST };
}

export function createItemRoute(config: ResourceConfig) {
  async function GET(
    _request: NextRequest,
    context: { params: Promise<{ id: string }> },
  ) {
    const user = await getCurrentUser();
    if (!user) return jsonError("Unauthorized", 401);
    const { id } = await context.params;
    const rows = await db
      .select()
      .from(config.table)
      .where(eq(config.idColumn, id))
      .limit(1);
    if (!rows.length) return jsonError("Not found", 404);
    return Response.json({ data: rows[0] });
  }

  async function PATCH(
    request: NextRequest,
    context: { params: Promise<{ id: string }> },
  ) {
    const user = await getCurrentUser();
    if (!user) return jsonError("Unauthorized", 401);
    const { id } = await context.params;

    const body = await request.json().catch(() => null);
    const parsed = config.updateSchema.safeParse(body);
    if (!parsed.success) return jsonError(zodMessage(parsed.error));

    let values = normalizeIds(parsed.data as Row);
    if (config.extra) values = config.extra(values, "update");
    if (!Object.keys(values).length) return jsonError("No changes submitted");

    const updated = await db
      .update(config.table)
      .set(values as never)
      .where(eq(config.idColumn, id))
      .returning();
    const row = (updated as Row[])[0];
    if (!row) return jsonError("Not found", 404);

    await logActivity({
      actorName: user.name,
      action: `updated ${config.entity}`,
      entity: config.entity,
      entityId: id,
      detail: config.describe?.(row) ?? "",
    });

    return Response.json({ data: row });
  }

  async function DELETE(
    _request: NextRequest,
    context: { params: Promise<{ id: string }> },
  ) {
    const user = await getCurrentUser();
    if (!user) return jsonError("Unauthorized", 401);
    const { id } = await context.params;

    const removed = await db
      .delete(config.table)
      .where(eq(config.idColumn, id))
      .returning();
    const row = (removed as Row[])[0];
    if (!row) return jsonError("Not found", 404);

    await logActivity({
      actorName: user.name,
      action: `deleted ${config.entity}`,
      entity: config.entity,
      entityId: id,
      detail: config.describe?.(row) ?? "",
    });

    return Response.json({ data: row });
  }

  return { GET, PATCH, DELETE };
}

export { asc };
