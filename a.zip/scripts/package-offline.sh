#!/usr/bin/env bash
# Package the standalone offline MEDORA edition into the dist/ folder.
# Produces a single portable folder that runs on Windows with zero dependencies.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST="$ROOT/dist"

mkdir -p "$DIST"

# The single-file application is the source of truth in public/.
cp "$ROOT/public/medora-offline.html" "$DIST/medora-offline.html"

# Self-extracting / portable launchers (token substitution keeps versions in sync).
# START-MEDORA.cmd and SETUP-MEDORA.cmd are already committed static files.

echo "[medora] Offline distribution assembled:"
ls -lh "$DIST"
echo
echo "[medora] To use on Windows, copy the contents of dist/ to any folder"
echo "        and double-click START-MEDORA.cmd (or medora-offline.html)."
