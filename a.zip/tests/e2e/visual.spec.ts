import { test, expect } from "@playwright/test";

// Visual regression tests. Each page is captured as a full-page screenshot
// and compared against the stored baseline (update with --update-snapshots).
// Failures also emit a screenshot for manual review.

const PAGES = [
  "/login",
  "/dashboard",
  "/patients",
  "/appointments",
  "/prescriptions",
  "/pharmacy",
  "/billing",
  "/claims",
  "/staff",
  "/settings",
];

const SLUGS: Record<string, string> = {
  "/login": "login",
  "/dashboard": "dashboard",
  "/patients": "patients",
  "/appointments": "appointments",
  "/prescriptions": "prescriptions",
  "/pharmacy": "pharmacy",
  "/billing": "billing",
  "/claims": "claims",
  "/staff": "staff",
  "/settings": "settings",
};

test.beforeEach(async ({ page }) => {
  await page.goto("/login");
  await page.getByLabel("Username or email").fill("admin");
  await page.getByLabel("Password").fill("admin");
  await page.locator("button[type=submit]").click();
  await expect(page).toHaveURL(/\/dashboard/);
});

test.describe("Visual snapshots", () => {
  for (const path of PAGES) {
    test(`screenshot of ${SLUGS[path]}`, async ({ page }) => {
      if (path === "/login") {
        await page.goto("/login");
      } else {
        await page.goto(path);
        await page.waitForLoadState("networkidle");
      }
      // Allow skeletons/animations to settle before capturing.
      await page.waitForTimeout(700);
      await expect(page).toHaveScreenshot(`${SLUGS[path]}.png`, {
        fullPage: true,
        maxDiffPixelRatio: 0.02,
      });
    });
  }
});
