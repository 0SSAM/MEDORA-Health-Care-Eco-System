import { test, expect, type Page } from "@playwright/test";

// Full CRUD flow against the running API and UI. These tests exercise the
// persistent PostgreSQL-backed data layer through the actual application.

async function signIn(page: Page) {
  await page.goto("/login");
  await page.getByLabel("Username or email").fill("admin");
  await page.getByLabel("Password").fill("admin");
  await page.locator("button[type=submit]").click();
  await expect(page).toHaveURL(/\/dashboard/);
}

test.describe("REST API CRUD", () => {
  test("health endpoint responds ok", async ({ request }) => {
    const response = await request.get("/api/health");
    expect(response.ok()).toBeTruthy();
    const body = await response.json();
    expect(body.ok).toBe(true);
  });

  test("unauthenticated API access is rejected", async ({ request }) => {
    const response = await request.get("/api/patients");
    expect(response.status()).toBe(401);
  });

  test.describe("authenticated API", () => {
    async function login(request: import("@playwright/test").APIRequestContext) {
      const response = await request.post("/api/auth/login", {
        data: { email: "admin", password: "admin" },
      });
      expect(response.ok()).toBeTruthy();
      return response;
    }

    test("lists patients", async ({ request }) => {
      await login(request);
      const response = await request.get("/api/patients");
      expect(response.ok()).toBeTruthy();
      const body = await response.json();
      expect(Array.isArray(body.data)).toBe(true);
      expect(body.data.length).toBeGreaterThan(0);
    });

    test("creates, updates, and deletes a patient", async ({ request }) => {
      await login(request);
      const create = await request.post("/api/patients", {
        data: {
          firstName: "E2E",
          lastName: "Tester",
          dateOfBirth: "1990-01-01",
          gender: "female",
          phone: "+966500000000",
          city: "Riyadh",
          status: "active",
          riskLevel: "low",
        },
      });
      expect(create.status()).toBe(201);
      const created = (await create.json()).data;
      expect(created.firstName).toBe("E2E");
      expect(created.mrn).toMatch(/^MRN-/);

      const update = await request.patch(`/api/patients/${created.id}`, {
        data: { status: "critical", city: "Jeddah" },
      });
      expect(update.ok()).toBeTruthy();
      const updated = (await update.json()).data;
      expect(updated.status).toBe("critical");
      expect(updated.city).toBe("Jeddah");

      const del = await request.delete(`/api/patients/${created.id}`);
      expect(del.ok()).toBeTruthy();
    });

    test("validates required fields", async ({ request }) => {
      await login(request);
      const response = await request.post("/api/patients", {
        data: { firstName: "A", lastName: "B" },
      });
      expect(response.ok()).toBeFalsy();
    });

    test("appointments expose patient join data", async ({ request }) => {
      await login(request);
      const response = await request.get("/api/appointments?limit=5");
      expect(response.ok()).toBeTruthy();
      const body = await response.json();
      expect(body.data.length).toBeGreaterThan(0);
    });
  });
});

test.describe("UI CRUD (patients)", () => {
  test("registers a patient through the form with optimistic update", async ({ page }) => {
    await signIn(page);
    await page.goto("/patients");

    await page.getByRole("button", { name: /new patient/i }).click();

    // The patient form is inside the (last) modal dialog.
    const modal = page.locator("form").last();
    await modal.getByLabel(/first name/i).fill("Playwright");
    await modal.getByLabel(/last name/i).fill("Patient");
    await modal.getByRole("button", { name: /create patient/i }).click();

    await expect(page.getByText("Playwright Patient").first()).toBeVisible();
  });
});
