import { test, expect } from "@playwright/test";

// Core authentication flows: root admin (username "admin" / "admin"),
// demo accounts, and rejection of bad credentials.

test.describe("Authentication", () => {
  test("landing page redirects to login when unauthenticated", async ({ page }) => {
    await page.goto("/");
    // Landing page is public, but the dashboard must redirect away.
    await expect(page.getByText(/healthcare ecosystem/i).first()).toBeVisible();
  });

  test("unauthenticated dashboard redirects to login", async ({ page }) => {
    await page.goto("/dashboard");
    await expect(page).toHaveURL(/\/login/);
  });

  test("signs in with root administrator username", async ({ page }) => {
    await page.goto("/login");
    await page.getByLabel("Username or email").fill("admin");
    await page.getByLabel("Password").fill("admin");
    await page.locator("button[type=submit]").click();
    await expect(page).toHaveURL(/\/dashboard/);
    // The dashboard greets the admin by surname.
    await expect(page.getByText(/^Good (morning|afternoon|evening), Haddad$/).first()).toBeVisible();
  });

  test("signs in with demo physician email", async ({ page }) => {
    await page.goto("/login");
    await page.getByLabel("Username or email").fill("doctor@medora.health");
    await page.getByLabel("Password").fill("medora123");
    await page.locator("button[type=submit]").click();
    await expect(page).toHaveURL(/\/dashboard/);
  });

  test("rejects wrong password with an error message", async ({ page }) => {
    await page.goto("/login");
    await page.getByLabel("Username or email").fill("admin");
    await page.getByLabel("Password").fill("definitely-wrong");
    await page.locator("button[type=submit]").click();
    await expect(page.getByText(/don't match/i)).toBeVisible();
    await expect(page).toHaveURL(/\/login/);
  });

  test("sign out returns to the login page", async ({ page }) => {
    await page.goto("/login");
    await page.getByLabel("Username or email").fill("admin");
    await page.getByLabel("Password").fill("admin");
    await page.locator("button[type=submit]").click();
    await expect(page).toHaveURL(/\/dashboard/);

    // Open the sign-out action in the sidebar (visible on desktop viewport).
    const signOut = page.getByRole("button", { name: /sign out/i });
    await signOut.first().click();
    await expect(page).toHaveURL(/\/login/);
  });
});
