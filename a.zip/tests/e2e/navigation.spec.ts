import { test, expect } from "@playwright/test";

// Verify every module is reachable from the sidebar navigation and renders content.

const ROUTES = [
  { path: "/dashboard", heading: null }, // dashboard uses a dynamic greeting, asserted separately
  { path: "/patients", heading: "Patients" },
  { path: "/appointments", heading: "Appointments" },
  { path: "/prescriptions", heading: "Prescriptions" },
  { path: "/pharmacy", heading: "Pharmacy inventory" },
  { path: "/billing", heading: "Billing & POS" },
  { path: "/claims", heading: "Insurance claims" },
  { path: "/staff", heading: "Care team" },
  { path: "/settings", heading: "Access & workspace" },
];

test.beforeEach(async ({ page }) => {
  await page.goto("/login");
  await page.getByLabel("Username or email").fill("admin");
  await page.getByLabel("Password").fill("admin");
  await page.locator("button[type=submit]").click();
  await expect(page).toHaveURL(/\/dashboard/);
});

test.describe("Navigation & rendering", () => {
  for (const route of ROUTES) {
    test(`renders ${route.path}`, async ({ page }) => {
      await page.goto(route.path);
      if (route.heading === null) {
        // Dashboard heading is a dynamic greeting.
        await expect(
          page.getByRole("heading", { level: 1 }).first(),
        ).toContainText(/Good (morning|afternoon|evening)/);
      } else {
        await expect(page.getByRole("heading", { level: 1 }).first()).toContainText(
          route.heading,
        );
      }
    });
  }

  test("sidebar links navigate between modules", async ({ page }) => {
    await page.getByRole("link", { name: /Patients/ }).first().click();
    await expect(page).toHaveURL(/\/patients/);
    await expect(page.getByRole("heading", { level: 1 }).first()).toContainText("Patients");
  });
});
